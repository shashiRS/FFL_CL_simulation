# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    SINT_SIG_NAME1,
    INTEGER_SIG_NAME,
    INTEGER_SIG_NAME1
)
import numpy as np
from evaluate.core import Testcase, Verdict, Delimiters


BITLSHIFT_NAME1 = "RefBitLShift"

# BITLSHIFT
BITLSHIFT_CONST_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITLSHIFT({{delimiter.start}}128{{delimiter.end}},{{delimiter.start}}1{{delimiter.end}}) == 256
""".format(None)

BITLSHIFT_CONST_TC_NEG = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITLSHIFT({{delimiter.start}}128{{delimiter.end}},{{delimiter.start}}2{{delimiter.end}}) == 256
""".format(None)

BITLSHIFT_SIG_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITLSHIFT({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}1{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INTEGER_SIG_NAME1, BITLSHIFT_NAME1)

BITLSHIFT_T_SIG_TC = """
T1:
start_of_measurement

T2:
9195ms

ET2:
BITLSHIFT({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}0b1{{delimiter.end}}) == 0x8 //"0x08", "8"
""".format(INTEGER_SIG_NAME1)

class TestFunction_BITLSHIFT(unittest.TestCase):

    __name__ = 'TestFunction_BITLSHIFT'

    # BITLSHIFT
    def test_const_bitlshift(self):
        tc = Testcase(BITLSHIFT_CONST_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_const_bitlshift_neg(self):
        tc = Testcase(BITLSHIFT_CONST_TC_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_sig_t_bitlshift(self):
        tc = Testcase(BITLSHIFT_T_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sig_bitlshift(self):
        sigs[BITLSHIFT_NAME1] = sigs[SINT_SIG_NAME1]
        b = np.ones(len(sigs[BITLSHIFT_NAME1].signal), int)*8
        sigs[BITLSHIFT_NAME1].signal = b
        tc = Testcase(BITLSHIFT_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()

        self.assertEqual(a[0], Verdict.passed)

    def test_sig_bitlshift_neg(self):
        sigs[BITLSHIFT_NAME1] = sigs[SINT_SIG_NAME1]
        b = np.ones(len(sigs[BITLSHIFT_NAME1].signal), int)*4
        sigs[BITLSHIFT_NAME1].signal = b
        tc = Testcase(BITLSHIFT_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
