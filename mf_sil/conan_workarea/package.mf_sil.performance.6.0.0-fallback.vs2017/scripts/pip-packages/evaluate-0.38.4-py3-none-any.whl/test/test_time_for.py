# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    csv_path,
    sigs,
    INTEGER_SIG_NAME
)

from evaluate.core import Testcase, Verdict, Delimiters

from test.utils import get_signal_data


FOR_POS = """
T1:
{{delimiter.start}}IGN_SWITCH{{delimiter.end}}  == RISING(0, 1)

T2:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100

INT_ET1_ET2:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 90000000ns
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 90000us
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 90ms
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 0.009s
""".format(None)

FOR_NEG = """
T1:
{{delimiter.start}}IGN_SWITCH{{delimiter.end}}  == RISING(0, 1)

T2:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100

T3:
{{delimiter.start}}9.3s{{delimiter.end}}

INT_ET1_ET3:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 91ms
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 91000us
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == {{delimiter.start}}0x0{{delimiter.end}}  for 91000000ns
""".format(None)


class TestTime_FOR(unittest.TestCase):

    def test_for_pos(self):
        sigs = get_signal_data(
            csv_path,
            ["IGN_SWITCH", "FAIL_RAM_807a"]
        )
        tc = Testcase(FOR_POS.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_for_neg(self):
        sigs = get_signal_data(
            csv_path,
            ["IGN_SWITCH", "FAIL_RAM_807a"]
        )
        tc = Testcase(FOR_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
