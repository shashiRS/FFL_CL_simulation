# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    MAXIM_SIG,
    MINIM_SIG,
    POW_SIG,
    LARGE_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters


# LARGE
LARGE_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
LARGE({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) == 29
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, LARGE_SIG)

LARGE_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
LARGE({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) != 29
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, LARGE_SIG)

LARGE_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
LARGE({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) == {{delimiter.start}}{}{{delimiter.end}}
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, LARGE_SIG)

class TestFunction_LARGE(unittest.TestCase):

    __name__ = 'TestFunction_LARGE'


    # LARGE
    def test_large(self):
        tc = Testcase(LARGE_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
    def test_large_neg(self):
        tc = Testcase(LARGE_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
    def test_large_interval(self):
        tc = Testcase(LARGE_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
