# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    DECREMENT_SIG,
    MAXIM_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters


# MAXIM
MAXIM_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MAXIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 29
""".format(INCREMENT_SIG, DECREMENT_SIG)

MAXIM_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MAXIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) != 29
""".format(INCREMENT_SIG, DECREMENT_SIG)

MAXIM_TC_INT = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
MAXIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, DECREMENT_SIG, MAXIM_SIG)

MAXIM_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MAXIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) != 29
""".format(INCREMENT_SIG, DECREMENT_SIG)


class TestFunction_MAXIM(unittest.TestCase):

    __name__ = 'TestFunction_MAXIM'


    # MAXIM
    def test_maxim(self):
        tc = Testcase(MAXIM_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_maxim_neg(self):
        tc = Testcase(MAXIM_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_maxim_interval(self):
        tc = Testcase(MAXIM_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_maxim_neg_interval(self):
        tc = Testcase(MAXIM_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
