# -*- coding: utf-8 -*-
import os
import unittest

from test.utils import get_signal_data, get_test_data
import numpy as np
from evaluate.core import Delimiters, Testcase, Verdict

thispath = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
csv_path = get_test_data("meas.csv")

AVAILABLE_FUNCTIONS = (
    'ABS', 'AVG',
    'BITAND', 'BITLSHIFT', 'BITOR', 'BITRSHIFT', 'BITXOR',
    'CHECK_CYCLE_TIME', 'CLIP',
    'DIFF', 'DEFINE', 'DIV',
    'EDIFF',
    'GRAD',
    'HYST',
    'INTERP',
    'LARGE',
    'MAX', 'MAXIM', 'MIN', 'MINIM', 'MOD',
    'NP_',
    'POW', 'PROD', 'PWM_DUTY', 'PWM_FREQ', 'PWM_PERIOD',
    'SEQUENCE', 'SIGN', 'SMALL', 'STRCMP', 'STRCMP_XDL', 'STR2INT_XDL', 'SUM',
    'TIME_SHIFT', 'TIMEOUT',
    'USE_PREVIOUS_SAMPLE',
    'VALUELIST'
)

TESTED_FUNCTIONS = (
    'ABS', 'AVG',
    'BITAND', 'BITLSHIFT', 'BITOR', 'BITRSHIFT', 'BITXOR',
    'CHECK_CYCLE_TIME',
    'DIFF', 'DIV',
    'EDIFF',
    'GRAD',
    'HYST',
    'LARGE',
    'MAX', 'MAXIM', 'MIN', 'MINIM', 'MOD',
    'POW', 'PROD',
    'SEQUENCE', 'SIGN', 'SMALL', 'SUM',
    'TIMEOUT',
    'VALUELIST'
)

AVAILABLE_TYPES = (
    'hex', 'bin', 'float', 'integer')
TESTED_TYPES = (
    'hex', 'bin', 'float', 'integer')

AVAILABLE_DELAY = (
    'count', 'delay', 'for', 'until', 'tolerance', 'within', 'once')
TESTED_DELAY = (
    'count', 'delay', 'for', 'until', 'tolerance', 'within', 'once')

AVAILABLE_TIME = (
    'ns', 'us', 'ms', 's')
TESTED_TIME = (
    'ns', 'us', 'ms', 's')

FSF_EBD = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5,
           5, 5, 5, 5, 5, 5, 5, 5, 5, 5]

MKC_MAG = [28.31, 28.31, 28.31, 28.31, 28.31, 28.31, 28.31, 28.31, 28.28,
           28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28,
           28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28, 28.28,
           28.28, 28.28]

MKC_CAP = [26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56,
           26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56,
           26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56, 26.56,
           26.56, 26.56]

# Float signals
FLOAT_SIG_NAME_1 = "MKC_AMM_MAGNET_TEMP_AVG"
FLOAT_SIG_NAME_2 = "MKC_AMM_DCL_CAP_TEMP_HOTSPOT"

# Integer signals
INTEGER_SIG_NAME = "Fsf_ebd"
INTEGER_SIG_NAME1 = "MkcSupServExecSt2ms_6a"
SINT_SIG_NAME1 = "SpcMotorSpeed"

# Bitwise
BIT_SIG_1 = "BITSIG1"
BIT_SIG_2 = "BITSIG2"
BITXOR_SIG = "BITXOR"
BITLSHIFT_NAME1 = "RefBitLShift"

# Triggers
CT_SIG = "CT"
INT_ECT_SIG = "INT_ECT"
INT_ECT_NOT_SIG = "INT_ECT_NOT"

# Add signals for SUM, DIFF, EDDIF, PROD
CYCLE_TIME_SIG = "CycleTime"
DECREMENT_SIG = "DECREMENT"
DIFF_SIG = "DIFF"  # INCREMENT_SIG - RANDOM_SIG_0_100
DIV_SIG = "DIV" # MAXIM / MINIM
INCREMENT_SIG = "INCREMENT"
LARGE_SIG = "LARGE" # LARGE(MAXIM, MINIM, PROD, 2)
MAXIM_SIG = "MAXIM"
MINIM_SIG = "MINIM"
MOD_SIG = "MOD" # MOD(MAXIM, MINIM)
MOD_SIG_CONST_SIG = "MOD_SIG_CONST" # MOD(MAXIM, 5)
MOD_CONST_SIG_SIG = "MOD_CONST_SIG" # MOD(100, MAXIM)
POW_SIG = "POW" # DIV ^ MINIM
PROD_SIG = "PROD" # INCREMENT_SIG * RANDOM_SIG_0_100
RANDOM_SIG_0_100 = "RANDOM"
SIGN_SAMPLES = "SignSample"
SMALL_SIG = "SMALL" # SMALL(MAXIM, MINIM, PROD, 2), should be the same as LARGE
SUM_SIG = "SUM"  # INCREMENT_SIG + RANDOM_SIG_0_100
TIMEOUT_SIG = "TIMEOUT"


GRAD_SIG = 'GRAD'
GRAD_RASTER_SIG = 'GRAD_RASTER'
HYST_SIG = 'HYST'
TIME_TOLERANCE_SIG = 'TIME_TOLERANCE'

CONST_3 = 'CONST_3'
CONST_1000 = 'CONST_1000'
CONST_0_01 = 'CONST_0.01'

sigs = get_signal_data(csv_path, [
    CYCLE_TIME_SIG,
    DECREMENT_SIG,
    DIFF_SIG,
    DIV_SIG,
    FLOAT_SIG_NAME_1,
    FLOAT_SIG_NAME_2,
    INCREMENT_SIG,
    INTEGER_SIG_NAME,
    INTEGER_SIG_NAME1,
    LARGE_SIG,
    MAXIM_SIG,
    MINIM_SIG,
    MOD_SIG,
    MOD_CONST_SIG_SIG,
    MOD_SIG_CONST_SIG,
    PROD_SIG,
    POW_SIG,
    RANDOM_SIG_0_100,
    SIGN_SAMPLES,
    SINT_SIG_NAME1,
    SMALL_SIG,
    SUM_SIG,
    CT_SIG,
    INT_ECT_SIG,
    INT_ECT_NOT_SIG,
    GRAD_SIG,
    GRAD_RASTER_SIG,
    HYST_SIG,
    TIME_TOLERANCE_SIG,
    TIMEOUT_SIG,
    CONST_3,
    CONST_0_01,
    CONST_1000,
    BIT_SIG_1,
    BIT_SIG_2,
    BITXOR_SIG
])



GENERIC_1 = """
T1:
1.5

T2:
T1 - {{delimiter.start}}1500001us{{delimiter.end}}+1000 ns

T3:
{{delimiter.start}}IGN_SWITCH{{delimiter.end}} == RISING(0, 1)

T4:
0 == {{delimiter.start}}IGN_SWITCH{{delimiter.end}}

ET1:
-7 == {{delimiter.start}}IGN_SWITCH{{delimiter.end}}

ET3:
{{delimiter.start}}0xABCDEF{{delimiter.end}}  == {{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}

ET4:
-  {{delimiter.start}}IGN_SWITCH{{delimiter.end}} ==     - {{delimiter.start}}-7.9{{delimiter.end}}
""".format(None)

# Syntax to be used in case test is copied from VED test database
# tc_6 = re.sub("{{", '"', re.sub("}}", '"', tc_6))

class TestUtils(unittest.TestCase):

    def test_get_signal_data(self):
        sigs_test = get_signal_data(csv_path,
                                    ["Fsf_ebd",
                                     FLOAT_SIG_NAME_1,
                                     FLOAT_SIG_NAME_2])
        c1 = (sigs_test["Fsf_ebd"].signal == np.array(FSF_EBD))
        c2 = (sigs_test["MKC_AMM_MAGNET_TEMP_AVG"].signal == np.array(MKC_MAG))
        c3 = (sigs_test["MKC_AMM_DCL_CAP_TEMP_HOTSPOT"].signal ==
              np.array(MKC_CAP))
        self.assertTrue(c1.all() and c2.all() and c3.all())


class TestTestCase(unittest.TestCase):

    def test_test_case_exists(self):
        self.assertTrue(Testcase)

    def test_generic_1(self):
        sigs = get_signal_data(
            csv_path,
            ["IGN_SWITCH", "FAIL_RAM_807a"]
        )

        tc = Testcase(GENERIC_1.format(delimiter=Delimiters), sigs)
        print(GENERIC_1.format(delimiter=Delimiters))
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)


if __name__ == '__main__':
    unittest.main()
else:
    pass
