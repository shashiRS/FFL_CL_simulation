# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    csv_path,
    sigs,
    SINT_SIG_NAME1
)

from evaluate.core import Testcase, Verdict, Delimiters, Signal
from test.utils import get_signal_data, save_html_report

import numpy as np

ABS_SPC_NAME1 = "RefAbs"
ABS_SPC_NAME2 = "RefAbsNeg"

ABS_SPC_MOT = [18, 8, 3, 12, 15, 16, 4, 6, 15, 1, 13, 8, 2, 19, 0, 8, 0, 8,
               16, 13, 2, 4, 12, 0, 11, 0, 7, 3, 2]

ABS_SPC_MOT_NEG = [18, -8, 3, 12, 15, 16, 4, 6, 15, 1, 13, 8, 2, 19, 0, 8, 0,
                   8, 16, 13, 2, 4, 12, 0, 11, 0, 7, 3, 2]

# ABS
ABS_SIG_TC = """
T1:
start_of_measurement
T2:
T1 + 1000000ns
T3:
T2 + 1000us
T4:
T3 + 1ms
T5:
T4 + 0.001s
T6:
end_of_measurement

INT_ET1_ET6:
ABS({{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(SINT_SIG_NAME1, ABS_SPC_NAME1)

ABS_SIG_TC_NEG = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
ABS({{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(SINT_SIG_NAME1, ABS_SPC_NAME2)

ABS_CONST_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
ABS({{delimiter.start}}-2{{delimiter.end}}) == 2
""".format(None)

ABS_CONST_TC_NEG = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
ABS({{delimiter.start}}-2{{delimiter.end}}) == -2 until 1000000000ns
AND ABS({{delimiter.start}}-2{{delimiter.end}}) == -2 until PROD({{delimiter.start}}1000{{delimiter.end}}, 1E3) us
AND ABS({{delimiter.start}}-2{{delimiter.end}}) == -2 until SUM(0.5, 0.5) ms
AND ABS({{delimiter.start}}-2{{delimiter.end}}) == -2 until 0.001s
""".format(None)


class TestFunction_ABS(unittest.TestCase):

    __name__ = 'TestFunction_ABS'

    # ABS
    def test_abs_sig(self):

        # Get a signal with negative and positive values
        local_sigs = get_signal_data(
            csv_path,
            [SINT_SIG_NAME1]
        )
        # Create result signal
        local_sigs[ABS_SPC_NAME1] = Signal(np.array(ABS_SPC_MOT), np.array(local_sigs[SINT_SIG_NAME1].time))
        local_sigs[ABS_SPC_NAME1].name = SINT_SIG_NAME1 + '_AbsoluteValue'

        # Get Test case object
        tc = Testcase(ABS_SIG_TC.format(delimiter=Delimiters), local_sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

        #  save html report
        tc.id = 'test_abs_sig'
        save_html_report(tc, local_sigs)


    def test_abs_sig_neg(self):
        # Get a signal with negative and positive values
        local_sigs = get_signal_data(
            csv_path,
            [SINT_SIG_NAME1]
        )
        # Create result signal
        local_sigs[ABS_SPC_NAME2] = Signal(np.array(ABS_SPC_MOT_NEG), np.array(local_sigs[SINT_SIG_NAME1].time))
        local_sigs[ABS_SPC_NAME2].name = SINT_SIG_NAME1 + '_NotAbsoluteValue'

        # Get Test case object
        tc = Testcase(ABS_SIG_TC_NEG.format(delimiter=Delimiters), local_sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

        #  save html report
        tc.id = 'test_abs_sig_neg'
        save_html_report(tc, local_sigs)

    def test_abs_cnt_pos(self):
        # Get Test case object
        tc = Testcase(ABS_CONST_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_abs_cnt_neg(self):
        tc = Testcase(ABS_CONST_TC_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
