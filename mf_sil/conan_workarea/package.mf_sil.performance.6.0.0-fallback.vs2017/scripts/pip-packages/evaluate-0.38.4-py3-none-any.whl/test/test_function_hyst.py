# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    HYST_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# HYST
HYST_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
HYST({{delimiter.start}}{}{{delimiter.end}}, 10, 8, 0) == 1
""".format(HYST_SIG)

HYST_NEG_TC_INT = """
T1:
{{delimiter.start}}{}{{delimiter.end}} == 15

T2:
end_of_measurement

INT_ET1_ET2:
HYST({{delimiter.start}}{}{{delimiter.end}}, 10, 8, 1) == 1
""".format(HYST_SIG, HYST_SIG)

class TestFunction_HYST(unittest.TestCase):

    __name__ = 'TestFunction_HYST'


    # HYST
    def test_hyst_interval(self):
        tc = Testcase(HYST_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()

        self.assertEqual(a[0], Verdict.passed)

    def test_hyst_neg_interval(self):
        tc = Testcase(HYST_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()

        self.assertEqual(a[0], Verdict.failed)
