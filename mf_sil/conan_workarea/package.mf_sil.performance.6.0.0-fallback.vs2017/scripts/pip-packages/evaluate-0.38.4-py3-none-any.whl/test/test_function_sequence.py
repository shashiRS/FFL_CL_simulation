# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INTEGER_SIG_NAME,
)

from evaluate.core import Testcase, Verdict, Delimiters


# SEQUENCE
SEQUENCE_TC = """
T1:
start_of_measurement

T2:
9205.52ms

INT_ET1_ET2:
SEQUENCE({{delimiter.start}}{}{{delimiter.end}},1,5) == 1
""".format(INTEGER_SIG_NAME)

SEQUENCE_NEG_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
SEQUENCE({{delimiter.start}}{}{{delimiter.end}},1,5) == 1
""".format(INTEGER_SIG_NAME)


class TestFunction_SEQUENCE(unittest.TestCase):

    __name__ = 'TestFunction_SEQUENCE'


    # SEQUENCE
    def test_seqeuence(self):
        tc = Testcase(SEQUENCE_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sequence_neg(self):
        tc = Testcase(SEQUENCE_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
