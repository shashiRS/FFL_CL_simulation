# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# EDIFF
EDIFF_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
EDIFF({{delimiter.start}}{}{{delimiter.end}}) == 1
""".format(INCREMENT_SIG)

# EDIFF
EDIFF_TC_INT_TOL = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
EDIFF({{delimiter.start}}{}{{delimiter.end}}) == 0 tolerance 1
""".format(INCREMENT_SIG)


EDIFF_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
EDIFF({{delimiter.start}}{}{{delimiter.end}}) == 0.9999
""".format(INCREMENT_SIG)


class TestFunction_EDIFF(unittest.TestCase):

    __name__ = 'TestFunction_EDIFF'

    # EDIFF
    def test_ediff(self):
        tc = Testcase(EDIFF_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_ediff_tolerance(self):
        tc = Testcase(EDIFF_TC_INT_TOL.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_ediff_neg(self):
        tc = Testcase(EDIFF_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
