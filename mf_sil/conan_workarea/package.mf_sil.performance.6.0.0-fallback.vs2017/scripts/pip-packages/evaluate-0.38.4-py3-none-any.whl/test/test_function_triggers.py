# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    CT_SIG,
    INT_ECT_SIG,
    INT_ECT_NOT_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters


# Triggers
INT_ECT_TC = """
CT1:
//comment
{{delimiter.start}}{}{{delimiter.end}} == RISING(0, 1)  //comment

CT2:
    //comment
{{delimiter.start}}{}{{delimiter.end}} == RISING(0, 3)

INT_ECT1_ECT2:
    //comment
{{delimiter.start}}{}{{delimiter.end}} == {{delimiter.start}}{}{{delimiter.end}} //comment
""".format(CT_SIG, INT_ECT_SIG, CT_SIG, INT_ECT_SIG)

INT_ECT_NOT_TC = """
CT1:
{{delimiter.start}}{}{{delimiter.end}} == 1

CT2:
{{delimiter.start}}{}{{delimiter.end}} == 3

INT_ECT1_ECT2:
{{delimiter.start}}{}{{delimiter.end}} != {{delimiter.start}}{}{{delimiter.end}}
""".format(CT_SIG, INT_ECT_SIG, CT_SIG, INT_ECT_NOT_SIG)

class TestFunction_TRIGGERS(unittest.TestCase):

    __name__ = 'TestFunction_TRIGGERS'


    # INT_ECT
    def test_int_ect(self):
        tc = Testcase(INT_ECT_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)


    def test_inc_ect_not(self):
        tc = Testcase(INT_ECT_NOT_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
