# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    SMALL_SIG,
    TIME_TOLERANCE_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters


# TIME_TOLERANCE
TIME_TOLERANCE_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
{{delimiter.start}}{}{{delimiter.end}} == {{delimiter.start}}{}{{delimiter.end}} delay 0ms;SUM(-20, 35)ms tolerance 3
""".format(SMALL_SIG, TIME_TOLERANCE_SIG)

TIME_TOLERANCE_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
{{delimiter.start}}{}{{delimiter.end}} == {{delimiter.start}}{}{{delimiter.end}}  delay PROD({{delimiter.start}}{}{{delimiter.end}}, 67, 0)ms;14ms tolerance 3
""".format(SMALL_SIG, TIME_TOLERANCE_SIG, SMALL_SIG)


class TestFunction_TIME_TOLERANCE(unittest.TestCase):

    __name__ = 'TestFunction_TIME_TOLERANCE'


    # TIME_TOLERANCE
    def test_time_tolerance(self):
        tc = Testcase(TIME_TOLERANCE_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    @unittest.skip
    def test_time_tolerance_neg(self):
        tc = Testcase(TIME_TOLERANCE_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
