# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INTEGER_SIG_NAME
)

from evaluate.core import Testcase, Verdict, Delimiters


# VALUELIST
VALUELIST_TC = """
T1:
start_of_measurement

T2:
9205.52ms

INT_ET1_ET2:
VALUELIST({{delimiter.start}}{}{{delimiter.end}},1,5) == 1
""".format(INTEGER_SIG_NAME)

VALUELIST_TC_NEG = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
VALUELIST({{delimiter.start}}{}{{delimiter.end}},1,5) == 1
""".format(INTEGER_SIG_NAME)


class TestFunction_VALUELIST(unittest.TestCase):

    __name__ = 'TestFunction_VALUELIST'


    # VALUELIST
    def test_valuelist(self):
        tc = Testcase(VALUELIST_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_valuelist_neg(self):
        tc = Testcase(VALUELIST_TC_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
