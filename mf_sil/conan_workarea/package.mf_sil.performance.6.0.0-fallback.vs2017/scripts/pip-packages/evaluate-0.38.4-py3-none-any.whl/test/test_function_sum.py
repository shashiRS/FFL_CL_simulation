# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    RANDOM_SIG_0_100,
    SUM_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters

# SUM
SUM_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
SUM({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, SUM_SIG)

SUM_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
SUM({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, RANDOM_SIG_0_100)

SUM_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
SUM({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, SUM_SIG)

SUM_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
SUM({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, RANDOM_SIG_0_100)


class TestFunction_SUM(unittest.TestCase):

    __name__ = 'TestFunction_SUM'


    # SUM
    def test_sum(self):
        tc = Testcase(SUM_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sum_neg(self):
        tc = Testcase(SUM_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_sum_interval(self):
        tc = Testcase(SUM_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sum_neg_interval(self):
        tc = Testcase(SUM_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
