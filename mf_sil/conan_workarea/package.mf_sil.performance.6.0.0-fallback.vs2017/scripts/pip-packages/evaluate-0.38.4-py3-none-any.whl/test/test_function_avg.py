# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    csv_path,
    sigs,
    FLOAT_SIG_NAME_1,
    FLOAT_SIG_NAME_2,
    CONST_1000
)

from test.utils import get_signal_data, save_html_report
from evaluate.core import Testcase, Verdict, Delimiters


# AVG
AVG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 27 tolerance 1
""".format(FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2)

# negative
NEGATE_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
NOT AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 27 tolerance 1
""".format(FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2)

AVG_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 1000000ns tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay {{delimiter.start}}CONST_1000{{delimiter.end}}us tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 1ms tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 0.001s tolerance 0.1
""".format(
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2)

NEGATE_TC_NEG = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
NOT (AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 1000000ns tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay {{delimiter.start}}CONST_1000{{delimiter.end}}us tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 1ms tolerance 0.1
AND AVG({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 25 delay 0.001s tolerance 0.1)
""".format(
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2,
    FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2)



class TestFunction_AVG(unittest.TestCase):

    __name__ = 'TestFunction_AVG'

    # AVG
    def test_avg(self):
        # Get a signal with negative and positive values
        local_sigs = get_signal_data(
            csv_path,
            [FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2]
        )
        # Get Test case object
        tc = Testcase(AVG_TC.format(delimiter=Delimiters), local_sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

        #  save html report
        tc.id = 'test_avg'
        save_html_report(tc, local_sigs)

    def test_avg_neg(self):
        # Get a signal with negative and positive values
        local_sigs = get_signal_data(
            csv_path,
            [FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2, CONST_1000]
        )
        # Get Test case object
        tc = Testcase(AVG_NEG_TC.format(delimiter=Delimiters), local_sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

        #  save html report
        tc.id = 'test_avg_neg'
        save_html_report(tc, local_sigs)

    def test_negate_avg(self):
        tc = Testcase(NEGATE_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_negate_avg_neg(self):
         # Get a signal with negative and positive values
        local_sigs = get_signal_data(
            csv_path,
            [FLOAT_SIG_NAME_1, FLOAT_SIG_NAME_2, CONST_1000]
        )
        # Get Test case object
        tc = Testcase(NEGATE_TC_NEG.format(delimiter=Delimiters), local_sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

        #  save html report
        tc.id = 'test_negate_avg_neg'
        save_html_report(tc, local_sigs)
