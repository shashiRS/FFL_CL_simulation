# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    DECREMENT_SIG,
    MINIM_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# MINIM
MINIM_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MINIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == 1
""".format(INCREMENT_SIG, DECREMENT_SIG)

MINIM_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MINIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) != 1
""".format(INCREMENT_SIG, DECREMENT_SIG)

MINIM_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MINIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, DECREMENT_SIG, MINIM_SIG)

MINIM_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MINIM({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}) != 1
""".format(INCREMENT_SIG, DECREMENT_SIG)


class TestFunction_MINIM(unittest.TestCase):

    __name__ = 'TestFunction_MINIM'


    # MINIM
    def test_minim(self):
        tc = Testcase(MINIM_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_minim_neg(self):
        tc = Testcase(MINIM_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_minim_interval(self):
        tc = Testcase(MINIM_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_minim_neg_interval(self):
        tc = Testcase(MINIM_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
