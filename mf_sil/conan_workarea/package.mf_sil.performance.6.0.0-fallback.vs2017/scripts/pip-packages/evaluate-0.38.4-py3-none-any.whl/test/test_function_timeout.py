# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
)

from evaluate.core import Testcase, Verdict, Delimiters

# TIMEOUT
TIMEOUT_TC_POS = """
T1:
TIMEOUT({{delimiter.start}}TIMEOUT{{delimiter.end}})  >= 100
ET1:
{{delimiter.start}}TIMEOUT{{delimiter.end}} == 110 delay 103ms
""".format(None)

TIMEOUT_TC_NEG = """
T1:
TIMEOUT({{delimiter.start}}TIMEOUT{{delimiter.end}})  >= 100
ET1:
{{delimiter.start}}TIMEOUT{{delimiter.end}} == 110 delay 102ms
""".format(None)


class TestFunction_TIMEOUT(unittest.TestCase):

    __name__ = 'TestFunction_TIMEOUT'


    # TIMEOUT
    def test_valuelist(self):
        tc = Testcase(TIMEOUT_TC_POS.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    # TIMEOUT
    def test_valuelist(self):
        tc = Testcase(TIMEOUT_TC_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
