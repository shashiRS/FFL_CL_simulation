# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    MAXIM_SIG,
    MINIM_SIG,
    POW_SIG,
    SMALL_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# SMALL
SMALL_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
SMALL({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) == 29
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, SMALL_SIG)

SMALL_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
SMALL({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) != 29
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, SMALL_SIG)

SMALL_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
SMALL({{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, {{delimiter.start}}{}{{delimiter.end}}, 2) == {{delimiter.start}}{}{{delimiter.end}}
""".format(MAXIM_SIG, MINIM_SIG, POW_SIG, SMALL_SIG)


class TestFunction_SMALL(unittest.TestCase):

    __name__ = 'TestFunction_SMALL'


    # SMALL
    def test_small(self):
        tc = Testcase(SMALL_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
    def test_small_neg(self):
        tc = Testcase(SMALL_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
    def test_small_interval(self):
        tc = Testcase(SMALL_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
