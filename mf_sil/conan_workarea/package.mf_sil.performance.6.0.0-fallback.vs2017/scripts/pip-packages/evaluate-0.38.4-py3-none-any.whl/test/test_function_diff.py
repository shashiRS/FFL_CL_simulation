# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    DIFF_SIG,
    INCREMENT_SIG,
    RANDOM_SIG_0_100,

)

from evaluate.core import Testcase, Verdict, Delimiters


# DIFF
DIFF_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
DIFF({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}

INT_ET1_ET2
AND {{delimiter.start}}{}{{delimiter.end}} == 10 once
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, -25, INCREMENT_SIG)

DIFF_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
DIFF({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, RANDOM_SIG_0_100)

DIFF_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
DIFF({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000000000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, DIFF_SIG)

DIFF_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
DIFF({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, RANDOM_SIG_0_100)


class TestFunction_DIFF(unittest.TestCase):

    __name__ = 'TestFunction_DIFF'

    # DIFF
    def test_diff(self):
        tc = Testcase(DIFF_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_diff_neg(self):
        tc = Testcase(DIFF_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_diff_interval(self):
        tc = Testcase(DIFF_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_diff_neg_interval(self):
        tc = Testcase(DIFF_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
