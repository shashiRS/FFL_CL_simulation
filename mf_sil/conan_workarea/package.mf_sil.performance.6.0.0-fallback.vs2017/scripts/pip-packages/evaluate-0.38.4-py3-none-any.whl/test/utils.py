#!/usr/bin/env python
import os
import csv
import numpy as np
from report import HTMLReport

from evaluate.core import Signal


def get_test_data(filename=""):
    """
    Utility functions needed by all test scripts.
    """
    return os.path.dirname(__file__) + "/data/" + filename


def get_signal_data(csv_path=None, lst_name=None):
    """get_signal_data

    The method will return measurement data necessary for the evaluation method

    Parameters
    ----------
    lst_name : list
        list with signals to be extracted from csv file
    csv_path : str
        the path to the csv file

    Returns
    -------
    s_data : dict
        dictionary with sigs.
    """
    c_reader = csv.DictReader(open(csv_path))
    s_data = {}
    s = {}
    t = {}
    for sig in lst_name:
        s[sig] = []
        t[sig] = []

    for row in c_reader:
        for sig in lst_name:
            if row[sig] \
                and set(row[sig].replace('.', '', 1).replace('-','',1)).issubset(set('xXABCDEFabcdef0123456789')):

                if "." in row[sig]:
                    s[sig].append(np.float64(row[sig]))
                else:
                    try:

                        s[sig].append(np.int64(row[sig]))
                    except:
                        s[sig].append(np.uint64(int(row[sig], base=16)))
                t[sig].append(float(row["Time_"+sig]))
            else:
                #print("!!Skipped data:", row[sig], row["Time_"+sig])
                pass
    for sig in lst_name:
        s_data[sig] = Signal(np.array(s[sig]), np.array(t[sig]), None, sig)
    return s_data

def save_html_report(test_case, sigs, output_dir=''):
    if not output_dir:
        output_dir = os.path.join('html', test_case.id)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

    html_report = HTMLReport(
        title=str(test_case.id),
        default_graph=True,
        display_log=False,
        output_dir=output_dir
    )

    html_report.append(test_case, str(sigs))
    html_report.save()
