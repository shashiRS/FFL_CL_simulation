# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters


# MAX
MAX_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MAX({{delimiter.start}}{}{{delimiter.end}}) == 29
""".format(INCREMENT_SIG)

NP_MAX_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
NP_amax({{delimiter.start}}{}{{delimiter.end}}) == 29
""".format(INCREMENT_SIG)

MAX_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MAX({{delimiter.start}}{}{{delimiter.end}}) != 29
""".format(INCREMENT_SIG)

MAX_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MAX({{delimiter.start}}{}{{delimiter.end}}) == 29
""".format(INCREMENT_SIG)

MAX_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MAX({{delimiter.start}}{}{{delimiter.end}}) != 29
""".format(INCREMENT_SIG)

class TestFunction_MAX(unittest.TestCase):

    __name__ = 'TestFunction_MAX'


    # MAX
    def test_max(self):
        tc = Testcase(MAX_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_NP_max(self):
        tc = Testcase(NP_MAX_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_max_neg(self):
        tc = Testcase(MAX_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_max_interval(self):
        tc = Testcase(MAX_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_max_neg_interval(self):
        tc = Testcase(MAX_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
