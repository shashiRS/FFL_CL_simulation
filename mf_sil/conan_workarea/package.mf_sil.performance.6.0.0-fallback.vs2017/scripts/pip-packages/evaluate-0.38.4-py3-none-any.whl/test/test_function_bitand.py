# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    SINT_SIG_NAME1,
    INTEGER_SIG_NAME
)
import numpy as np
from evaluate.core import Testcase, Verdict, Delimiters


# BITAND
BITAND_TC = """
T1:
start_of_measurement

T2:
9205520us

INT_ET1_ET2:
BITAND({{delimiter.start}}{}{{delimiter.end}},1) == 1
""".format(INTEGER_SIG_NAME)

BITAND_NEG_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITAND({{delimiter.start}}{}{{delimiter.end}},1) == 0
""".format(INTEGER_SIG_NAME)

# MISSING_signal
MISSING_SIGNAL_TC = """
T1:
start_of_measurement

T2:
9205520us

INT_ET1_ET2:
BITAND({{delimiter.start}}{}{{delimiter.end}},1) == 1
""".format("DoesNotExist")



class TestFunction_BITAND(unittest.TestCase):

    __name__ = 'TestFunction_BITAND'

    # BITAND
    def test_bitand(self):
        tc = Testcase(BITAND_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_bitand_neg(self):
        tc = Testcase(BITAND_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    # BITAND
    def test_missing_signal(self):
        tc = Testcase(MISSING_SIGNAL_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.unknown)
