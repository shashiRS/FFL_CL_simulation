# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INTEGER_SIG_NAME,
    SIGN_SAMPLES,
    SINT_SIG_NAME1,
)

from evaluate.core import Testcase, Verdict, Delimiters

# SIGN
SIGN_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
SIGN({{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INTEGER_SIG_NAME, SIGN_SAMPLES)

SIGN_TC_INT_NEG = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
SIGN({{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(SINT_SIG_NAME1, SIGN_SAMPLES)


class TestFunction_SIGN(unittest.TestCase):

    __name__ = 'TestFunction_SIGN'

    # SIGN
    def test_sign(self):
        tc = Testcase(SIGN_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sign_neg(self):
        tc = Testcase(SIGN_TC_INT_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
