# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    MINIM_SIG,
    DIV_SIG,
    POW_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters

# POW
POW_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
POW({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == 29 tolerance 0.00000000000001
""".format(DIV_SIG, MINIM_SIG)

POW_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
POW({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000000000001
""".format(DIV_SIG, MINIM_SIG, POW_SIG)

POW_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
POW({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.001
""".format(DIV_SIG, MINIM_SIG, POW_SIG)


class TestFunction_POW(unittest.TestCase):

    __name__ = 'TestFunction_POW'


    # POW
    def test_pow(self):
        tc = Testcase(POW_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_pow_neg(self):
        tc = Testcase(POW_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_pow_interval(self):
        tc = Testcase(POW_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
