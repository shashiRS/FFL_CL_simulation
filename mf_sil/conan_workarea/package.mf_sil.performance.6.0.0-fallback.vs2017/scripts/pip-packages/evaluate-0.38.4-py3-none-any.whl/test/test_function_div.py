# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    DIV_SIG,
    MAXIM_SIG,
    MINIM_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# DIV
DIV_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
DIV({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == 29 tolerance 0.00000000000001
""".format(MAXIM_SIG, MINIM_SIG)

DIV_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
DIV({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000000000001
""".format(MAXIM_SIG, MINIM_SIG, DIV_SIG)

DIV_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
DIV({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.001
""".format(MAXIM_SIG, MINIM_SIG, DIV_SIG)



class TestFunction_DIV(unittest.TestCase):

    __name__ = 'TestFunction_DIV'

    # DIV
    def test_div(self):
        tc = Testcase(DIV_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_div_neg(self):
        tc = Testcase(DIV_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_div_interval(self):
        tc = Testcase(DIV_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
