# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    BIT_SIG_1,
    BIT_SIG_2,
    BITXOR_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters

#BITXOR
BITXOR_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
BITXOR({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(BIT_SIG_1,BIT_SIG_2,BITXOR_SIG)

BITXOR_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
BITXOR({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(BIT_SIG_1,BIT_SIG_2,BITXOR_SIG)

BITXOR_TC_INT  = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITXOR({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(BIT_SIG_1,BIT_SIG_2,BITXOR_SIG)

BITXOR_NEG_TC_INT = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITXOR({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(BIT_SIG_1,BIT_SIG_2,BITXOR_SIG)


class TestFunction_BITXOR(unittest.TestCase):

    __name__ = 'TestFunction_BITXOR'

    #BITXOR
    def test_bitxor(self):
        tc = Testcase(BITXOR_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_bitxor_neg(self):
        tc = Testcase(BITXOR_NEG_TC.format(delimiter=Delimiters),sigs)
        a = tc.evaluate()
        self.assertEqual(a[0],Verdict.failed)

    def test_bitxor_int(self):
        tc = Testcase(BITXOR_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_bitxor_int_neg(self):
        tc = Testcase(BITXOR_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
