# -*- coding: utf-8 -*-
import unittest

from test.utils import get_signal_data
from test.test_core import csv_path

from evaluate.core import Testcase, Verdict, Delimiters


WITHIN_POS = """
T1:
{{delimiter.start}}IGN_SWITCH{{delimiter.end}}  == RISING(0, 1)

ET1:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100 within 111000000ns
AND {{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100 within 111000us
AND {{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100 within 111ms
AND {{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100 within 0.111s
""".format(None)

WITHIN_NEG = """
T1:
{{delimiter.start}}IGN_SWITCH{{delimiter.end}}  == RISING(0, 1)

ET1:
{{delimiter.start}}FAIL_RAM_807a{{delimiter.end}}  == 0x100 within 110ms
""".format(None)


class TestTime_WITHIN(unittest.TestCase):

    def test_within_pos(self):
        sigs = get_signal_data(
            csv_path,
            ["IGN_SWITCH", "FAIL_RAM_807a"]
        )
        tc = Testcase(WITHIN_POS.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_within_neg(self):
        sigs = get_signal_data(
            csv_path,
            ["IGN_SWITCH", "FAIL_RAM_807a"]
        )
        tc = Testcase(WITHIN_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

