# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    SINT_SIG_NAME1,
    INTEGER_SIG_NAME,
    INTEGER_SIG_NAME1
)
import numpy as np
from evaluate.core import Testcase, Verdict, Delimiters


# BITOR
BITOR_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITOR({{delimiter.start}}{}{{delimiter.end}}, 1) == 1
""".format(INTEGER_SIG_NAME)

BITOR_NEG_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITOR({{delimiter.start}}{}{{delimiter.end}},1) == 0
""".format(INTEGER_SIG_NAME)

class TestFunction_BITOR(unittest.TestCase):

    __name__ = 'TestFunction_BITOR'


    # BITOR
    def test_bitor(self):
        tc = Testcase(BITOR_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_bitor_neg(self):
        tc = Testcase(BITOR_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
