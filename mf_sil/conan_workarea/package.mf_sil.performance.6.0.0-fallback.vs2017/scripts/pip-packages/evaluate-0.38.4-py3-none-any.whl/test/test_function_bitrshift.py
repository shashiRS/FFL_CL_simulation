# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    SINT_SIG_NAME1,
    INTEGER_SIG_NAME,
    INTEGER_SIG_NAME1
)
import numpy as np
from evaluate.core import Testcase, Verdict, Delimiters


BITLSHIFT_NAME1 = "RefBitLShift"

# BITRSHIFT
BITRSHIFT_CONST_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITRSHIFT({{delimiter.start}}0x80{{delimiter.end}},{{delimiter.start}}1{{delimiter.end}}) == {{delimiter.start}}0x40{{delimiter.end}} //64
""".format(None)

BITRSHIFT_CONST_TC_NEG = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITLSHIFT({{delimiter.start}}0x80{{delimiter.end}},{{delimiter.start}}2{{delimiter.end}}) == {{delimiter.start}}0x40{{delimiter.end}} //64
""".format(None)

BITRSHIFT_SIG_TC = """
T1:
start_of_measurement

T2:
9195ms

INT_ET1_ET2:
BITRSHIFT({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}1{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(INTEGER_SIG_NAME1, BITLSHIFT_NAME1)

BITRSHIFT_T_SIG_TC = """
T1:
start_of_measurement

T2:
9195ms

ET2:
BITRSHIFT({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}1{{delimiter.end}}) == {{delimiter.start}}2{{delimiter.end}}
""".format(INTEGER_SIG_NAME1)


class TestFunction_BITRSHIFT(unittest.TestCase):

    __name__ = 'TestFunction_BITRSHIFT'

    # BITRSHIFT
    def test_const_bitrshift(self):
        tc = Testcase(BITRSHIFT_CONST_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_const_bitrshift_neg(self):
        tc = Testcase(BITRSHIFT_CONST_TC_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_sig_bitrshift(self):
        sigs[BITLSHIFT_NAME1] = sigs[SINT_SIG_NAME1]
        b = np.ones(len(sigs[BITLSHIFT_NAME1].signal), int)*2
        sigs[BITLSHIFT_NAME1].signal = b
        tc = Testcase(BITRSHIFT_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_sig_bitrshift_neg(self):
        sigs[BITLSHIFT_NAME1] = sigs[SINT_SIG_NAME1]
        b = np.ones(len(sigs[BITLSHIFT_NAME1].signal), int)*4
        sigs[BITLSHIFT_NAME1].signal = b
        tc = Testcase(BITRSHIFT_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_sig_t_bitrshift(self):
        tc = Testcase(BITRSHIFT_T_SIG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
