# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    DECREMENT_SIG,
    MAXIM_SIG,
    MINIM_SIG,
    MOD_SIG,
    MOD_SIG_CONST_SIG,
    MOD_CONST_SIG_SIG,
)

from evaluate.core import Testcase, Verdict, Delimiters

# MOD
MOD_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET2:
MOD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == 0
""".format(MAXIM_SIG, MINIM_SIG)

MOD_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MOD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(MAXIM_SIG, MINIM_SIG, MOD_SIG)

MOD_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MOD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.001
""".format(MAXIM_SIG, MINIM_SIG, MOD_SIG)

MOD_SIG_CONST_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MOD({{delimiter.start}}{}{{delimiter.end}}, {}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(MAXIM_SIG, 5, MOD_SIG_CONST_SIG)

MOD_CONST_SIG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MOD({},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}}
""".format(100, MAXIM_SIG, MOD_CONST_SIG_SIG)


MOD_TC_COUNT = """
T1:
{{delimiter.start}}{}{{delimiter.end}} == 2 count 2

ET1:
{{delimiter.start}}{}{{delimiter.end}} == 23
""".format(MOD_SIG, MAXIM_SIG)


class TestFunction_MOD(unittest.TestCase):

    __name__ = 'TestFunction_MOD'


    # MOD
    # MOD(Signal, Signal)
    def test_mod(self):
        tc = Testcase(MOD_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_mod_neg(self):
        tc = Testcase(MOD_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

#    @unittest.skip
    def test_mod_interval(self):
        tc = Testcase(MOD_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    # MOD(Signal, Constant)
    def test_mod_sig_const_interval(self):
        tc = Testcase(MOD_SIG_CONST_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    # MOD(Constant, Signal)
#    @unittest.skip
    def test_mod_const_sig_interval(self):
        tc = Testcase(MOD_CONST_SIG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    # MOD with Count
    def test_count(self):
        tc = Testcase(MOD_TC_COUNT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
