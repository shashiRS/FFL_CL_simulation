# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    CYCLE_TIME_SIG,
    INTEGER_SIG_NAME,
)

from evaluate.core import Testcase, Verdict, Delimiters


# CHECK_CYCLE_TIME
CT_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance NP_multiply(0.01, {{delimiter.start}}{}{{delimiter.end}})
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(INTEGER_SIG_NAME, CYCLE_TIME_SIG, 'CONST_3', INTEGER_SIG_NAME, CYCLE_TIME_SIG)

CT_TC_INT_NEG = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance {{delimiter.start}}CONST_0.01{{delimiter.end}}
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) != {{delimiter.start}}{}{{delimiter.end}}
""".format(INTEGER_SIG_NAME, CYCLE_TIME_SIG, INTEGER_SIG_NAME, CYCLE_TIME_SIG)

CT_TC_ET = """
T1:
start_of_measurement

T2:
9195ms

ET2:
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) == 10.0 tolerance 0.03
CHECK_CYCLE_TIME({{delimiter.start}}{}{{delimiter.end}}) != 10.0
""".format(INTEGER_SIG_NAME, CYCLE_TIME_SIG, INTEGER_SIG_NAME, CYCLE_TIME_SIG)


class TestFunction_CHECK_CYCLE_TIME(unittest.TestCase):

    __name__ = 'TestFunction_CHECK_CYCLE_TIME'

    # CHECK_CYCLE_TIME
    def test_cycle_time_int(self):
        tc = Testcase(CT_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_cycle_time_int_neg(self):
        tc = Testcase(CT_TC_INT_NEG.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_cycle_time_et(self):
        tc = Testcase(CT_TC_ET.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)
