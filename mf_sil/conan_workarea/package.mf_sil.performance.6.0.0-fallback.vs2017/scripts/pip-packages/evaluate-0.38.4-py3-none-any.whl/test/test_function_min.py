# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    DECREMENT_SIG,
    MAXIM_SIG
)

from evaluate.core import Testcase, Verdict, Delimiters

# MIN
MIN_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
MIN({{delimiter.start}}{}{{delimiter.end}}) == 1
""".format(INCREMENT_SIG)

MIN_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
MIN({{delimiter.start}}{}{{delimiter.end}}) != 1
""".format(INCREMENT_SIG)

MIN_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MIN({{delimiter.start}}{}{{delimiter.end}}) == 1
""".format(INCREMENT_SIG)

MIN_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
MIN({{delimiter.start}}{}{{delimiter.end}}) != 1
""".format(INCREMENT_SIG)

class TestFunction_MIN(unittest.TestCase):

    __name__ = 'TestFunction_MIN'


    # MIN
    def test_min(self):
        tc = Testcase(MIN_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_min_neg(self):
        tc = Testcase(MIN_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_min_interval(self):
        tc = Testcase(MIN_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_min_neg_interval(self):
        tc = Testcase(MIN_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
