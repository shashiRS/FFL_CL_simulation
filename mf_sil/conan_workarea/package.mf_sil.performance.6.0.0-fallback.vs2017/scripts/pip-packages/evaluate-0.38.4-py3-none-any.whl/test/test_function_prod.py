# -*- coding: utf-8 -*-
import unittest

from test.test_core import (
    sigs,
    INCREMENT_SIG,
    PROD_SIG,
    RANDOM_SIG_0_100
)

from evaluate.core import Testcase, Verdict, Delimiters

# PROD
PROD_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
PROD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, PROD_SIG)

PROD_NEG_TC = """
T1:
start_of_measurement

T2:
end_of_measurement

ET1:
PROD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, 10000)

PROD_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
PROD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, PROD_SIG)

PROD_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
PROD({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, 10000)

NP_PROD_NEG_TC_INT = """
T1:
start_of_measurement

T2:
end_of_measurement

INT_ET1_ET2:
NP_multiply({{delimiter.start}}{}{{delimiter.end}},{{delimiter.start}}{}{{delimiter.end}}) == {{delimiter.start}}{}{{delimiter.end}} tolerance 0.00000001
""".format(INCREMENT_SIG, RANDOM_SIG_0_100, 10000)


class TestFunction_PROD(unittest.TestCase):

    __name__ = 'TestFunction_PROD'


    # PROD
    def test_prod(self):
        tc = Testcase(PROD_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_prod_neg(self):
        tc = Testcase(PROD_NEG_TC.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_prod_interval(self):
        tc = Testcase(PROD_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.passed)

    def test_prod_neg_interval(self):
        tc = Testcase(PROD_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)

    def test_NP_prod_neg_interval(self):
        tc = Testcase(NP_PROD_NEG_TC_INT.format(delimiter=Delimiters), sigs)
        a = tc.evaluate()
        self.assertEqual(a[0], Verdict.failed)
