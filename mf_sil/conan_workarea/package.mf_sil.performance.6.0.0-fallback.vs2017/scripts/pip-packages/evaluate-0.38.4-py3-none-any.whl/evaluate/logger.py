import os
from time import gmtime, strftime

app_data_path = 'log'
LOG_FOLDER = os.mkdir(app_data_path) if not os.path.exists(app_data_path) else None

LOG_FILE = 'evaluate_{}.log'.format(strftime("%Y-%m-%d_%H-%M-%S", gmtime()))
LOG_FILE = os.path.join(os.getcwd(), app_data_path, LOG_FILE)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'verbose': {
            'format' : "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s",
            'datefmt' : "%Y/%b/%d %H:%M:%S"
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'level': 'INFO',
            #'formatter': 'verbose'
        },
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': LOG_FILE,
            'formatter': 'verbose'
        },
    },
    'loggers': {
        '': {
            'handlers': [
                'file',
                'console'
            ],
            'level': 'DEBUG',
            'propagate': False
        },
        'evaluate': {
            'handlers': [
                'file',
                'console'
            ],
            'level': 'DEBUG',
            'propagate': False
        }
    }
}
