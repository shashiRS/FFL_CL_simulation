''' automated test evaluation framework '''

from time import gmtime, strftime
import os
import sys

import logging
import logging.config

from .version import __version__
from .logger import LOGGING, LOG_FILE

from .core import (
    Condition,
    ConditionGroup,
    Constant,
    Delimiters,
    Evaluator,
    Function,
    Signal,
    Testcase,
    Trigger,
    Verdict,
    EvaluateError
)

from .utils import (
    remove_comments,
    sanitize_string,
    replace_keywords,
    get_signal_dependencies
)

logging.config.dictConfig(LOGGING)

LOGGER = logging.getLogger('evaluate')
LOGGER.setLevel(logging.INFO)

LOGGER.info('\t* Evaluate log file: {}'.format(LOG_FILE))
LOGGER.info('\t* Evaluate package version: {}\n'.format(__version__))


__all__ = [
    'Condition',
    'ConditionGroup',
    'Constant',
    'Delimiters',
    'Evaluator',
    'Function',
    'Signal',
    'Testcase',
    'Trigger',
    'Verdict',
    'EvaluateError',
    'remove_comments',
    'sanitize_string',
    'replace_keywords',
    'get_signal_dependencies',
    '__version__'
]
