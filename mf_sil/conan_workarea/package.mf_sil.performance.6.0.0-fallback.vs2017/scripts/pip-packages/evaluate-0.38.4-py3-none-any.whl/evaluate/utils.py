# -*- coding: utf-8 -*-
"""
Created on Tue May 30 11:13:57 2017

@author: uidn3651
"""

import re
import sys


PYVERSION = sys.version_info[0]
SPACES = r'[ \t]'


def compat_log(string):
    """ enables compatibility between Python 2 and 3 codes for logging.

    In Python 2 StingIO expects an unicode object
    """
    if PYVERSION == 2:
        string = unicode(string)
    return string


def sanitize_string(string, keywords=None):
    """ sanitize_string

    Replica of ``replace_keywords``

    Parameters
    ----------
    string : str
        input string to be parsed
    keywords : dict
        dictionary of keywords

    Returns
    -------
    out : str
        string without keywords

    Examples
    --------
    >>> sanitize_string(string, keywords)
    is the same as
    >>> replace_keywords(string, keywords)
    """
    return replace_keywords(string, keywords)


def replace_keywords(string, keywords=None):
    """ replace_keywords

    Replaces the keywords with the conditions


    Parameters
    ----------
    string : str
        input string to be parsed
    keywords : dict
        dictionary of keywords

    Returns
    -------
    out : str
        string without keywords

    """
    string = remove_comments(string)
    if keywords:
        out = []

        for line in string.splitlines():
            keyword_pattern = r'(?P<pre>.+)?(?i)keyword\SPACES*(?P<keyword>[^ \t\n$]+).*'.replace(r'\SPACES', SPACES)
            m = re.match(keyword_pattern, line)
            if m:
                pre = m.group('pre') if m.group('pre') else ''
                new_lines = replace_keywords(keywords[m.group('keyword')], keywords)
                new_lines = pre + '(' + new_lines + ')'
                out.append(new_lines)
            else:
                out.append(line)
        res = '\n'.join(out)
    else:
        res = string
    return res

def remove_comments(string):
    """ remove_comments

    Removes the comments from the input *string*

    Parameters
    ----------
    string : str
        input string

    Returns
    -------
    new_string : str
        input string with the comments removed

    Examples
    --------
    >>> s = '''T1:  // this is the first trigger
    ... "sInVehicleSpeed" > 100  // Vehicle speed higher than 100km/h'''
    >>> remove_comments(s)
    'T1:\\n"sInVehicleSpeed" > 100'

    """
    new_string = []
    for line in string.splitlines():
        if '//' in line:
            line = line.split('//')
            if line[0].strip():
                new_string.append(line[0].strip())
        else:
            new_string.append(line.strip())

    return '\n'.join(new_string)

def get_signal_dependencies(string, keywords=None, delimiters=None):
    """ get_signal_dependencies

    Parses the `string` for signal names. If the `string` contains keywords, then the keyword definition
    is also parsed.

    Parameters
    ----------
    string : str
        input string to be parsed
    keywords : dict
        dictionary of keywords

    Returns
    -------
    findings : list
        list of signal names strings found

    Examples
    --------
    >>> keywords = {'VehicleMoving': '"sInVehicleSpeed" >= 7'}
    >>> input_string = '''SUM("MotorTemp", "MagnetTemp", 7.0) > 9 delay 100 tolerance 1
    ... AND AVG("MotorSpeed", "RotorSpeed") == 260 tolerance 30
    ... keyword VehicleMoving'''
    >>> get_signal_dependencies(input_string, keywords)
    ['MotorTemp', 'MagnetTemp', 'MotorSpeed', 'RotorSpeed', 'sInVehicleSpeed']

    """
    string = sanitize_string(string, keywords)
    findings = []
    lines = [line for line in string.splitlines() if line.strip()]
    for line in lines:
        title_pattern = r'^\SPACES*((?i)title)'.replace(r'\SPACES', SPACES)
        if re.match(title_pattern, line.strip()):
            continue
        else:
            pattern = r'({0.start}(?P<name>(?!{0.end}).+?){0.end})'.format(delimiters)
            matches = re.finditer(pattern, line)
            for match in matches:
                name = match.group('name')
                if not (name[0] in '-+0123456789' or name.startswith(('RISING', 'FALLING', 'ELEVATION'))):
                    findings.append(name)

    return findings


def xdl_replace(string):

    cmd_map = {
        '?E?': '01A2A3',
        '?F2?': '02A332D7',
        '?I0?': '02A030D2',
        '? 0?': '02A030D2',
    }

    string = cmd_map.get(string, string)

    if string.startswith('?H'):
        if string.endswith('?'):
            payload_len = (len(string) - 3) // 2
        else:
            payload_len = (len(string) - 4) // 2
        replacement = hex(payload_len)[2:4]
        if len(replacement) == 1:
            replacement = '0' + replacement
        string = string.replace('?H', replacement.upper())

    if string.endswith(('3F', '?')):
        if string.endswith('?'):
            size = (len(string) - 1) // 2
        else:
            size = (len(string) - 2) // 2
        values = [
            int('0x{}'.format(string[2*i: 2*i + 2]), 16)
            for i in range(size)
        ]
        checksum = sum(values) & 0xFF

        replacement = hex(checksum)[2:4]
        if len(replacement) == 1:
            replacement = '0' + replacement
        string = string[:2*size] + replacement.upper()

    return string
