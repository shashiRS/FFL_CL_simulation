# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 18:18:26 2016

@author: uidn3651
"""
from __future__ import division, print_function
from itertools import product
from io import StringIO

import logging
import math
import re
import sys

from string import ascii_uppercase
from collections import OrderedDict
from functools import reduce

import numpy as np
import numexpr

from .utils import (
    compat_log,
    get_signal_dependencies,
    remove_comments,
    xdl_replace,
    SPACES,
)

PYVERSION = sys.version_info[0]
LOGGER = logging.getLogger(__name__)


def fullmatch(pattern, string):
    match = re.match(pattern, string)
    if match:
        if match.start() == 0 and match.end() == len(string):
            return match
        else:
            return None
    else:
        return None

AVAILABLE_FUNCTIONS = (
    'NP_',
    'ABS',
    'AVG',
    'BITAND',
    'BITLSHIFT',
    'BITOR',
    'BITRSHIFT',
    'BITXOR',
    'CHECK_CYCLE_TIME',
    'CLIP',
    'DEFINE',
    'DIFF',
    'DIV',
    'EDIFF',
    'GRAD',
    'HYST',
    'INTERP',
    'LARGE',
    'MAX',
    'MAXIM',
    'MIN',
    'MINIM',
    'MOD',
    'POW',
    'PROD',
    'PWM_DUTY',
    'PWM_FREQ',
    'PWM_PERIOD',
    'SEQUENCE',
    'SIGN',
    'SMALL',
    'STR2INT_XDL',
    'STRCMP',
    'STRCMP_XDL',
    'SUM',
    'TIME_SHIFT',
    'TIMEOUT',
    'TRIGGER_INTERVAL',
    'VALUELIST',
)

CONSTANT = 0
SIGNAL = 1
FUNCTION = 2

CONST_TYPE_SCALAR = 0
CONST_TYPE_INTERP_TABLE = 1
CONST_TYPE_COMPLEX = 2
CONST_TYPE_STRING = 3

START_OF_MEASUREMENT = 0   # s
END_OF_MEASUREMENT = 10**9  # s

OPS = {'!=': '__ne__',
       '!': '__ne__',
       '==': '__eq__',
       '>': '__gt__',
       '>=': '__ge__',
       '<': '__lt__',
       '<=': '__le__',
       '': '__eq__',
       'is': '__eq__',
       '&': '__and__',
       '|': '__or__',
       '^': '__xor__',
       '~': '__invert__',
       '<<': '__lshift__',
       '>>': '__rshift__',
       None: '__eq__'}

REVOPS = {'!=': '__ne__',
          '!': '__ne__',
          '==': '__eq__',
          '>': '__lt__',
          '>=': '__le__',
          '<': '__gt__',
          '<=': '__ge__',
          'is': '__eq__',
          '': '__eq__',
          '&': '__and__',
          '|': '__or__',
          '^': '__xor__',
          '~': '__invert__',
          '<<': '__lshift__',
          '>>': '__rshift__',
          None: '__eq__'}


def parse_item(string, signals, user_signals):
    string = string.strip(' \t')

    if string[0] in '+-':
        sign = string[0]
        string = string[1:].strip(' \t')
    else:
        sign = ''

    if string.startswith(Delimiters.start):
        start_size, end_size = len(Delimiters.start), len(Delimiters.end)
        end_pos = string[start_size:].index(Delimiters.end) + start_size
        unit = string[end_pos + end_size:].strip(' \t')
        string = string[start_size: end_pos].strip(' \t')

        if string[0] in '0123456789|':
            item = Constant(sign + string)
        else:
            if string.startswith('__'):
                if string not in user_signals:
                    user_signals[string] = Signal(
                        [],
                        [],
                        name=string,
                        sign=sign,
                    )
                sig = user_signals[string]
            else:
                if string not in signals:
                    sig = None
                    sign = ''
                else:
                    sig = signals[string]
            if sign == '-':
                item = -sig
            else:
                item = sig

    else:
        if string.startswith(AVAILABLE_FUNCTIONS):
            start = string.index('(')
            end_ = start

            while True:
                try:
                    end = string[end_:].index(')')
                    end_ += end + 1
                except:
                    break

            unit = string[end_:].strip(' \t')

            item = Function(
                string[:end_],
                signals,
                user_signals=user_signals,
                sign=sign,
            )
        else:
            item = Constant(sign + string)
            unit = item.unit

    if unit:
        item.unit = unit

    return item


def to_seconds(value, unit=None):
    """ convert value to seconds based on its unit

    Converts value into time units


    Parameters
    ----------
    value : float
        input time to be converted
    unit : str
        time units used for conversion like ``ns``, ``us``, ``ms``, ``s``

    Returns
    -------
    out : float
        time converted to seconds depending on the provided time unit


    """
    if isinstance(value, Constant):
        unit = value.unit
        value = value.x
    elif isinstance(value, Signal):
        unit = value.unit
        value = value.signal[0]

    if unit in ('', 'ms', None):
        result = value * 10**-3
    elif unit == 'us':
        result = value * 10**-6
    elif unit == 'ns':
        result = value * 10**-9
    else:
        result = value

    return result

def ups_downs(y):
    """Detect when the direction of y crosses 0
    Taken from here:
    https://codereview.stackexchange.com/questions/185535/applying-hysteresis-to-a-signal
    """

    try:
        summed = np.cumsum(y)
        d = np.sign(np.diff(summed))
        ud = np.flatnonzero(d)
        uds = d[ud]
        change = ud[np.r_[True, uds[1:] != uds[:-1]]]

        out = np.zeros(len(summed), dtype=int)

        out[1:][change] = d[change]
    except IndexError:
        out = y
    return out

class Result:
    """ this object holds together the condition evalaution findings

    Attributes
    ----------
    idx : numpy.ndarray
        indexes where the evaluation was passed
    lval : Signal | Constant
        the Condition's left operand
    rval : Signal | Constant
        the Condition's right operand
    tolerance : Signal | Constant
        the Condition's tolerance
    op : str
        the Condition's operator

    """

    def __init__(self, idx, lval, rval, tolerance, op):

        self.idx = idx
        self.lval = lval
        self.rval = rval
        self.tolerance = tolerance
        self.op = op

    def time_stamps(self):
        """ get all timestamps where the evaluation is passed

        Returns
        -------
        timestamps : numpy.ndarray

        """
        if isinstance(self.lval, Signal):
            return self.lval.time[self.idx]
        elif isinstance(self.rval, Signal):
            return self.rval.time[self.idx]
        else:
            if isinstance(self.tolerance, Signal):
                return self.tolerance.time[self.idx]
            else:
                return self.idx

    def time_intervals(self):
        """ get all time intervals where the result is passed

        Returns
        -------
        intervals : list
            list of [start, stop] inclusive intervals

        """

        intervals = []

        if len(self.idx):
            start = stop = self.idx[0]
            index = 0
            dim = len(self.idx)

            while True:
                current = self.idx[index]
                if current - stop <= 1:
                    stop = current
                    index += 1
                    if index >= dim:
                        intervals.append((start, stop))
                        break
                else:
                    intervals.append((start, stop))
                    start = stop = current
                    index += 1
                    if index >= dim:
                        intervals.append((current, current))
                        break

        if isinstance(self.lval, Signal):
            timestamps = self.lval.time
        elif isinstance(self.rval, Signal):
            timestamps = self.rval.time
        elif isinstance(self.tolerance, Signal):
            timestamps = self.tolerance.time
        else:
            raise Exception("Can't get result intervals for all constants results")
            intervals = []

        intervals = [
            (timestamps[start], timestamps[stop])
            for start, stop in intervals
        ]

        return intervals

    def failed_timestamps(self):
        """ get all timestamps where the evalaution is failed

        Returns
        -------
        timestamps : numpy.ndarray

        """
        if isinstance(self.lval, Signal):
            failed_timestamps = np.setdiff1d(
                np.arange(len(self.lval)),
                self.idx,
            )
            failed_timestamps = self.lval.time[failed_timestamps]
        elif isinstance(self.rval, Signal):
            failed_timestamps = np.setdiff1d(
                np.arange(len(self.rval)),
                self.idx,
            )
            failed_timestamps = self.rval.time[failed_timestamps]
        else:
            if isinstance(self.tolerance, Signal):
                failed_timestamps = np.setdiff1d(
                    np.arange(len(self.tolerance)),
                    self.idx,
                )
                failed_timestamps = self.tolerance.time[failed_timestamps]
            else:
                if len(self.idx):
                    failed_timestamps = np.array([])
                else:
                    failed_timestamps = self.idx
        return failed_timestamps

    def first_failed(self):
        """ get a string reprezentaion of the first failed event

        Returns
        -------
        first_failure : str

        """
        if isinstance(self.lval, Signal):
            failed_index = np.setdiff1d(
                np.arange(len(self.lval)),
                self.idx,
            )
            if len(failed_index):
                failed_index = failed_index[0]
                timestamp = '{}s'.format(
                    round(
                        float(self.lval.time[failed_index]),
                        6,
                    )
                )
            else:
                return ''
        elif isinstance(self.rval, Signal):
            failed_index = np.setdiff1d(
                np.arange(len(self.rval)),
                self.idx,
            )
            if len(failed_index):
                failed_index = failed_index[0]
                timestamp = '{}s'.format(
                    round(
                        float(self.rval.time[failed_index]),
                        6,
                    )
                )
            else:
                return ''
        else:
            if isinstance(self.tolerance, Signal):
                failed_index = np.setdiff1d(
                    np.arange(len(self.tolerance)),
                    self.idx,
                )
                if len(failed_index):
                    failed_index = failed_index[0]
                    timestamp = '{}s'.format(
                        round(
                            float(self.tolerance.time[failed_index]),
                            6,
                        )
                    )
                else:
                    return ''
            else:
                if len(self.idx):
                    return ''
                else:
                    failed_index = 0
                    timestamp = 'all constants'

        if isinstance(self.lval, Signal):
            lval = self.lval.signal[failed_index]
        else:
            if self.lval.const_type in (CONST_TYPE_SCALAR, CONST_TYPE_STRING):
                lval = self.lval.x
            else:
                lval = '{}({}{}, {}{})'.format(
                    self.lval.edge,
                    self.lval.op1 or '',
                    self.lval.val1,
                    self.lval.op2 or '',
                    self.lval.val2,
                )

        if isinstance(self.rval, Signal):
            rval = self.rval.signal[failed_index]
        else:
            if self.rval.const_type in (CONST_TYPE_SCALAR, CONST_TYPE_STRING):
                rval = self.rval.x
            else:
                rval = '{}({}{}, {}{})'.format(
                    self.rval.edge,
                    self.rval.op1,
                    self.rval.val1,
                    self.rval.op2,
                    self.rval.val2,
                )

        if isinstance(self.tolerance, Signal):
            tolerance = self.tolerance.signal[failed_index]
        else:
            tolerance = self.tolerance.x

        return "{} {} {} tolerance {} @{}".format(
            lval,
            self.op,
            rval,
            tolerance,
            timestamp,
        )

    def __repr__(self):
        failed_timestamps = self.failed_timestamps()

        if len(failed_timestamps) == 0:
            failed_timestamps = "None"

        return  """Condition result:
\tLVAL = {}
\tOP {}
\tRVAL = {}
\tTOLERANCE = {}
\tFAILED = {}"""\
    .format(
        self.lval,
        self.op,
        self.rval,
        self.tolerance,
        failed_timestamps,
    )

    def negate(self):
        if isinstance(self.lval, Signal):
            inv = np.arange(len(self.lval.time), dtype=self.idx.dtype)
            inv = np.setdiff1d(inv, self.idx, assume_unique=True)

            result = Result(
                idx=inv,
                lval=self.lval,
                rval=self.rval,
                tolerance=self.tolerance,
                op=self.op,
            )
        elif isinstance(self.rval, Signal):
            inv = np.arange(len(self.rval.time), dtype=self.idx.dtype)
            inv = np.setdiff1d(inv, self.idx, assume_unique=True)

            result = Result(
                idx=inv,
                lval=self.lval,
                rval=self.rval,
                tolerance=self.tolerance,
                op=self.op,
            )
        else:
            if isinstance(self.tolerance, Signal):
                inv = np.arange(len(self.tolerance.time), dtype=self.idx.dtype)
                inv = np.setdiff1d(inv, self.idx, assume_unique=True)

                result = Result(
                    idx=inv,
                    lval=self.lval,
                    rval=self.rval,
                    tolerance=self.tolerance,
                    op=self.op,
                )
            else:
                if len(self.idx):
                    result = Result(
                        np.array([]),
                        self.lval,
                        self.rval,
                        self.tolerance,
                        self.op,
                    )
                else:
                    result = Result(
                        np.array([0, ]),
                        self.lval,
                        self.rval,
                        self.tolerance,
                        self.op,
                    )

        return result

    def timebase(self):
        if isinstance(self.lval, Signal):
            result = self.lval.time
        elif isinstance(self.rval, Signal):
            result = self.rval.time
        else:
            if isinstance(self.tolerance, Signal):
                result = self.tolerance.time
            else:
                result = np.array([0])

        return result


class Delimiters:
    """ delimiters for replaced Signals and Constants

    Delimiters are use to register the start and end separator needed to extract objects like ``Signal``, ``Constant``

    Even if is not recommended you can use also special characters like ``?``, ``.``, ``(``, ``)``


    Attributes
    ----------
    start : str default='"'
        start delimiter
    end : str default='"'
        end delimiter


    Examples
    --------
    >>> Delimiter.set(['{{', '}}'])  # {{Signal1}}, {{Constant1}}
    >>> Delimiter.set(['"', '"'])    # "Signal1", "Constant1", '"' this is default separator value for start and end
    >>> Delimiter.set(['||', '|'])   # ||Signal1|, ||Constant|

    """
    start = '"'
    end = '"'

    @classmethod
    def set(cls, delims):
        cls.set_start(delims[0])
        cls.set_end(delims[1])

    @classmethod
    def set_start(cls, value):
        """ set start delimiter

        Parameters
        ----------
        value : str
            delimiter string; can have multiple characters

        """
        delimiter = ''
        for val in value:
            if val in '?+.*()':
                delimiter += '\\'
            delimiter += val
        cls.start = delimiter

    @classmethod
    def set_end(cls, value):
        """ set end delimiter

        Parameters
        ----------
        value : str
            delimiter string; can have multiple characters

        """
        delimiter = ''
        for val in value:
            if val in '?+.*()':
                delimiter += '\\'
            delimiter += val
        cls.end = delimiter


class Verdict:
    '''Enumeration used for the verdicts. The options are:
       unknown(0), failed(-1) and passed(1).

    '''
    unknown = 0
    failed = -1
    passed = 1

    @staticmethod
    def to_string(value):
        if value == Verdict.unknown:
            string = 'UNKNOWN'
        elif value == Verdict.failed:
            string = 'FAILED'
        elif value == Verdict.passed:
            string = 'PASSED'
        else:
            raise EvaluateError('Invalid Verdict value {}'.format(value))
        return string


class EvaluateError(Exception):
    """EvaluateError

    Custom exception for the Evaluation package
    """
    pass


class Trigger:
    """Trigger

    The trigger is an event inside the measurement defined using conditions.
    The trigger's timestamp is further used for the evaluation of the testcase.

    Parameters
    ----------
    string : str
        'Expected Test Results' column string that has to be parsed for trigger
         definitions
    signals : dict
        Dictionary of Signals loaded from the measurement file
    name : str
        trigger name

    Attributes
    ----------
    string : str
        trigger definition
    timestamp : float
        timestamp obtained after the evaluation of the trigger's conditions
    condition_group : utils.ConditionGroup
        top level condition group
    relative_trigger : str
        name of the relative trigger, if it exist
    ops : list
        list of operations in case of relative trigger
    operands : list
        list of operands in case if relative trigger


    """
    def __init__(self, string, signals, name='', comment=None, cumulative=False, user_signals=None):
        self.name = name
        self.full_string = string
        self.string = remove_comments(string)
        string = remove_comments(string)
        self.timestamp = None
        self.relative_trigger = None
        self.ops = []
        self.operands = []
        self.condition_group = None
        self.cumulative = cumulative
        self.user_signals = user_signals
        self.comment = comment
        self.use_previous_sample = False
        self.missing_signals = False

        if comment:
            comment = comment.strip()
            if not comment.startswith('//'):
                comment = ''
        else:
            comment = ''
        self.comment = comment

        lines = string.splitlines()

        # check if it's a special trigger for start or end of measurement
        if 'START_OF_MEASUREMENT' in lines[0].upper():
            first_stamps = [
                signal.time[0]
                for signal in signals.values()
                if len(signal)
            ]
            if first_stamps:
                self.timestamp = np.float32(min(first_stamps))
            else:
                self.timestamp = None
            string = '\n'.join(lines[1:])
            if string:
                self.condition_group = ConditionGroup(
                    string,
                    signals,
                    user_signals=self.user_signals,
                )
                self.condition_group.store(self.timestamp)
        elif 'END_OF_MEASUREMENT' in lines[0].upper():
            last_stamps = [
                signal.time[-1]
                for signal in signals.values()
                if len(signal)
            ]
            if last_stamps:
                self.timestamp = np.float32(max(last_stamps))
            else:
                self.timestamp = None

            string = '\n'.join(lines[1:])
            if string:
                self.condition_group = ConditionGroup(
                    string,
                    signals,
                    user_signals=self.user_signals,
                )
                self.condition_group.store(self.timestamp)

        # relative trigger
        elif lines[0].strip().startswith('T') and lines[0].strip()[1] in '0123456789':
            if self.cumulative is False:
                # regex the operators and operands in case of a relative trigger
                pattern = r'\SPACES*(?P<rel_trigger>T[0-9]+)(?P<args>.*)'.replace('\SPACES', SPACES)
                matches = re.finditer(pattern, lines[0])
                # each operand must be a constant
                for match in matches:
                    self.relative_trigger = match.group('rel_trigger')
                    args = match.group('args')
                pattern = (r'\SPACES*(?P<op>\+|-|\*|\/)'                   # operator
                           r'\SPACES*'
                           r'('
                           r'{0.start}(?P<operand_param>(?!{0.end}).+){0.end}'             # "signal/constant"
                           r'|'                                            # or
                           r'(?P<operand_adhoc>[^,><=+/\-*\n]+)'           # adhoc operand
                           r')'
                           r'\SPACES*').format(Delimiters).replace('\SPACES', SPACES)
                matches = re.finditer(pattern, args)
                # each operand must be a constant
                for match in matches:
                    self.ops.append(match.group('op'))
                    if match.group('operand_param'):
                        self.operands.append(Constant(match.group('operand_param')))
                    else:
                        self.operands.append(Constant(match.group('operand_adhoc')))
                string = '\n'.join(lines[1:])
                if string:
                    self.condition_group = ConditionGroup(
                        string,
                        signals,
                        user_signals=self.user_signals,
                    )
                    self.missing_signals = self.condition_group.missing_signals
                    self.condition_group.store(self.timestamp)

            else:
                pattern = r'\SPACES*(?P<rel_trigger>T[0-9]+)(?P<args>.*)'.replace(
                    '\SPACES', SPACES)
                match = fullmatch(pattern, lines[0])
                relative_trigger = match.group('rel_trigger')
                message = (
                    'Cumulative trigger {} is defined as a relative trigger. The '
                    'relative trigger should be a cumulative trigger as well, but'
                    '{} simple trigger was found'
                )
                raise EvaluateError(
                    message.format(self.name, relative_trigger)
                )

        # cumulative relative trigger
        elif lines[0].strip().startswith('CT'):

            if self.cumulative is True:
                # regex the operators and operands in case of a relative trigger
                pattern = r'\SPACES*(?P<rel_trigger>CT[0-9]+)(?P<args>.*)'.replace('\SPACES', SPACES)
                matches = re.finditer(pattern, lines[0])
                # each operand must be a constant
                for match in matches:
                    self.relative_trigger = match.group('rel_trigger')
                    args = match.group('args')
                pattern = (r'\SPACES*(?P<op>\+|-|\*|\/)'                   # operator
                           r'\SPACES*'
                           r'('
                           r'{0.start}(?P<operand_param>(?!{0.end}).+){0.end}'            # "signal/constant"
                           r'|'                                            # or
                           r'(?P<operand_adhoc>[^,><=+/\-*\n]+)'           # adhoc operand
                           r')'
                           r'\SPACES*').format(Delimiters).replace('\SPACES', SPACES)
                matches = re.finditer(pattern, args)
                # each operand must be a constant
                for match in matches:
                    self.ops.append(match.group('op'))
                    if match.group('operand_param'):
                        self.operands.append(Constant(match.group('operand_param')))
                    else:
                        self.operands.append(Constant(match.group('operand_adhoc')))

                string = '\n'.join(lines[1:])
                if string:
                    self.condition_group = ConditionGroup(
                        string,
                        signals,
                        user_signals=self.user_signals,
                    )
                    self.missing_signals = self.condition_group.missing_signals
                    self.condition_group.store(self.timestamp)

            else:
                pattern = r'\SPACES*(?P<rel_trigger>CT[0-9]+)(?P<args>.*)'.replace(
                    '\SPACES', SPACES)
                match = fullmatch(pattern, lines[0])
                relative_trigger = match.group('rel_trigger')
                message = (
                    'Simple trigger {} is defined as a relative trigger. The '
                    'relative trigger should be a simple trigger as well, but'
                    '{} cumulative trigger was found'
                )
                raise EvaluateError(
                    message.format(self.name, relative_trigger)
                )

        else:
            if 'use_previous_sample' in lines[0].lower():
                self.use_previous_sample = True
                lines.pop(0)
            if self.cumulative is False:
                # direct timestamp input
                pattern = (r'^\SPACES*'
                           r'('                                    # parameters can be
                           r'{0.start}(?P<operand_param>(?!{0.end}).+?){0.end}'       # "xxx" replaced values
                           r'\SPACES*'
                           r'|'                                    # or
                           r'(?P<operand_adhoc>[^,><= \n]+)?'       # adhoc values
                           r'\SPACES*'
                           r')').format(Delimiters).replace('\SPACES', SPACES)

                match = fullmatch(pattern, lines[0])
                if match:
                    if match.group('operand_param'):
                        timestamp = Constant(match.group('operand_param'))
                    elif match.group('operand_adhoc'):
                        timestamp = Constant(match.group('operand_adhoc'))
                    self.timestamp = to_seconds(timestamp.x, timestamp.unit)

                else:

                    string = '\n'.join(lines)
                    if string:
                        self.condition_group = ConditionGroup(
                            string,
                            signals,
                            user_signals=self.user_signals,
                        )
                        self.missing_signals = self.condition_group.missing_signals
                        if not self.missing_signals:
                            self.condition_group.store(self.timestamp)

            # the last possibility is to have a ConditionGroup
            if self.timestamp is None:
                # for simple conditions append the condition
                self.condition_group = ConditionGroup(string, signals, user_signals=self.user_signals)
                self.missing_signals = self.condition_group.missing_signals

    def __str__(self):
        return \
            'Trigger {{ '\
            'timestamp={}'\
            '\trelative trigger={}'\
            '\toperands={}'\
            '\tops={}'\
            '\tuse_previous_sample={}'\
            '\tcondition group={} '\
            '}}'\
                .format(
                    self.timestamp,
                    self.relative_trigger,
                    self.operands,
                    self.ops,
                    self.use_previous_sample,
                    self.condition_group
                )

    def evaluate(self, start=0, relative_timestamp=0, stop=0, limits=()):
        """evaluate

        Start the trigger's timestamp evaluation.

        Parameters
        ----------
        start : float
            Starting time value from which the trigger's conditions are evaluated; default 0 (START_OF_MEASUREMENT)
        relative_timestamp : float
            Time delta; default 0. Use this in case of relative trigger
        stop : float
            stop timestamp
        limits : tuple
            valid time stamp range

        Returns
        -------
        timestamp: float
            the computed timestamp

        """

        LOGGER.info(compat_log(''))
        LOGGER.info(compat_log('{: <60}'.format('{}:'.format(self.name))))
        if self.comment:
            LOGGER.info(compat_log('{: <60}'.format(self.comment)))
        LOGGER.info(compat_log(self.full_string))
        if self.condition_group:
            LOGGER.info(compat_log(''))

        if self.missing_signals:
            LOGGER.info(compat_log('{: <20}{}'.format('{}'.format(self.name), 'not available due to missing signals')))
        else:

            out_of_limits = False
            partial_detection = False

            if self.timestamp is None and relative_timestamp is not None:

                if limits:
                    first_stamp, last_stamp = limits
                    if self.relative_trigger:
                        if self.cumulative is False:
                            if self.operands:
                                st = ''
                                for op, operand in zip(self.ops, self.operands):
                                    # scale operands to seconds
                                    unit = operand.unit
                                    operand = to_seconds(operand, unit)
                                    st += str(op) + str(operand)
                                st = eval(st)
                            else:
                                st = 0
                            stamp = relative_timestamp + st
                            if first_stamp <= stamp <= last_stamp:
                                self.timestamp = stamp
                            else:
                                out_of_limits = True
                                self.timestamp = None
                        else:
                            st = str(relative_timestamp)
                            for op, operand in zip(self.ops, self.operands):
                                # scale operands to seconds
                                unit = operand.unit
                                operand = to_seconds(operand, unit)
                                st += str(op) + str(operand)
                            stamp = numexpr.evaluate(st)

                            if first_stamp <= stamp <= last_stamp:
                                self.timestamp = stamp
                            else:
                                out_of_limits = True
                                self.timestamp = None
                    else:
                        if self.cumulative is False:
                            if start is not None:
                                intervals, _1, _2 = self.condition_group.evaluate(
                                    start=start,
                                    etype='trigger',
                                    use_previous_sample=self.use_previous_sample,
                                )

                                if len(intervals):
                                    stamp = np.float32(intervals[0][0])
                                    if first_stamp <= stamp <= last_stamp:
                                        self.timestamp = stamp
                                    else:
                                        out_of_limits = True
                                        self.timestamp = None
                                else:
                                    partial_detection = self.condition_group.partial_detection
                                    self.timestamp = None
                        else:
                            timestamps = []
                            if start is None:
                                intervals, _1, _2 = self.condition_group.evaluate(
                                    etype='trigger',
                                    use_previous_sample=self.use_previous_sample,
                                )

                                timestamps = intervals
                                for i, stamp in enumerate(timestamps):
                                    if stamp is None:
                                        continue
                                    if not first_stamp <= stamp[0] <= last_stamp:
                                        timestamps[i] = None
                                        out_of_limits = True
                                    else:
                                        timestamps[i] = stamp[0]
                            else:
                                for start_, stop_ in zip(start, stop):
                                    if start_ is None:
                                        timestamps.append(None)
                                    else:
                                        intervals, _1, _2 = self.condition_group.evaluate(
                                            start=start_,
                                            stop=stop_,
                                            etype='trigger',
                                            use_previous_sample=self.use_previous_sample,
                                        )

                                        if len(intervals):
                                            stamp = np.float32(intervals[0][0])
                                            if first_stamp <= stamp <= last_stamp:
                                                timestamps.append(stamp)
                                            else:
                                                out_of_limits = True
                                                timestamps.append(None)
                                        else:
                                            timestamps.append(None)
                            self.timestamp = timestamps
            else:
                if not self.cumulative and self.timestamp and limits:
                    if not limits[0] <= self.timestamp <= limits[1]:
                        self.timestamp = None
                        out_of_limits = True

            if self.condition_group and not self.cumulative:
                self.condition_group.evaluate(
                    self.timestamp,
                    self.timestamp,
                    etype='trigger',
                    log=False,
                )

            if self.timestamp is None:
                if out_of_limits:
                    found = 'Not found - out of measurement range {}s'.format(limits)
                else:
                    if partial_detection:
                        found = 'No common timestamp or interval for the detected conditions'
                    else:
                        found = 'Not found'
            else:
                if isinstance(self.timestamp, (np.ndarray, tuple, list)):
                    if self.timestamp:
                        found = 'Found (t = {})'.format(self.timestamp)
                    else:
                        found = 'Not found'
                else:
                    found = 'Found (t = {:.6f}s)'.format(self.timestamp)

            if self.condition_group is not None:
                self.condition_group.store(self.timestamp)
            LOGGER.info(compat_log('{: <20}{}'.format('{}'.format(self.name), found)))
        return self.timestamp

class Evaluator:
    """Evaluator

    The evaluator is defined using conditions.

    The evaluator's result is computed based on it's triggers and conditions.
    For simple evaluators, the evaluation is done using the start trigger.
    For interval evaluators, the evaluation is done in the time period determined
    by the start and stop triggers' timestamps.
    If a need trigger is not found in the measurment then the verdict is Verdict.unknown.


    Parameters
    ----------
    string : str
        'Expected Test Results' column string that has to be parsed for trigger definitions
    keywords : dict
        Keywords dictionary
    signals : dict
        Dictionary of Signals loaded from the measurement file
    global_delay : float
        global delay used for alal the conditions
    cumulative : bool
        flag for cumualtive or simple Evaluator

    Attributes
    ----------
    string : str
        trigger definition
    condition_group :utils.ConditionGroup
        top level condition group
    start_trigger : str
        name of the start trigger
    stop_trigger : str
        name of the stop trigger, in case of interval evaluation
    verdict : Verdict
        overall verdict; can be Verdict.failed, Verdict.passed or Verdict.unknown


    """
    def __init__(self, string, signals, global_delay=0.0, name='', comment=None, cumulative=False, user_signals=None):
        self.name = name
        self.full_string = string
        self.string = remove_comments(string)
        string = remove_comments(string)
        self.start_trigger = None
        self.stop_trigger = None
        self.global_delay = global_delay
        self.verdict = Verdict.unknown
        self.cumulative = cumulative
        self.user_signals = user_signals
        self.missing_signals = False

        if comment:
            comment = comment.strip()
            if not comment.startswith('//'):
                comment = ''
        else:
            comment = ''
        self.comment = comment

        pattern = (r'\SPACES*'
                   r'('                                                              # it can be:
                   r'(?i)ET(?P<single_trigger>[0-9]+)'                               # Evaluator on trigger
                   r'|'
                   r'(?i)ECT(?P<cumulative_trigger>[0-9]+)'                         # cumulative Evaluator on trigger
                   r'|'                                                             # or
                   r'(?i)INT_ET(?P<start_trigger>[0-9]+)_ET(?P<stop_trigger>[0-9]+)' # evaluator between 2 triggers
                   r'|'                                                             # or
                   r'(?i)INT_ECT(?P<cumulative_start_trigger>[0-9]+)_ECT(?P<cumulative_stop_trigger>[0-9]+)' # cumulative evaluator between 2 triggers
                   r')'
                   r'\SPACES*:\SPACES*\n'
                   r'\SPACES*(?P<conditions>(.+(\n|$))+)').replace('\SPACES', SPACES)

        match = re.match(pattern, string)
        if match.group('single_trigger'):
            self.start_trigger = 'T{}'.format(match.group('single_trigger'))
        elif match.group('cumulative_trigger'):
            self.start_trigger = 'CT{}'.format(match.group('cumulative_trigger'))
        elif match.group('start_trigger'):
            self.start_trigger = 'T{}'.format(match.group('start_trigger'))
            self.stop_trigger = 'T{}'.format(match.group('stop_trigger'))
        elif match.group('cumulative_start_trigger'):
            self.start_trigger = 'CT{}'.format(match.group('cumulative_start_trigger'))
            self.stop_trigger = 'CT{}'.format(match.group('cumulative_stop_trigger'))

        self.condition_group = ConditionGroup(match.group('conditions'), signals, user_signals=self.user_signals)
        self.missing_signals = self.condition_group.missing_signals

    def __str__(self):
        return 'start = {} stop = {}'.format(self.start_trigger, self.stop_trigger)

    def evaluate(self, triggers):
        """evaluate

        Runs the evaluation of the Evaluator's condition group

        Parameters
        ----------
        triggers : dict
            triggers dictionary

        Returns
        -------
        result : Verdict
            the overall result of the evaluator's condition group

        """

        start = triggers[self.start_trigger].timestamp
        if self.stop_trigger:
            stop = triggers[self.stop_trigger].timestamp
        else:
            stop = start

        if self.condition_group.missing_signals:
            LOGGER.info(compat_log(''))
            LOGGER.info(compat_log('{: <20}{}'.format('{}:'.format(self.name), '')))
            LOGGER.info(compat_log('{: <8}{: <16}{}'.format('', 'UNKNOWN', 'because of missing signals')))
            self.verdict = Verdict.unknown
        else:

            if self.cumulative is False:
                if start is None or stop is None:
                    start_v = '{:.6f}s'.format(start) if start is not None else 'unknown start'
                    stop_v = '{:.6f}s'.format(stop) if stop is not None else 'unknown stop'
                    if self.stop_trigger:
                        time_interval = 'from {} to {}'.format(start_v, stop_v)
                    else:
                        time_interval = 'at {}'.format(start_v)
                    LOGGER.info(compat_log(''))
                    LOGGER.info(compat_log('{: <20}{}'.format('{}:'.format(self.name), time_interval)))
                    if self.comment:
                        LOGGER.info(compat_log('{: <60}'.format(self.comment)))
                    LOGGER.info(compat_log('\n'.join(self.full_string.splitlines()[1:])))
                    LOGGER.info(compat_log(''))

                    LOGGER.info(compat_log('{: <8}{: <16}{}'.format('', 'UNKNOWN',
                                                                    'because start or stop trigger was not found')))

                    self.verdict = Verdict.unknown
                else:
                    if self.stop_trigger:
                        time_interval = 'from {:.6f}s to {:.6f}s'.format(start, stop)
                    else:
                        time_interval = 'at {:.6f}s'.format(start)
                    LOGGER.info(compat_log(''))
                    LOGGER.info(compat_log('{: <20}{}'.format('{}:'.format(self.name), time_interval)))
                    if self.comment:
                        LOGGER.info(compat_log('{: <60}'.format(self.comment)))
                    LOGGER.info(compat_log('\n'.join(self.full_string.splitlines()[1:])))
                    LOGGER.info(compat_log(''))

                    start, stop = start + self.global_delay, stop + self.global_delay
                    self.verdict, _1, _2 = self.condition_group.evaluate(start, stop, etype='evaluator')

            else:
                if start is None or stop is None:
                    start_v = '{}s'.format(start) if start is not None else 'unknown start'
                    stop_v = '{}s'.format(stop) if stop is not None else 'unknown stop'
                    if self.stop_trigger:
                        time_interval = 'from {} to {}'.format(start_v, stop_v)
                    else:
                        time_interval = 'at {}'.format(start_v)
                    LOGGER.info(compat_log(''))
                    LOGGER.info(compat_log('{: <20}{}'.format('{}:'.format(self.name), time_interval)))
                    if self.comment:
                        LOGGER.info(compat_log('{: <60}'.format(self.comment)))
                    LOGGER.info(compat_log('\n'.join(self.full_string.splitlines()[1:])))
                    LOGGER.info(compat_log(''))
                    self.verdict = Verdict.unknown
                else:
                    verdicts = []
                    for cntr, (start_, stop_) in enumerate(zip(start, stop), 1):

                        start_v = '{:.6f}s'.format(start_) if start_ is not None else 'unknown start'
                        stop_v = '{:.6f}s'.format(stop_) if stop_ is not None else 'unknown stop'
                        if self.stop_trigger:
                            time_interval = 'from {} to {}'.format(start_v, stop_v)
                        else:
                            time_interval = 'at {}'.format(start_v)
                        LOGGER.info(compat_log(''))
                        LOGGER.info(compat_log('{: <15} {: >4} {}'\
                            .format('{}:'.format(self.name), cntr, time_interval)))
                        if self.comment:
                            LOGGER.info(compat_log('{: <60}'.format(self.comment)))
                        LOGGER.info(compat_log('\n'.join(self.full_string.splitlines()[1:])))
                        LOGGER.info(compat_log(''))

                        if start_ is None or stop_ is None:
                            verdicts.append(Verdict.unknown)
                            LOGGER.info(compat_log('{: <8}{: <16}{}'\
                                .format('', 'UNKNOWN', 'because start or stop trigger was not found')))
                        else:
                            start_, stop_ = start_ + self.global_delay, stop_ + self.global_delay
                            verdict, _1, _2 = self.condition_group.evaluate(start_, stop_, etype='evaluator')
                            verdicts.append(verdict)

                    if verdicts:
                        if any(verdict == Verdict.failed for verdict in verdicts):
                            self.verdict = Verdict.failed
                        elif any(verdict == Verdict.passed for verdict in verdicts):
                            self.verdict = Verdict.passed
                        else:
                            self.verdict = Verdict.unknown
                    else:
                        self.verdict = Verdict.unknown

        return self.verdict


class Signal:
    """Signal

    The Signal represents a signal described by it's samples and timestamps.

    It can do aritmethic operations agains other Signal, Constant or numeric type.
    The operations are computed in respect to the timestamps (time correct).
    The integer signals are not interpolated, instead the last value relative to the current timestamp is used.

    Parameters
    ----------
    signal : numpy.array
        signal samples
    time : numpy.array
        signal timestamps
    unit : str
        signal unit
    name : str
        signal name

    """
    def __init__(self, signal=None, time=None, unit=None, name=None, sign='+', comment=''):

        self.type = SIGNAL
        self.signal = np.array(signal)
        self.time = np.array(time, dtype=np.float32)
        self.unit = unit
        self.name = name
        self.sign = sign
        self.comment = comment

    def copy(self):
        return Signal(
            self.signal.copy(),
            self.time.copy(),
            self.unit,
            self.name,
        )

    def __str__(self):
        return 'Signal {{ name="{}" (comment={}):\ts={}\tt={} \tl={} }}'.format(
            self.name,
            self.comment,
            self.signal,
            self.time,
            len(self.signal),
        )

    def __repr__(self):
        return 'Signal {{ {}:\ts={}\tt={} \tl={} }}'.format(
            self.name,
            repr(self.signal),
            repr(self.time),
            repr(len(self.signal)))

    def cut(self, start, stop):
        """cut

        Cuts the signal according to the *start* and *stop* values,
        by using the insertion indexes in the signal's *time* axis.

        Parameters
        ----------
        start : float
            start timestamp for cutting
        stop : float
            stop timestamp for cutting

        Returns
        -------
        outsig : Signal
            new `Signal` cut from the original

        Examples
        --------
        >>> new_sig = old_sig.cut(1.0, 10.5)
        >>> new_sig.time[0], new_sig.time[-1]
        0.98, 10.48

        """
        if start is None and stop is None:
            return self
        start_ = np.searchsorted(self.time, start, side='left')
        start_ = max(0, start_)
        stop_ = np.searchsorted(self.time, stop, side='right')
        if start not in self.time and start_ == stop_:
            start_ -= 1

        if stop_ == start_:

            if (len(self.time)
                    and stop >= self.time[0]
                    and start <= self.time[-1]):
                # start and stop are found between 2 signal samples
                # so return the previous sample
                result = Signal(
                    self.signal[start_ - 1: start_],
                    self.time[start_ - 1: start_],
                    self.unit,
                    self.name,
                )
            else:
                # signal is empty or start and stop are outside the
                # signal time base
                result = Signal(
                    np.array([]),
                    np.array([]),
                    self.unit,
                    self.name,
                )
        else:
            result = Signal(
                self.signal[start_: stop_],
                self.time[start_: stop_],
                self.unit,
                self.name,
            )

        return result

    def time_delta(self):
        return self.time[1] - self.time[0]

    def interp(self, new_time):
        new_time = new_time.astype(np.float32)
        if self.signal.dtype.kind == 'f':
            s = np.interp(new_time, self.time, self.signal)
        else:
            idx = np.searchsorted(self.time, new_time, side='right') - 1
            idx = np.clip(idx, 0, idx[-1])
            s = self.signal[idx]
        return Signal(s, new_time, self.unit, self.name)

    def extend(self, other):
        """ extend signal with samples from another signal

        Parameters
        ----------
        other : Signal

        """
        if len(self.time):
            last_stamp = self.time[-1]
            delta = last_stamp / len(self) + last_stamp
        else:
            last_stamp = 0
            delta = 0
        if len(other):
            other_first_sample = other.time[0]
            if last_stamp >= other_first_sample:
                timestamps = other.time + delta - other_first_sample
            else:
                timestamps = other.time

            result = Signal(
                np.append(self.signal, other.signal),
                np.append(self.time, timestamps),
                self.unit,
                self.name,
            )
        else:
            result = self
        return result

    def __apply_func(self, other, func_name):

        if isinstance(other, Signal):
            time = np.union1d(self.time, other.time)
            s = self.interp(time).signal
            o = other.interp(time).signal
            func = getattr(s, func_name)
            s = func(o)
        elif other is None:
            s = self.signal
            time = self.time
        elif isinstance(other, Constant):
            func = getattr(self.signal, func_name)
            s = func(other.x)
            time = self.time
        else:
            func = getattr(self.signal, func_name)
            s = func(other)
            time = self.time
        return Signal(s, time, self.unit)

    def __pos__(self):
        return Signal(self.signal, self.time, self.unit, self.name)

    def __neg__(self):
        return Signal(np.negative(self.signal), self.time, self.unit, self.name)

    def __round__(self, n):
        return Signal(np.around(self.signal, n), self.time, self.unit, self.name)

    def __sub__(self, other):
        return self.__apply_func(other, '__sub__')

    def __isub__(self, other):
        return self.__sub__(other)

    def __rsub__(self, other):
        return -self.__sub__(other)

    def __add__(self, other):
        return self.__apply_func(other, '__add__')

    def __iadd__(self, other):
        return self.__add__(other)

    def __radd__(self, other):
        return self.__add__(other)

    def __mul__(self, other):
        return self.__apply_func(other, '__mul__')

    def __imul__(self, other):
        return self.__mul__(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        return self.__apply_func(other, '__truediv__')

    def __itruediv__(self, other):
        return self.__truediv__(other)

    def __rtruediv__(self, other):
        return self.__apply_func(other, '__rtruediv__')

    def __div__(self, other):
        return self.__apply_func(other, '__div__')

    def __idiv__(self, other):
        return self.__truediv__(other)

    def __rdiv__(self, other):
        return self.__apply_func(other, '__rdiv__')

    def __mod__(self, other):
        return self.__apply_func(other, '__mod__')

    def __pow__(self, other):
        return self.__apply_func(other, '__pow__')

    def __and__(self, other):
        return self.__apply_func(other, '__and__')

    def __or__(self, other):
        return self.__apply_func(other, '__or__')

    def __xor__(self, other):
        return self.__apply_func(other, '__xor__')

    def __invert__(self):
        s = ~self.signal
        time = self.time
        return Signal(s, time, self.unit)

    def __lshift__(self, other):
        return self.__apply_func(other, '__lshift__')

    def __rshift__(self, other):
        return self.__apply_func(other, '__rshift__')

    def __lt__(self, other):
        return self.__apply_func(other, '__lt__')

    def __le__(self, other):
        return self.__apply_func(other, '__le__')

    def __gt__(self, other):
        return self.__apply_func(other, '__gt__')

    def __ge__(self, other):
        return self.__apply_func(other, '__ge__')

    def __eq__(self, other):
        return self.__apply_func(other, '__eq__')

    def __ne__(self, other):
        return self.__apply_func(other, '__ne__')

    def __iter__(self):
        return zip(self.signal, self.time)

    def __reversed__(self):
        return enumerate(zip(reversed(self.signal), reversed(self.time)))

    def __len__(self):
        return len(self.signal)

    def __abs__(self):
        return Signal(np.fabs(self.signal), self.time)

    def __getitem__(self, val):
        return self.signal[val]

    def slice(self, val):
        if isinstance(val, int):
            return self.signal[val]
        else:
            return Signal(
                self.signal[val],
                self.time[val],
                self.unit,
                self.name,
                self.sign,
                self.comment,
            )

    def __setitem__(self, idx, val):
        self.signal[idx] = val

    def astype(self, np_type):
        return Signal(self.signal.astype(np_type), self.time, self.unit, self.name)


class Constant:
    """Constant

    A Constant can contain numeric values, interpolation curves or elevation parameters.

    Parameters
    ----------
    string : Type of string
        Description of string default None


    Attributes
    ----------
    constant_type : int
        int code for constant type
    x : {int, float, list}
        value for scalar `Constant` or `x` axis for interpolation curve
    y : list
        `y` axis for interpolation curve
    op1 : str
        operator for first treshold of eleveation `Constant`
    op2 : str
        operator for second treshold of eleveation `Constant`
    val1 : float
        first treshold value of elevation `Constant`
    val2 : float
        first treshold value of elevation `Constant`
    unit : str
        measurement unit

    Examples
    --------
    >>> float_constant = Constant("9.5")
    >>> float_constant.x
    9.5
    >>> float_exp_constant = Constant("2.5e-4")
    >>> int_constant = Constant("3")
    >>> int_base16_constant = Constant("0xFA")
    >>> int_base16_constant.x
    250
    >>> interpolation_curve_constant = Constant("0.1,0.2,0.3,0.4,0.5;100,100,80,60,0")
    >>> interpolation_curve_constant.x
    [ 0.1  0.2  0.3  0.4  0.5]
    >>> interpolation_curve_constant.y
    [ 100.0 100.0 80.0 60.0 0.0 ]
    >>> elevation_constant = Constant("FALLING(>100, <=90)")
    >>> elevation_constant.val1
    100
    >>> elevation_constant.val2
    90


    """

    def __init__(self, string):
        self.type = CONSTANT
        self.unit = ''
        self.match = None
        if isinstance(string, str) or (PYVERSION == 2 and isinstance(string, unicode)):
            string = remove_comments(string)
            if string.startswith(Delimiters.start) and string.endswith(Delimiters.end):
                start_size, end_size = len(Delimiters.start), len(Delimiters.end)
                string = string[start_size: -end_size].strip(' \t')
            self.string = string

            found = False

            # interpolation table
            if not found:
                values = string.split(';')
                if len(values) == 2:
                    self.x = np.array([float(v) for v in values[0].split(',')])
                    self.y = np.array([float(v) for v in values[1].split(',')])
                    self.const_type = CONST_TYPE_INTERP_TABLE
                    found = True

            # float number
            if not found:
                pattern = r'(?P<float>[\+-]?(([0-9]+(\.[0-9]+)?e(\+|-)?[0-9]+)|[0-9]+\.[0-9]+))\SPACES*(?P<unit>[^ ,]*)\SPACES*'
                pattern = pattern.replace('\SPACES', SPACES)
                match = fullmatch(pattern, string)
                if match:
                    self.x = np.float64(float(match.group('float')))
                    self.const_type = CONST_TYPE_SCALAR
                    self.unit = match.group('unit').strip() if match.group('unit').strip() else ''
                    found = True
                    self.match = match

            # hexadecimal integer
            if not found:
                pattern = r'(?P<hex>0x[0-9A-Fa-f]+)\SPACES*(?P<unit>[^ ,]*)\SPACES*'
                pattern = pattern.replace('\SPACES', SPACES)
                match = fullmatch(pattern, string)
                if match:
                    self.x = np.int64(int(match.group('hex'), 16))
                    self.const_type = CONST_TYPE_SCALAR
                    self.unit = match.group('unit').strip() if match.group('unit').strip() else ''
                    found = True
                    self.match = match

            # binary integer
            if not found:
                pattern = r'(?P<bin>0b[0-1]+)\SPACES*(?P<unit>[^ ,]*)\SPACES*'
                pattern = pattern.replace('\SPACES', SPACES)
                match = fullmatch(pattern, string)
                if match:
                    self.x = np.int64(int(match.group('bin'), 2))
                    self.const_type = CONST_TYPE_SCALAR
                    self.unit = match.group('unit').strip() if match.group('unit').strip() else ''
                    found = True
                    self.match = match

            # integer base 10 number
            if not found:
                pattern = r'(?P<base10>[\+-]?[0-9]+)\SPACES*(?P<unit>[^ ,]*)\SPACES*'
                pattern = pattern.replace('\SPACES', SPACES)
                match = fullmatch(pattern, string)
                if match:
                    self.x = np.int64(int(match.group('base10')))
                    self.const_type = CONST_TYPE_SCALAR
                    self.unit = match.group('unit').strip() if match.group('unit').strip() else ''
                    found = True
                    self.match = match

            # complex constant
            if not found:
                pattern = (r'\SPACES*(?P<edge>(?i)RISING|FALLING|ELEVATION)\SPACES*'
                           r'\(\SPACES*'
                           r'(?P<op1>!=|==|<=|>=|<|>)?\SPACES*'
                           r'({0.start}(?P<operand1_param>(?!{0.end}).+){0.end}|(?P<operand1_adhoc>[^, \t]+))\SPACES*'
                           r',\SPACES*'
                           r'(?P<op2>!=|==|<=|>=|<|>)?\SPACES*'
                           r'({0.start}(?P<operand2_param>(?!{0.end}).+){0.end}|(?P<operand2_adhoc>[^)]+))\SPACES*'
                           r'\)').format(Delimiters).replace('\SPACES', SPACES)

                matches = re.finditer(pattern, string)
                for match in matches:
                    self.edge = match.group('edge')
                    self.op1 = match.group('op1')
                    if match.group('operand1_adhoc'):
                        operand = match.group('operand1_adhoc')
                    elif match.group('operand1_param'):
                        operand = match.group('operand1_param')
                    self.val1 = Constant(operand).x
                    self.op2 = match.group('op2')
                    if match.group('operand2_adhoc'):
                        operand = match.group('operand2_adhoc')
                    elif match.group('operand2_param'):
                        operand = match.group('operand2_param')
                    self.val2 = Constant(operand).x
                    self.const_type = CONST_TYPE_COMPLEX
                    found = True

            # string
            if not found:
                pattern = r'\SPACES*\|(?P<string>.+?)\SPACES*\|\SPACES*'
                pattern = pattern.replace('\SPACES', SPACES)
                match = fullmatch(pattern, string)
                if match:
                    self.x = match.group('string')
                    self.const_type = CONST_TYPE_STRING
                    self.unit = 'string'
                    found = True
                    self.match = match

            if not found:
                raise EvaluateError('Could not parse constant: "{}"'.format(self.string))

        elif isinstance(string, Signal):
            val = string.signal[0]
            self.const_type = CONST_TYPE_SCALAR
            self.string = str(val)
            self.x = np.float64(val)
            self.unit = string.unit
            if self.x.is_integer():
                self.x = np.int64(int(val))
        elif isinstance(string, Constant):
            other = string
            self.const_type = other.const_type
            self.string = other.string
            self.x = other.x
            self.unit = other.unit
        else:
            self.const_type = CONST_TYPE_SCALAR
            self.string = str(string)
            self.x = np.float64(float(string))
            if self.x.is_integer():
                self.x = np.int64(int(string))

    def __str__(self):
        if self.const_type == CONST_TYPE_SCALAR:
            string = 'Constant {{ scalar : value={} unit={} }}'.format(self.x, self.unit)
        elif self.const_type == CONST_TYPE_INTERP_TABLE:
            string = 'Constant {{ interpolation : Xaxis={} Yaxis={} }}'.format(self.x, self.y)
        elif self.const_type == CONST_TYPE_COMPLEX:
            string = 'Constant {{ complex : edge={} op1="{}" value1={} op2="{}" value2={} }}'\
                .format(self.edge, self.op1, self.val1, self.op2, self.val2)
        elif self.const_type == CONST_TYPE_STRING:
            string = 'Constant {{ string : value={} unit={} }}'.format(self.x[1:], self.unit)
        return string

    def __repr__(self):
        return str(self)

    def __bool__(self):
        return bool(self.x)

    def __apply_func(self, other, func_name):
        func = getattr(self.x, func_name)
        if isinstance(other, Constant):
            return Constant(func(other.x))
        elif isinstance(other, Signal):
            return NotImplemented
        elif other is None:
            return self
        else:
            return Constant(func(other))

    def __add__(self, other):
        return self.__apply_func(other, '__add__')

    def __radd__(self, other):
        return self.__add__(other)

    def __iadd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):

        return self.__apply_func(other, '__sub__')

    def __rsub__(self, other):
        return -self.__sub__(other)

    def __isub__(self, other):
        return self.__sub__(other)

    def __pow__(self, other):
        if isinstance(other, Constant):
            return Constant(self.x ** other.x)
        elif isinstance(other, Signal):
            return Signal(self.x ** other.signal, other.time)
        elif other is None:
            return self
        else:
            return self.x ** other

    def __mul__(self, other):
        return self.__apply_func(other, '__mul__')

    def __rmul__(self, other):
        return self.__mul__(other)

    def __imul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        return self.__apply_func(other, '__truediv__')

    def __rtruediv__(self, other):
        return self.__apply_func(other, '__rtruediv__')

    def __itruediv__(self, other):
        return self.__truediv__(other)

    def __neg__(self):
        return Constant(-self.x)

    def __abs__(self):
        return Constant(abs(self.x))

    def __and__(self, other):
        return self.__apply_func(other, '__and__')

    def __or__(self, other):
        return self.__apply_func(other, '__or__')

    def __xor__(self, other):
        return self.__apply_func(other, '__xor__')

    def __lt__(self, other):
        return self.__apply_func(other, '__lt__')

    def __le__(self, other):
        return self.__apply_func(other, '__le__')

    def __gt__(self, other):
        return self.__apply_func(other, '__gt__')

    def __ge__(self, other):
        return self.__apply_func(other, '__ge__')

    def __eq__(self, other):
        return self.__apply_func(other, '__eq__')

    def __ne__(self, other):
        return self.__apply_func(other, '__ne__')

    def __invert__(self):
        return Constant(~self.x)


class ConditionGroup:
    """ConditionGroup

    A condition group contains one or more Conditions/ConditionGroups grouped using paranthesis

    Parameters
    ----------
    string : str
        string to be parsed for condition definition
    signals : dict
        dictionary of `Signal` object loaded from the measurement file
    relation : str
        relation relative to the preceding Conditions/ConditionGroups; default *AND*

    Attributes
    ----------
    string : str
        definition
    items : list
        list of Conditions/ConditionGroups
    results : list
        list of items results
    relation : str
        relation relative to the preceding Conditions/ConditionGroups
    id : int
        id used to identify the condition groups instanciated by a testcase
    counter : int
        static class attribute incremented with each new condition group instance

    """

    counter = 0

    def __init__(self, string, signals, relation='AND', user_signals=None, negate=False):
        self.items = []
        self.results = []
        self.partial_detection = False
        self.relation = relation
        self.user_signals = user_signals
        self.missing_signals = False
        self.negate = negate

        self.string = remove_comments(string)
        state = 'simple'
        relation = ''
        cntr = 1

        for line in string.splitlines():
            line = line.strip()

            if state == 'simple':
                group_str = []
                # new condition group ?
                pattern = '(?P<rel>((?i)OR|AND)?)\SPACES*(?P<not>((?i)NOT)?)\SPACES*\(\SPACES*(?P<rest>.+)'\
                    .replace('\SPACES', SPACES)

                match = re.match(pattern, line)
                if match:
                    relation = match.group('rel').upper() if match.group('rel') else 'AND'
                    negate = True if match.group("not") else False
                    line = match.group('rest')
                    state = 'group'
                    cntr = 1
                else:
                    cond = Condition(line, signals, self.user_signals)
                    if cond.missing_signals:
                        self.missing_signals = True

                    self.items.append(cond)
            if state == 'group':
                cntr += line.count('(') - line.count(')')
                if cntr == 0:
                    line = line[:-1]
                    group_str.append(line)
                    cond_group = ConditionGroup(
                        '\n'.join(group_str),
                        signals,
                        relation,
                        self.user_signals,
                        negate=negate
                    )
                    self.items.append(cond_group)
                    if cond_group.missing_signals:
                        self.missing_signals = True
                    state = 'simple'
                    cntr = 1
                else:
                    group_str.append(line)

        self.id = ConditionGroup.counter
        ConditionGroup.counter += 1

    def __repr__(self):
        s = [self.string, self.relation, str(self.negate)]
        for e in self.items:
            if isinstance(e, ConditionGroup):
                s.append(str(e))
            else:
                s.append(repr(e))

        s.append('='*20)
        return '\n'.join(s)

    def evaluate(self, start=None, stop=None, etype='', log=True, use_previous_sample=False):
        """evaluate

        Evaluates the items; the evaluation depends on the context *etype*

        Parameters
        ----------
        start : float
            start time; default `START_OF_MEASUREMENT`
        stop : float
            stop time; default `END_OF_MEASUREMENT`
        etype : str [*evaluator* | *trigger*]
            context
        log : bool
            option to use logging while evaluating; default *True*
        use_previous_sample : bool
            option to use previous samples, in case of Trigger evaluation;
            default *False*


        Returns
        -------
        result, relation : tuple
            in *evaluator* context the result is the overall verdict
            in *trigger* context the result is the time stamps intersection

        """

        self.results = []

        if etype == 'evaluator':
            for item in self.items:

                if isinstance(item, Condition):
                    cond = item
                    res = cond.evaluate(start, stop, use_previous_sample=use_previous_sample)

                    if cond.delay_type == 'within':
                        if not len(res.idx):
                            self.results.append((cond.relation, Verdict.failed, res))
                        else:
                            self.results.append((cond.relation, Verdict.passed, res))

                    elif cond.delay_type == 'once':
                        if not len(res.idx):
                            self.results.append((cond.relation, Verdict.failed, res))
                        else:
                            self.results.append((cond.relation, Verdict.passed, res))

                    elif cond.delay_type == 'for':
                        if not len(res.idx):
                            self.results.append((cond.relation, Verdict.failed, res))
                        else:
                            delta = cond.delay_low

                            if isinstance(delta, Signal):
                                delta = delta.cut(start, stop)
                            elif isinstance(delta, Function):
                                delta = delta.evaluate(start, stop)

                            delta = to_seconds(delta)

                            start_i = stop_i = 0
                            pivot = res.idx[0]
                            intervals = []
                            for i, v in enumerate(res.idx):
                                if v - pivot <= 1:
                                    stop_i = i
                                else:
                                    intervals.append(res.time_stamps()[stop_i] - res.time_stamps()[start_i])
                                    start_i = stop_i = i
                                pivot = v
                            intervals.append(res.time_stamps()[stop_i] - res.time_stamps()[start_i])

                            if max(intervals) >= delta:
                                self.results.append((cond.relation, Verdict.passed, res))
                            else:
                                self.results.append((cond.relation, Verdict.failed, res))

                    else:
                        if not len(res.idx):
                            self.results.append((cond.relation, Verdict.failed, res))
                        else:
                            if len(res.failed_timestamps()):
                                self.results.append((cond.relation, Verdict.failed, res))
                            else:
                                self.results.append((cond.relation, Verdict.passed, res))

                    if self.results[-1][1] == Verdict.passed:
                        verdict = Verdict.to_string(self.results[-1][1])
                        if not self.negate:
                            LOGGER.info(compat_log('{: <8}{: <16}{}'.format('', verdict, item.string)))
                        else:
                            LOGGER.info(compat_log('{: <8}{: <16} (Inside NOT ConditionGroup) {}'\
                                .format('', verdict, item.string)))
                    else:
                        verdict = Verdict.to_string(self.results[-1][1])
                        first_failed = self.results[-1][2].first_failed()

                        if not self.negate:
                            LOGGER.info(compat_log('{: <8}{: <16}{}    // first failure: {}'\
                                .format('', verdict, item.string, first_failed)))
                        else:
                            LOGGER.info(
                                compat_log('{: <8}{: <16} (Inside NOT ConditionGroup) {}    // first failure: {}'\
                                    .format('', verdict, item.string, first_failed)))

                        LOGGER.debug(str(self.results[-1][2]))
                elif isinstance(item, ConditionGroup):
                    verdict, rel, none = item.evaluate(
                        start,
                        stop,
                        etype='evaluator',
                        log=log,
                        use_previous_sample=use_previous_sample,
                    )
                    self.results.append((rel, verdict, none))

            # create OR groups for the condition results
            condition_groups = []
            for res in self.results:
                if res[0] == 'OR':
                    condition_groups.append([])
                    condition_groups[-1].append(res[1])
                elif res[0] in ('AND', ''):
                    if not condition_groups:
                        condition_groups.append([])
                    condition_groups[-1].append(res[1])

            # get the intersections for each OR group
            final_result = []
            for gp in condition_groups:
                if all([e == Verdict.passed for e in gp]):
                    final_result.append(True)
                else:
                    final_result.append(False)

            self.verdict = Verdict.passed if any(final_result) else Verdict.failed

            if self.negate:
                if self.verdict == Verdict.passed:
                    self.verdict = Verdict.failed
                elif self.verdict == Verdict.failed:
                    self.verdict = Verdict.passed

            return self.verdict, self.relation, None

        elif etype == 'trigger':
            timebases = []
            for item in self.items:
                if isinstance(item, Condition):
                    cond = item
                    res = cond.evaluate(start, stop, use_previous_sample=use_previous_sample)
                    indexes, intervals, stamps = res.idx, res.time_intervals(), res.time_stamps()
                    timebase = res.timebase()
                    if len(timebase):
                        timebases.append(timebase)
                        self.partial_detection = True

                    if cond.delay_type == 'for':

                        if not len(indexes):
                            self.results.append((cond.relation, []))
                        else:
                            intervals = []
                            delta = cond.delay_low

                            if isinstance(delta, Signal):
                                delta = delta.cut(start, stop)
                            elif isinstance(delta, Function):
                                delta = delta.evaluate(start, stop)

                            delta = to_seconds(delta)

                            start = stop = 0
                            pivot = res.idx[0]
                            time_stamps = []

                            for i, v in enumerate(indexes):
                                if v - pivot == 1:
                                    stop, pivot = i, v
                                else:
                                    start_stamp, start_index = stamps[start], start
                                    while stamps[stop] - stamps[start] >= delta:
                                        time_stamps.append(stamps[start])
                                        start += 1

                                    if start > start_index:
                                        intervals.append((start_stamp, stamps[start-1]))

                                    start = stop = i
                                    pivot = v

                            start_stamp, start_index = stamps[start], start
                            while stamps[stop] - stamps[start] >= delta:
                                time_stamps.append(stamps[start])
                                start += 1

                            if start > start_index:
                                intervals.append((start_stamp, stamps[start-1]))

                            self.results.append((cond.relation, intervals))

                    elif cond.delay_type == 'count':
                        count = Constant(cond.delay_low).x
                        temp_res = Result(
                            res.idx[count-1:],
                            res.lval,
                            res.rval,
                            res.tolerance,
                            res.op,
                        )
                        stamps = temp_res.time_stamps()
                        intervals = temp_res.time_intervals()
                        LOGGER.debug(compat_log(str(count) + str(type(count))))
                        self.results.append((cond.relation, intervals))

                    else:
                        self.results.append((cond.relation, intervals))

                    if log:
                        if len(self.results[-1][1]):
                            detected = 'Detected'
                        else:
                            detected = 'Not detected'
                        LOGGER.info(compat_log('{: <8}{: <16}{}'.format('', detected, item.string)))

                elif isinstance(item, ConditionGroup):
                    intervals, rel, timebase = item.evaluate(
                        start,
                        stop,
                        etype='trigger',
                        log=log,
                        use_previous_sample=use_previous_sample,
                    )
                    if len(timebase):
                        timebases.append(timebase)
                    self.partial_detection = item.partial_detection
                    self.results.append((item.relation, intervals))

            if timebases:
                timebase = reduce(np.union1d, timebases)
            else:
                timebase = np.array([])

            # create OR groups for the intermediate results
            condition_groups = []
            for result in self.results:
                if result[0] == 'OR':
                    condition_groups.append([])
                    condition_groups[-1].append(result[1])
                elif result[0] in ('AND', ''):
                    if not condition_groups:
                        condition_groups.append([])
                    condition_groups[-1].append(result[1])
            # get the intersections for each OR group

            time_intervals = []
            for group in condition_groups:
                temporary_intervals = group[0]

                for other_and_intervals in group[1:]:
                    remaining_intervals = []

                    for int1, int2 in product(temporary_intervals, other_and_intervals):
                        _start, _stop = int1
                        start, stop = int2

                        if start <= _stop and stop >= _start:
                            remaining_intervals.append(
                                (max(start, _start), min(stop, _stop))
                            )

                    temporary_intervals = remaining_intervals

                time_intervals.extend(temporary_intervals)

            time_intervals.sort()

            # the final result is the union of the intermediat results

            result = []
            for start, stop in time_intervals:
                for i, (existing_start, existing_stop) in enumerate(result):
                    if start <= existing_stop and stop >= existing_start:
                        result[i] = (min(start, existing_start), max(stop, existing_stop))
                        break
                else:
                    result.append((start, stop))

            if self.negate:
                if result:
                    negated_result = []
                    dim = len(result)
                    for i, interval in enumerate(result):
                        if i == 0:
                            idx = np.argwhere(timebase < interval[0]).flatten()
                            if len(idx):
                                negated_result.append((timebase[idx[0]], timebase[idx[-1]]))
                        elif i == dim - 1:
                            idx = np.argwhere(timebase > interval[-1]).flatten()
                            if len(idx):
                                negated_result.append((timebase[idx[0]], timebase[idx[-1]]))
                        else:
                            prev_interval = result[i-1]
                            next_interval = result[i+1]

                            idx1 = np.argwhere(timebase > prev_interval[-1]).flatten()
                            idx2 = np.argwhere(timebase < interval[0]).flatten()

                            idx = np.intersect1d(idx1, idx2).flatten()
                            if len(idx):
                                negated_result.append((timebase[idx[0]], timebase[idx[-1]]))

                            idx1 = np.argwhere(timebase > interval[-1]).flatten()
                            idx2 = np.argwhere(timebase < next_interval[0]).flatten()

                            idx = np.intersect1d(idx1, idx2).flatten()
                            if len(idx):
                                negated_result.append((timebase[idx[0]], timebase[idx[-1]]))
                    result = negated_result

                else:
                    if len(timebase):
                        result = [(timebase[0], timebase[-1]), ]

            # if the conditions ar not met the result is an empty list
            return result, self.relation, timebase

    def store(self, timestamp):
        for item in self.items:

            if isinstance(item, Condition):
                left = item.operand1
                if left.type == FUNCTION and left.func_type == 'DEFINE':
                    user_signal = left.args[0]
                    if timestamp is None:
                        user_signal.signal = np.array([])
                        user_signal.time = np.array([], dtype=np.float32)
                    # del self.user_signals[user_signal.name]
            else:
                item.store(timestamp)


class Condition:
    """Condition

    Parameters
    ----------
    string : str
        string to be parsed for condition definition
    signals : dict
        dictionary of `Signal` object loaded from the measurement file

    Attributes
    ----------
    string : str
        initial string definition of the condition
    start : float
        start time for condition evaluation
    stop : float
        stop time for condition evaluation
    relation : str
        relation relative to the preceding conditions
    op : str
        operation for the condition operands
    operan1 : Constant|Signal|Function
        left side operand; can be either of the object types Constant, Signal or Function
    operan2 : Constant|Signal|Function
        right side operand; can be either of the object types above
    delay_type : str
        delay modifier type
    delay_low : float
        delay lower tolerance
    delay_high : float
        delay higher tolerance
    delay_unit : str
        time unit for the delay
    tolerance : float
        tolerance to be used for the evaluation of the condition

    """

    def __init__(self, string, signals, user_signals=None):
        self.string = string
        self.relation = ''
        self.negate = False
        self.start = None
        self.stop = None
        self.operand1 = None
        self.operand2 = None
        self.op = None
        self.delay_type = ''
        self.delay_low = Constant(0)
        self.delay_high = Constant(0)
        self.tolerance = Constant(0)
        self.signals = signals
        self.user_signals = user_signals
        self.missing_signals = False

        pattern = (r'(?P<relation>(?i)(AND|OR)?)\SPACES*(?P<not>(?i)(NOT)?)\SPACES*(?P<left_sign>[\+-]+)?'
                   r'(?P<left>[^<>=!]+)\SPACES*'
                   r'(?P<op>!=|==|>=|<=|<|>) *'
                   r'(?P<right>.+)\SPACES*').replace('\SPACES', SPACES)

        match = fullmatch(pattern, self.string)
        if match:
            self.negate = True if match.group("not") else False
            self.relation = match.group('relation').upper() if match.group('relation') else 'AND'
            left_sign = match.group('left_sign')
            if left_sign:
                self.left_sign = left_sign[-1]
            else:
                self.left_sign = ''
            self.op = match.group('op')
            left = match.group('left').strip()
            right = match.group('right').strip()

            if left.startswith(AVAILABLE_FUNCTIONS):
                self.operand1 = Function(left, signals, self.left_sign, user_signals=self.user_signals)
                if self.operand1.func_type == 'DEFINE':
                    self.op = '=='
                self.missing_signals = self.operand1.missing_signals
            else:

                if left.startswith(Delimiters.start):
                    if not left.endswith(Delimiters.end):
                        raise EvaluateError("Could not parse Signal or Constant: '{}'".format(left))
                    left = left[len(Delimiters.start): -len(Delimiters.end)].strip()
                    if left[0] in '+-0123456789':
                        self.operand1 = Constant(left)
                    else:
                        if left.startswith('__'):
                            if left not in self.user_signals:
                                self.user_signals[left] = Signal([], [], name=left)
                            self.operand1 = self.user_signals[left]
                        elif left in signals:
                            self.operand1 = signals[left]
                        else:
                            self.missing_signals = True
                            self.operand1 = None
                else:
                    self.operand1 = Constant(left)
                if self.left_sign == '-':
                    self.operand1 = -self.operand1

            # right is a function
            right_pattern = (
                r'\SPACES*(?P<right_sign>[\+-]+)?\SPACES*(?P<func>({})[^ \t\(]*\SPACES*\(.+\))\SPACES*'\
                    .format('|'.join(AVAILABLE_FUNCTIONS)),
                r'(?P<options>((once|delay|until|within|for|count)\SPACES+.+\SPACES+tolerance\SPACES+.+|tolerance\SPACES+.+|(once|delay|until|within|for|count)(\SPACES+.+)?)?)'
            )

            right_pattern = ''.join(right_pattern).replace('\SPACES', SPACES)

            match = fullmatch(right_pattern, right)

            if match:
                func = match.group('func')
                right_sign = match.group('right_sign')
                if right_sign:
                    self.right_sign = right_sign[-1]
                else:
                    self.right_sign = ''
                self.operand2 = Function(func, signals, self.right_sign, user_signals=self.user_signals)
                if self.operand2.missing_signals:
                    self.missing_signals = True
            else:
                # right is a level

                right_pattern = (
                    r'\SPACES*(?P<string>(?i)(RISING|FALLING|ELEVATION)\SPACES*',
                    r'\(\SPACES*(!=|==|<=|>=|<|>)?\SPACES*',
                    r'({0.start}(?!{0.end}).+{0.end}|[^, ]+)\SPACES*,\SPACES*',
                    r'(!=|==|<=|>=|<|>)?\SPACES*',
                    r'({0.start}(?!{0.end}).+{0.end}|[^) ]+)\SPACES*',
                    r'\))',
                    r'(?P<options>((once|delay|until|within|for|count)\SPACES+.+\SPACES+tolerance\SPACES+.+|tolerance\SPACES+.+|(once|delay|until|within|for|count)(\SPACES+.+)?)?)'
                )

                match = fullmatch(''.join(right_pattern).format(Delimiters).replace('\SPACES', SPACES), right)

                if match:
                    self.operand2 = Constant(match.group('string'))
                else:

                    # ims replaced
                    right_pattern = (
                        r'\SPACES*(?P<right_sign>[\+-]+)?\SPACES*({0.start}(?P<operand2_param>(?!{0.end}).+?){0.end}|(?P<operand2_adhoc>.+?(?=(once|delay|until|within|for|count|tolerance|$|\n))))\SPACES*'
                        r'(?P<options>((once|delay|until|within|for|count)\SPACES+.+\SPACES+tolerance\SPACES+.+|tolerance\SPACES+.+|(once|delay|until|within|for|count)(\SPACES+.+)?)?)'
                    )

                    right_pattern = ''.join(right_pattern).format(Delimiters).replace('\SPACES', SPACES)

                    match = fullmatch(right_pattern, right)

                    if match is None:
                        raise EvaluateError('could not parse right operand: "{}"'.format(self.string))

                    right_sign = match.group('right_sign')
                    if right_sign:
                        self.right_sign = right_sign[-1]
                    else:
                        self.right_sign = ''

                    if match.group('operand2_param'):
                        operand_str = match.group('operand2_param').strip()
                        if operand_str[0] in ' -+0123456789':
                            self.operand2 = Constant(operand_str)
                        else:
                            if operand_str.startswith('__'):
                                if operand_str not in self.user_signals:
                                    self.user_signals[operand_str] = Signal([], [], name=operand_str)
                                self.operand2 = self.user_signals[operand_str]
                            elif operand_str in signals:
                                self.operand2 = signals[operand_str]
                            else:
                                self.operand2 = None
                                self.missing_signals = True

                    elif match.group('operand2_adhoc'):
                        self.operand2 = Constant(match.group('operand2_adhoc'))
                    else:
                        raise EvaluateError('could not parse right operand: "{}"'.format(self.string))
                    if self.right_sign == '-':
                        self.operand2 = -self.operand2

            options = match.group('options').strip()

            if options:
                pattern = (
                    r'(?P<delay_and_tol>(once|delay|until|within|for|count)\SPACES+.+\SPACES+tolerance\SPACES+.+)'
                    r'|'
                    r'(?P<tol_only>tolerance\SPACES+.+)'
                    r'|'
                    r'(?P<delay_only>(once|delay|until|within|for|count)(\SPACES+.+)?)'
                )

                match = fullmatch(''.join(pattern).format(Delimiters).replace('\SPACES', SPACES), options)

                if match.group('delay_and_tol'):
                    pattern = r'(?P<delay_type>(once|delay|until|within|for|count))\SPACES+(?P<delay_value>.+)\SPACES+tolerance\SPACES+(?P<tolerance>.+)'
                    match = fullmatch(
                        ''.join(pattern).format(Delimiters).replace('\SPACES',
                                                                    SPACES),
                        options)

                    self.delay_type = match.group('delay_type').strip()
                    delay = match.group('delay_value')
                    tolerance = match.group('tolerance').strip()

                elif match.group('tol_only'):
                    pattern = r'tolerance\SPACES+(?P<tolerance>.+)'
                    match = fullmatch(
                        ''.join(pattern).format(Delimiters).replace('\SPACES',
                                                                    SPACES),
                        options)

                    tolerance = match.group('tolerance').strip()
                    delay = None
                elif match.group('delay_only'):
                    pattern = r'(?P<delay_type>(once|delay|until|within|for|count))(\SPACES+(?P<delay_value>.*))?'
                    match = fullmatch(
                        ''.join(pattern).format(Delimiters).replace('\SPACES',
                                                                    SPACES),
                        options)

                    self.delay_type = match.group('delay_type').strip()
                    delay = match.group('delay_value')
                    tolerance = None

            else:
                tolerance = delay = None

            if delay:
                pattern = (
                    r'\SPACES*(?P<delay_proc_ref>.+)\SPACES*;\SPACES*(?P<delay_proc_val>.+)\SPACES*[%]\SPACES*'
                    r'|'
                    r'\SPACES*(?P<delay_low>.+)\SPACES*;\SPACES*(?P<delay_high>.+)\SPACES*'
                    r'|'
                    r'\SPACES*(?P<delay_fixed>.+)\SPACES*'
                )

                match = fullmatch(
                    ''.join(pattern).format(Delimiters).replace('\SPACES',
                                                                SPACES),
                    delay)

                if not match:
                    raise EvaluateError(
                        'Could not parse delay definition <{}> from condition <{}>'.format(
                            delay,
                            self.string,
                        )
                    )

                delay_type = self.delay_type

                if delay_type == 'count':
                    delay_fixed = parse_item(
                        match.group('delay_fixed'),
                        self.signals,
                        self.user_signals,
                    )
                    self.delay_low = self.delay_high = delay_fixed
                else:

                    if match.group('delay_proc_ref'):
                        value = parse_item(
                            match.group('delay_proc_ref'),
                            self.signals,
                            self.user_signals,
                        )

                        proc = parse_item(
                            match.group('delay_proc_val'),
                            self.signals,
                            self.user_signals,
                        )

                        if value is not None and proc is not None:
                            self.delay_low = value * (100 - proc) / 100
                            self.delay_high = value * (100 - proc) / 100
                        else:
                            self.missing_signals = True
                            self.delay_low = None
                            self.delay_high = None

                    elif match.group('delay_low'):
                        self.delay_low = parse_item(
                            match.group('delay_low'),
                            self.signals,
                            self.user_signals,
                        )

                        self.delay_high = parse_item(
                            match.group('delay_high'),
                            self.signals,
                            self.user_signals,
                        )

                        if self.delay_high is None or self.delay_low is None:
                            self.missing_signals = True

                    elif match.group('delay_fixed'):

                        delay_fixed = parse_item(
                            match.group('delay_fixed'),
                            self.signals,
                            self.user_signals,
                        )
                        self.delay_low = self.delay_high = delay_fixed

                        if self.delay_high is None or self.delay_low is None:
                            self.missing_signals = True

            if tolerance:
                self.tolerance = parse_item(tolerance, self.signals, self.user_signals)

                if self.tolerance is None:
                    self.missing_signals = True

        else:
            raise EvaluateError('Could not parse Condition: {}'.format(self.string))

    def __repr__(self):
        return 'Condition {{ relation={} negate={} operand1={} op="{}" operand2={} delaytype={} delaylow={} delayhigh={} tolerance={} }}'\
            .format(
                self.relation,
                self.negate,
                self.operand1,
                self.op,
                self.operand2,
                self.delay_type,
                self.delay_low,
                self.delay_high,
                self.tolerance,
            )

    def evaluate(self, start=None, stop=None, use_previous_sample=False):
        """Evaluate

        Runs the condition's evaluation with respect to the `start` and `stop` timestamps.

        Parameters
        ----------
        start : float
            start time; default `START_OF_MEASUREMENT`
        stop : float
            stop time; default `END_OF_MEASUREMENT`
        debug : bool
            debug option
        use_previous_sample : bool
            option to use previous samples, in case of Trigger evaluation;
            default *False*

        Returns
        -------
        result : Result
            the result contains the passed indexes, lval, rval and tolerance

        """
        if self.missing_signals:
            return None

        if not self.string:
            raise EvaluateError('Attempting to evaluate an empty condition')

        LOGGER.debug('COND EVALUATE PRE')
        LOGGER.debug(self.operand1)
        LOGGER.debug(self.operand2)

        if start is None:
            first_stamps = [
                signal.time[0]
                for signal in self.signals.values()
                if len(signal)
            ]

            start = np.float32(min(first_stamps))

        if stop is None:
            last_stamps = [
                signal.time[-1]
                for signal in self.signals.values()
                if len(signal)
            ]

            stop = np.float32(max(last_stamps))

        delay_low = self.delay_low
        delay_high = self.delay_high

        if isinstance(delay_low, Signal):
            delay_low = delay_low.cut(start, stop)
        elif isinstance(delay_low, Function):
            delay_low = delay_low.evaluate(start, stop)

        delay_low = to_seconds(delay_low)

        if isinstance(delay_high, Signal):
            delay_high = delay_high.cut(start, stop)
        elif isinstance(delay_high, Function):
            delay_high = delay_high.evaluate(start, stop)

        delay_high = to_seconds(delay_high)

        if self.delay_type == 'delay':
            if start == stop:
                start, stop = start + delay_low, stop + delay_high
            else:
                start, stop = start + delay_low, stop

        elif self.delay_type == 'until':
            start, stop = start, stop + delay_low

        elif self.delay_type == 'within':
            start, stop = start, stop + delay_high

        else:
            start, stop = start, stop

        self.start, self.stop = start, stop

        try:
            message = "Evaluating condition: '{}' from {:.4f}s to {:.4f}s".format(self.string, start, stop)
        except:
            message = "Evaluating condition: '{}' from {}s to {}s".format(
                self.string, start, stop)

        LOGGER.debug(compat_log(message))

        if self.operand2.type == FUNCTION:
            rval = self.operand2.evaluate(start, stop)
        elif self.operand2.type == SIGNAL:
            rval = self.operand2.cut(start, stop)
        elif self.operand2.type == CONSTANT:
            rval = self.operand2

        if self.operand1.type == FUNCTION:
            if self.operand1.func_type == 'DEFINE':
                self.operand1.args.append(rval)
            lval = self.operand1.evaluate(start, stop)

        elif self.operand1.type == SIGNAL:
            lval = self.operand1.cut(start, stop)
        elif self.operand1.type == CONSTANT:
            lval = self.operand1

        if isinstance(self.tolerance, Constant):
            tolerance = self.tolerance.x
            tol = self.tolerance
        elif isinstance(self.tolerance, Function):
            tolerance = self.tolerance.evaluate(start, stop)
            if isinstance(tolerance, Constant):
                tol = tolerance
                tolerance = tolerance.x
        elif isinstance(self.tolerance, Signal):
            tolerance = tol = self.tolerance.cut(start, stop)
        else:
            tolerance = self.tolerance
            tol = tolerance

        if lval.type == SIGNAL and rval.type == CONSTANT:
            dim = len(lval)
            if isinstance(tolerance, Signal):
                tol = tolerance.interp(lval.time)
                tolerance = tol.signal

            if rval.const_type == CONST_TYPE_SCALAR:
                if self.op == '==':

                    idx1 = np.argwhere(lval.signal <= rval.x + tolerance).flatten()
                    idx2 = np.argwhere(lval.signal >= rval.x - tolerance).flatten()
                    idx = np.intersect1d(idx1, idx2).flatten()

                elif self.op == '!=':
                    idx1 = np.argwhere(lval.signal > rval.x + tolerance).flatten()
                    idx2 = np.argwhere(lval.signal < rval.x - tolerance).flatten()
                    idx = np.union1d(idx1, idx2).flatten()

                else:
                    level1 = rval.x - tolerance
                    level2 = rval.x + tolerance
                    op = getattr(lval.signal, OPS[self.op])

                    idx = np.argwhere(op(level1) | op(level2)).flatten()

            elif rval.const_type == CONST_TYPE_COMPLEX:
                dim -= 1
                prev_sample = lval[:-1]
                next_sample = lval[1:]
                c1 = getattr(prev_sample, OPS[rval.op1])
                c2 = getattr(next_sample, OPS[rval.op2])
                idx = np.argwhere(c1(rval.val1) & c2(rval.val2)).flatten() + 1

            if use_previous_sample:
                idx -= 1
                invalid = np.argwhere(idx < 0)
                idx[invalid] = 0

            result = Result(
                idx,
                lval,
                rval,
                tol,
                self.op,
            )
        elif lval.type == CONSTANT and rval.type == SIGNAL:
            dim = len(rval)
            if isinstance(tolerance, Signal):
                tol = tolerance.interp(rval.time)
                tolerance = tol.signal

            if lval.const_type == CONST_TYPE_SCALAR:
                if self.op == '==':
                    idx1 = np.argwhere(rval.signal <= lval.x + tolerance).flatten()
                    idx2 = np.argwhere(rval.signal >= lval.x - tolerance).flatten()
                    idx = np.intersect1d(idx1, idx2).flatten()

                elif self.op == '!=':
                    idx1 = np.argwhere(rval.signal > lval.x + tolerance).flatten()
                    idx2 = np.argwhere(rval.signal < lval.x - tolerance).flatten()
                    idx = np.union1d(idx1, idx2).flatten()

                else:
                    level1 = lval.x - tolerance
                    level2 = lval.x + tolerance
                    op = getattr(rval.signal, OPS[self.op])

                    idx = np.argwhere(op(level1) | op(level2)).flatten()

            elif lval.const_type == CONST_TYPE_COMPLEX:
                prev = rval[:-1]
                next = rval[1:]
                c1 = getattr(prev, OPS[lval.op1])
                c2 = getattr(next, OPS[lval.op2])
                idx = np.argwhere(c1(lval.val1) & c2(lval.val2)).flatten() + 1

            if use_previous_sample:
                idx -= 1
                invalid = np.argwhere(idx < 0)
                idx[invalid] = 0

            result = Result(
                idx,
                lval,
                rval,
                tol,
                self.op,
            )

        elif lval.type == SIGNAL and rval.type == SIGNAL:
            time = np.union1d(lval.time, rval.time)
            lval_ = lval.interp(time).astype(lval.signal.dtype)
            lval = lval_.signal
            rval_ = rval.interp(time).astype(rval.signal.dtype)
            rval = rval_.signal
            if isinstance(tolerance, Signal):
                tol = tolerance.interp(time)
                tolerance = tol.signal

            if lval.dtype.kind == 'f' and rval.dtype.kind == 'f':
                if lval.itemsize > rval.itemsize:
                    lval = lval.astype(rval.dtype)
                elif rval.itemsize > lval.itemsize:
                    rval = rval.astype(lval.dtype)

            if rval.dtype.kind in 'ui':
                idx = np.argwhere(rval + tolerance < rval)
                s1 = rval + tolerance
                s1[idx] = np.iinfo(rval.dtype).max

                idx = np.argwhere(rval - tolerance > rval)
                s2 = rval - tolerance
                s2[idx] = np.iinfo(rval.dtype).min

                if self.op == '==':
                    idx1 = np.argwhere(lval <= s1)
                    idx2 = np.argwhere(lval >= s2)
                    idx = np.intersect1d(idx1, idx2).flatten()

                elif self.op == '!=':
                    idx1 = np.argwhere(lval > s1)
                    idx2 = np.argwhere(lval < s2)
                    idx = np.union1d(idx1, idx2).flatten()

                else:
                    op = getattr(lval, OPS[self.op])

                    idx1 = np.argwhere(op(s1))
                    idx2 = np.argwhere(op(s2))
                    idx = np.union1d(idx1, idx2).flatten()

            else:
                s1 = rval + tolerance
                s2 = rval - tolerance

                if self.op == '==':
                    idx1 = np.argwhere(lval <= s1)
                    idx2 = np.argwhere(lval >= s2)
                    idx = np.intersect1d(idx1, idx2).flatten()
                elif self.op == '!=':
                    idx1 = np.argwhere(lval > s1)
                    idx2 = np.argwhere(lval < s2)
                    idx = np.union1d(idx1, idx2).flatten()
                else:
                    op = getattr(lval, OPS[self.op])

                    idx1 = np.argwhere(op(s1))
                    idx2 = np.argwhere(op(s2))
                    idx = np.union1d(idx1, idx2).flatten()

            if use_previous_sample:
                idx -= 1
                invalid = np.argwhere(idx < 0)
                idx[invalid] = 0

            result = Result(
                idx,
                lval_,
                rval_,
                tol,
                self.op,
            )

        elif lval.type == CONSTANT and rval.type == CONSTANT:
            if isinstance(tolerance, Signal):
                dim = len(tolerance)
                time = tolerance.time
                tol = tolerance
                tolerance = tolerance.signal
                if self.op == '==':
                    idx = np.argwhere(abs(lval.x - rval.x) <= tolerance).flatten()

                elif self.op == '!=':
                    idx = np.argwhere(abs(lval.x - rval.x) > tolerance).flatten()

                else:
                    v1 = lval.x - tolerance
                    v2 = lval.x + tolerance
                    c1 = getattr(v1, OPS[self.op])
                    c2 = getattr(v2, OPS[self.op])
                    idx1 = np.argwhere(c1(rval.x))
                    idx2 = np.argwhere(c2(rval.x))
                    idx = np.union1d(idx1, idx2).flatten()

                if use_previous_sample:
                    idx -= 1
                    invalid = np.argwhere(idx < 0)
                    idx[invalid] = 0

                result = Result(
                    idx,
                    lval,
                    rval,
                    tol,
                    self.op,
                )

            else:
                dim = 1
                if self.op == '==':
                    if abs(lval.x - rval.x) <= tolerance:
                        result = Result(
                            np.array([0,]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )
                    else:
                        result = Result(
                            np.array([]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )
                elif self.op == '!=':
                    if abs(lval.x - rval.x) > tolerance:
                        result = Result(
                            np.array([0,]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )
                    else:
                        result = Result(
                            np.array([]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )
                else:
                    v1 = lval.x - tolerance
                    v2 = lval.x + tolerance
                    c1 = getattr(v1, OPS[self.op])
                    c2 = getattr(v2, OPS[self.op])
                    if c1(rval.x) or c2(rval.x):
                        result = Result(
                            np.array([0,]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )
                    else:
                        result = Result(
                            np.array([]),
                            lval,
                            rval,
                            tol,
                            self.op,
                        )

        if self.negate:
            result = result.negate()
        message = str(result)
        LOGGER.debug(compat_log(message))
        LOGGER.debug('COND EVALUATE POST')
        LOGGER.debug(self.operand1)
        LOGGER.debug(self.operand2)

        return result


class Testcase:
    """Testcase

    A testcase is parsed from the input string, and has the associated signals.

    The input string has to sanitized first: this means the keywords have been
    replaced with their definition, and the comments have been removed.

    After the ``evaluate`` method is called, the triggers and evaluators can be
    inspected to see the trigger timestamps and individual evaluator verdict.

    Parameters
    ----------
    string : str
        string to be parsed for condition definition
    signals : dict
        dictionary of `Signal` objects loaded from the measurement file
    id : str
        test case ID, default is ''
    description : str
        test case description
    status : str
        testcase status as string
    requirements : list
        list of requirements covered by this testcase; default *None*

    Attributes
    ----------
    id : str
        test case ID
    string : str
        initial testcase string definition
    signals : dict
        dictionary of `Signal` objects loaded from the measurement file
    triggers : OrderedDict
        dictionary of triggers (type `Trigger`)
    evaluators : OrderedDict
        dictionary of evaluators (type `Evaluator`)
    graphs : OrderedDict
        dictionary of graph definitions
    result : Verdict
        cached test case evaluation result
    comments : str
        cached test case evaluation comments
    log : str
        evaluation log
    stringio : io.StringIO
        StringIO object used for logging by this testcase
    description : str
        test case description
    status : str
        testcase status
    requirements : list
        lsit of requirments covered by the testcase

    """

    @classmethod
    def verify(cls, string):
        """ minimal verification that a Testcase has proper syntax

        Parameters
        ----------
        string : str
            testcase string

        Examples
        --------
        >>> testcase_string_ok = "..."
        >>> Testcase.verify(testcase_string)
        True
        >>> testcase_string_nok = "..."
        >>> Testcase.verify(testcase_string)
        False

        """

        class DummySignals(dict):

            def __init__(self):
                super(DummySignals, self).__init__()

            def __getitem__(self, item):
                return Signal([], [], name=item)

            def __contains__(self, value):
                return True

        signals = DummySignals()
        return cls(string, signals)

    def __init__(self, string, signals, id='', description='',
                 status='', requirements=None):

        ConditionGroup.counter = 0
        self.user_signals = {}
        self.id = id
        self.description = description
        self.string = string
        self.signals = signals

        self.first_timestamp = None
        self.last_timestamp = None

        self.result = None
        self.comments = ''
        self.log = ''
        self.stringio = StringIO()

        self.requirements = requirements or []
        self.interfaces = [signal for signal in signals]
        self.status = status

    def get_triggers(self):
        """get_triggers

        Parses the testcase string definition and returns the triggers.

        Returns
        -------
        triggers : OrderedDict
            dictionary of `Trigger` objects

            .. note::

                the keys are the trigger names (eg. "T1")

        Examples
        --------
        >>> input_string = '''T1:
        ... "MAIN__si16EPSTorque" == RISING(0,>1)
        ... OR "MAIN__si16EPSTorque" == FALLING(0,<-1)
        ...
        ... T2:
        ... "MAIN__si16EPSTorque" == FALLING(>1,0)
        ... OR "MAIN__si16EPSTorque" == RISING(<-1,0)
        ...
        ... T3:
        ... T2 + 500
        ...
        ... INT_ET1_ET2:
        ... ABS(DIFF(ABS("AI.MotTorque"), ABS("MAIN__si16EPSTorque"))) < 1 delay 200 ms
        ...
        ... INT_ET2_ET3:
        ... DIFF("AI.MotTorque", "MAIN__si16EPSTorqueLim") == 0 delay 200 ms tolerance 1'''
        >>> tc = Testcase(input_string, signals)
        >>> tc.get_triggers()
        OrderedDict([('T1', <__main__.Trigger object at 0x00000000005E6DD8>),
                     ('T2', <__main__.Trigger object at 0x00000000005E6DE8>),
                     ('T3', <__main__.Trigger object at 0x00000000005E6DF8>)])

        """
        string = self.string

        triggers = OrderedDict()
        pattern = (r'^\SPACES*(?<!((?i)E|(?i)C))'                     # prevent ETx, ECTx missinterpretation
                   r'(?P<name>((?i)T[0-9]+|(?i)CT[0-9]+))\SPACES*'
                   r':\SPACES*(?P<comment>.+)?\n'
                   r'\SPACES*(?P<trigger_string>('
                   r'('                                      # next line is not:
                   r'(?!(?i)\SPACES*T[0-9]+\s*:)'            # a simple Trigger definition
                   r'(?!(?i)\SPACES*CT[0-9]+\s*:)'           # a cumulative Trigger definition
                   r'(?!(?i)\SPACES*ET[0-9]+\SPACES*:)'      # an Evaluator definition
                   r'(?!(?i)\SPACES*ECT[0-9]+\SPACES*:)'     # an cumulative Evaluator definition
                   r'(?!(?i)\SPACES*INT_ET[0-9]+)'           # an interval Evaluator definition
                   r'(?!(?i)\SPACES*INT_ECT[0-9]+)'          # an cumulative interval Evaluator definition
                   r'(?!(?i)\SPACES*G[0-9]+\SPACES*:)'       # a Graph definition
                   r'(?!(?i)\SPACES*option)'                 # global delay definition
                   r'(?!(?i)\SPACES*Statistics\SPACES*:)'    # statistics definition
                   r')'
                   r'.+(\n|$))+)').replace('\SPACES', SPACES)
        matches = re.finditer(pattern, string, re.M)
        for match in matches:
            if match.group('name').startswith('CT'):
                cumulative = True
            else:
                cumulative = False
            triggers[match.group('name')] = Trigger(
                match.group('trigger_string').strip(),
                self.signals,
                name=match.group('name'),
                comment=match.group('comment'),
                cumulative=cumulative,
                user_signals=self.user_signals,
            )
        if not triggers:
            raise EvaluateError('No triggers found in the test specification')
        return triggers

    def get_evaluators(self):
        """get_evaluators

        Parses the testcase string definition and returns the evaluators.

        Returns
        -------
        evaluators : OrderedDict
            dictionary of `Trigger` objects

            .. note::

                the keys are the evaluator names (eg. "ET1", "INT_ET1_ET2")

        Examples
        --------
        >>> input_string = '''T1:
        ... "MAIN__si16EPSTorque" == RISING(0,>1)
        ... OR "MAIN__si16EPSTorque" == FALLING(0,<-1)
        ...
        ... T2:
        ... "MAIN__si16EPSTorque" == FALLING(>1,0)
        ... OR "MAIN__si16EPSTorque" == RISING(<-1,0)
        ...
        ... T3:
        ... T2 + 500
        ...
        ... INT_ET1_ET2:
        ... ABS(DIFF(ABS("AI.MotTorque"), ABS("MAIN__si16EPSTorque"))) < 1 delay 200 ms
        ...
        ... INT_ET2_ET3:
        ... DIFF("AI.MotTorque", "MAIN__si16EPSTorqueLim") == 0 delay 200 ms tolerance 1'''
        >>> tc = Testcase(input_string, signals)
        >>> tc.get_evaluators()
        OrderedDict([('INT_ET1_ET2', <__main__.Evaluator object at 0x00000000005E6DD8>),
                     ('INT_ET2_ET3', <__main__.Evaluator object at 0x00000000005E6DE8>)])
        """
        string = self.string
#        string = remove_comments(string)
        global_delay = 0.0

        # this has to be removed if the IMS export starts to work correctly
#        string = string.splitlines()
#        new_string = []
#        for line in string:
#            if ':' in line:
#                line = line.split(':')
#                if line[1].strip():
#                    new_string.append(line[0] + ':')
#                    new_string.append(line[1])
#                else:
#                    new_string.append(line[0] + ':')
#            else:
#                new_string.append(line)
#        string = '\n'.join(new_string)
        # remove until this line

        #search for global evaluation delay
        pattern = (r'\SPACES*((?i)option)'
                   r'\SPACES*((?i)GlobalEvaluationDelay)'
                   r'\SPACES*(?P<delay>[0-9.eE\-]+)'
                   r'\SPACES*(?P<unit>(?i)ms|ns|us|s)?').replace('\SPACES', SPACES)
        matches = re.finditer(pattern, string)
        for match in matches:
            global_delay = Constant(match.group('delay'))
            unit = match.group('unit')
            global_delay = to_seconds(global_delay, unit)

        evaluators = OrderedDict()
        pattern = (r'^(?P<evaluator_str>(?<!_)'               # must not start with _
                   r'\SPACES*(?P<name>((?i)ET[0-9]+|(?i)ECT[0-9]+|(?i)INT_ET[0-9]+_ET[0-9]+|(?i)INT_ECT[0-9]+_ECT[0-9]+))'
                   r'\SPACES*:\SPACES*(?P<comment>.+)?\n('
                   r'('                                      # next line is not:
                   r'(?!(?i)\SPACES*T[0-9]+\s*:)'            # a simple Trigger definition
                   r'(?!(?i)\SPACES*CT[0-9]+\s*:)'           # a cumulative Trigger definition
                   r'(?!(?i)\SPACES*ET[0-9]+\SPACES*:)'      # an Evaluator definition
                   r'(?!(?i)\SPACES*ECT[0-9]+\SPACES*:)'     # an cumulative Evaluator definition
                   r'(?!(?i)\SPACES*INT_ET[0-9]+)'           # an interval Evaluator definition
                   r'(?!(?i)\SPACES*INT_ECT[0-9]+)'          # an cumulative interval Evaluator definition
                   r'(?!(?i)\SPACES*G[0-9]+\SPACES*:)'       # a Graph definition
                   r'(?!(?i)\SPACES*option)'                 # global delay definition
                   r'(?!(?i)\SPACES*Statistics)'             # statistics definition
                   r')'
                   r'.+(\n|$))+)').replace('\SPACES', SPACES)

        matches = re.finditer(pattern, string, re.M)
        for match in matches:
            if 'ECT' in match.group('name'):
                cumulative = True
            else:
                cumulative = False
            evaluators[match.group('name')] = Evaluator(
                match.group('evaluator_str'),
                self.signals,
                global_delay,
                name=match.group('name'),
                comment=match.group('comment'),
                cumulative=cumulative,
                user_signals=self.user_signals,
            )
        if not evaluators:
            raise EvaluateError('No evaluators found in the test specification')

        return evaluators

    def get_stats_definition(self):
        """get_stats_definition

        Parses the tescase string definition for statistics definitions

        Returns
        -------
        keywords : dict
            dictionary of found graph

            .. note::

                * the dictionary keys are the graph numbers
                * each value is a dictionary with the following attributes

                    * title : str
                    * start trigger name, stop trigger name, function : tuple

        Examples
        --------
        >>> input_string = '''Statistics:
        ... mot speed avg [rpm]: : T23: NP_mean("SigMotSpeed") // start of measurement to T23
        ... max force [Nm]: : : MAX("AxialForce")''' // from measurement start to measurement stop
        ... min force [Nm]: T10: T23: MIN("AxialForce")''' // from T10 to T23
        >>> tc = Testcase(input_string, signals)
        >>> tc.get_stats_definition()
        OrderedDict([('mot speed avg [rpm]', <evaluate.core.Function object at 0x0000016661812668>),
                     ('max force [Nm]', <evaluate.core.Function object at 0x0000016661812978>),
                     ('min force [Nm]', <evaluate.core.Function object at 0x000001666184298E>)])

        """
        string = remove_comments(self.string)

        pattern = (r'(?P<definition>'
                   r'\SPACES*(?P<name>(?i)Statistics)'
                   r'\SPACES*:\SPACES*\n'
                   r'\SPACES*(?P<item_list>('
                   r'('                                      # next line is not:
                   r'(?!(?i)\SPACES*T[0-9]+\s*:)'            # a Trigger definition
                   r'(?!(?i)\SPACES*ET[0-9]+\SPACES*:)'      # an Evaluator definition
                   r'(?!(?i)\SPACES*INT_ET[0-9]+)'           # an Evaluator definition
                   r'(?!(?i)\SPACES*G[0-9]+\SPACES*:)'       # a Graph definition
                   r'(?!(?i)\SPACES*option)'                 # global delay definition
                   r')'
                   r'.+(\n|$))+))').format(Delimiters).replace('\SPACES', SPACES)
        matches = re.finditer(pattern, string)

        stats = OrderedDict()

        for i, match in enumerate(matches):
            item_list = match.group('item_list')

            pattern = r'\SPACES*(?P<title>[^:]+):(\SPACES*(?P<start>T[^:]+)?:\SPACES*(?P<stop>T[^:]+)?:)?\SPACES*(?P<function>[^:]+)(:\SPACES*(?P<red>[^:]*):\SPACES*(?P<green>[^:]*)?(:\SPACES*(?P<check>(YES|NO))\SPACES*)?)?'.replace('\SPACES', SPACES)
            for line in item_list.splitlines():
                match = re.search(pattern, line)
                if match:
                    title = match.group('title').strip()
                    start = match.group('start')
                    if start is None:
                        start = ''
                    else:
                        start = start.strip()
                    stop = match.group('stop')
                    if stop is None:
                        stop = ''
                    else:
                        stop = stop.strip()
                    function = match.group('function').strip()
                    function = Function(function, self.signals)

                    pattern2 = (
                        r'(\SPACES*(?P<rel>[><=!]*)\SPACES*(?P<adhoc>.+)\SPACES*)'
                        r'|'
                        r'(\SPACES*(?P<rel_replaced>[><=!]*)\SPACES*{0.start}(?P<replaced>(?!{0.end}).+){0.end}\SPACES*)'
                    )
                    pattern2 = pattern2.replace('\SPACES', SPACES)

                    red = match.group('red')
                    green = match.group('green')
                    check = match.group('check')

                    if red is not None:
                        red = red.strip()
                        if red:
                            match = fullmatch(pattern2, red)
                            if match:
                                if match.group('adhoc'):
                                    red = (
                                        match.group('rel'),
                                        Constant(match.group('adhoc')),
                                    )
                                else:
                                    red = (
                                        match.group('rel_replaced'),
                                        Constant(match.group('replaced')),
                                    )

                            else:
                                raise EvaluateError('wrong statistics definition in: {}'.format(line))
                        else:
                            red = None

                    if green is not None:
                        green = green.strip()
                        if green:
                            match = fullmatch(pattern2, green)
                            if match:
                                if match.group('adhoc'):
                                    green = (
                                        match.group('rel'),
                                        Constant(match.group('adhoc')),
                                    )
                                else:
                                    green = (
                                        match.group('rel_replaced'),
                                        Constant(match.group('replaced')),
                                    )

                            else:
                                raise EvaluateError('wrong statistics definition')
                        else:
                            green = None

                    if check:
                        if check == 'YES':
                            check = True
                        else:
                            check = False

                    stats[title] = start, stop, function, red, green, check

        return stats

    def get_graphs_definition(self):
        """get_graphs_definition

        Parses the tescase string definition for graph definitions

        Returns
        -------
        keywords : dict
            dictionary of found graph

            .. note::

                * the dictionary keys are the graph numbers
                * each value is a dictionary with the following attributes

                    * title : str
                    * signal_names : list of signal name strings
                    * arch_names : list of architecture name strings

        Examples
        --------
        >>> input_string = '''G101:
        ... title "EBA status"
        ... "Functions[0].EBAstatus[3]" EBAStatus
        ...
        ... G1:
        ... title "Braking vs Speed"
        ... "Car.v" vechicleSpeed
        ... "Brk.Pedal.Level" brakePedal
        ...
        ... G2:
        ... title "Pedestrian detection"
        ... "Radar.Left.Objects[0].Level" leftObject
        ... "Radar.Right.Objects[0].Level" rightObject'''
        >>> tc = Testcase(input_string, signals)
        >>> tc.get_graphs_definition()
        OrderedDict([('G1', {'title': 'G1: Braking vs Speed',
                             'arch_names': ['vechicleSpeed', 'brakePedal'],
                             'signal_names': ['Car.v', 'Brk.Pedal.Level']}),
                     ('G2', {'title': 'G2: Pedestrian detection',
                             'arch_names': ['leftObject', 'rightObject'],
                             'signal_names': ['Radar.Left.Objects[0].Level', 'Radar.Right.Objects[0].Level']}),
                     ('G101', {'title': 'G101: EBA status',
                               'arch_names': ['EBAStatus'],
                               'signal_names': ['Functions[0].EBAstatus[3]']})])

        """
        string = remove_comments(self.string)
        graphs = OrderedDict()

        pattern = (r'(?P<definition>'
                   r'\SPACES*(?P<name>(?i)G[0-9]+)'
                   r'\SPACES*:\SPACES*\n'
                   r'\SPACES*((?i)title\SPACES*:?\SPACES*{0.start}(?P<title>(?!{0.end}).+){0.end}\SPACES*\n)?'
                   r'\SPACES*(?P<item_list>('
                   # r'(?<!\)\n)'                              # previous line did not end in )\n
                   r'('                                      # next line is not:
                   r'(?!(?i)\SPACES*T[0-9]+\s*:)'            # a Trigger definition
                   r'(?!(?i)\SPACES*ET[0-9]+\SPACES*:)'      # an Evaluator definition
                   r'(?!(?i)\SPACES*INT_ET[0-9]+)'           # an Evaluator definition
                   r'(?!(?i)\SPACES*G[0-9]+\SPACES*:)'       # a Graph definition
                   r'(?!(?i)\SPACES*option)'                 # global delay definition
                   r'(?!(?i)\SPACES*Statistics)'             # statistics definition
                   r')'
                   r'.+(\n|$))+))').format(Delimiters).replace('\SPACES', SPACES)

        matches = re.finditer(pattern, string)

        for i, match in enumerate(matches):
            definition = match.group('definition')
            graph_name = 'G{}'.format(i+1)
            title = match.group('title')
            if title is None:
                title = graph_name
            item_list = match.group('item_list')

            sig_or_const = (
                r'\SPACES*{0.start}(?P<signal_name>(?!{0.end}).+){0.end}\SPACES*(?P<legend_name>.*)?'
                .format(Delimiters)
                .replace('\SPACES', SPACES)
            )

            function = (
                r'\SPACES*(?P<sign>[\+-]+)?\SPACES*(?P<func>({})[^ \t\(]*\SPACES*\(.+\))\SPACES*(?P<legend_name>.*)?'
                .format('|'.join(AVAILABLE_FUNCTIONS))
                .replace('\SPACES', SPACES)
            )

            graphs[graph_name] = graph = {
                'definition': definition,
                'title': '{}: {}'.format(graph_name, title),
                'signals': OrderedDict(),
                'constants': OrderedDict(),
            }

            for line in item_list.splitlines():
                match = fullmatch(sig_or_const, line)
                if match:
                    legend_name = match.group('legend_name')
                    name = match.group('signal_name').strip()
                    if legend_name and legend_name.strip() != ')':
                        legend = (
                            legend_name
                            .strip()
                            .replace(Delimiters.start, '')
                            .replace(Delimiters.end, '')
                        )
                    else:
                        legend = name

                    if name in self.signals:
                        graph['signals'][legend] = self.signals[name]
                    else:
                        try:
                            graph['constants'][legend] = Constant(name)
                        except:
                            continue

                    continue

                match = fullmatch(function, line)
                if match:
                    legend_name = match.group('legend_name')
                    func = match.group('func').strip()

                    if legend_name and legend_name.strip() != ')':
                        legend = (
                            legend_name
                            .strip()
                            .replace(Delimiters.start, '')
                            .replace(Delimiters.end, '')
                        )
                    else:
                        legend = func.replace(Delimiters.start, '').replace(Delimiters.end, '')

                    try:
                        value = Function(
                            func,
                            self.signals,
                        ).evaluate()

                        sign = match.group('sign')
                        if sign and sign.strip() == '-':
                            value = -value

                        if isinstance(value, Signal):
                            graph['signals'][legend] = value
                        else:
                            graph['constants'][legend] = value
                    except:
                        continue

        return graphs

    def compute_stats(self):
        results = OrderedDict()

        for title, (start, stop, func, red, green, check) in self.stats.items():
            if start:
                start = self.triggers[start].timestamp
            else:
                start = self.first_timestamp

            if stop:
                stop = self.triggers[stop].timestamp
            else:
                stop = self.last_timestamp

            try:
                result = func.evaluate(start=start, stop=stop)
                result.x
            except:
                result = 'n.a.'

            passed = False
            if isinstance(result, str):
                background_color = None
            else:
                if red is None and green is None:
                    background_color = None
                elif green is None:
                    rel, red = red

                    conditions = (
                        rel == '>' and result > red,
                        rel == '>=' and result >= red,
                        rel == '<' and result < red,
                        rel == '<=' and result <= red,
                        rel == '!=' and result != red,
                        rel in ('', '==') and result == red,
                    )

                    if any(conditions):
                        background_color = 255, 0, 0
                    else:
                        background_color = 0, 255, 0
                        passed = True

                elif red is None:
                    rel, green = green

                    conditions = (
                        rel == '>' and result > green,
                        rel == '>=' and result >= green,
                        rel == '<' and result < green,
                        rel == '<=' and result <= green,
                        rel == '!=' and result != green,
                        rel in ('', '==') and result == green,
                    )

                    if any(conditions):
                        background_color = 0, 255, 0
                        passed = True
                    else:
                        background_color = 255, 0, 0

                else:
                    r_rel, red = red
                    g_rel, green = green

                    conditions = (
                        r_rel == '>' and result > red,
                        r_rel == '>=' and result >= red,
                        r_rel == '<' and result < red,
                        r_rel == '<=' and result <= red,
                        r_rel == '!=' and result != red,
                        r_rel in ('', '==') and result == red,
                    )

                    if any(conditions):
                        background_color = 255, 0, 0
                    else:

                        conditions = (

                            g_rel == '>' and result > green,
                            g_rel == '>=' and result >= green,
                            g_rel == '<' and result < green,
                            g_rel == '<=' and result <= green,
                            g_rel == '!=' and result != green,
                            g_rel in ('', '==') and result == green,
                        )

                        if any(conditions):
                            passed = True
                            background_color = 0, 255, 0
                        else:
                            if red.x > green.x:
                                x = np.array([green.x, red.x])
                                yr = np.array([90, 255])
                                yg = np.array([255, 90])
                            else:
                                x = np.array([red.x, green.x])
                                yg = np.array([90, 255])
                                yr = np.array([255, 90])

                            background_color = (
                                int(np.interp(result.x, x, yr)),
                                int(np.interp(result.x, x, yg)),
                                0,
                            )

                result = '{:.3f}'.format(result.x).rstrip('0').rstrip('.')
            if check and passed:
                mark_yellow = True
            else:
                mark_yellow = False

            results[title] = result, background_color, mark_yellow

        return results

    def evaluate(self, measurement=''):
        """Evaluates the test case using the supplied measurement files.

        Parameters
        ----------
        measurement : str
            measurement file name

        Returns
        -------
        results : `Verdict`
            testcase evalaution result
        comments : str
            testcase evaluation comments
        log : str
            testcase evaluation log

        """
        self.stringio = StringIO()
        log_formatter = logging.Formatter('%(message)s')
        log_handler = logging.StreamHandler(self.stringio)
        log_handler.setFormatter(log_formatter)
        log_handler.setLevel(logging.INFO)
        LOGGER.addHandler(log_handler)

        required_signals = get_signal_dependencies(self.string, delimiters=Delimiters)

        self.comments = ''
        self.result = None
        self.log = ''

        LOGGER.info(compat_log('='*13 + ' START '+ '='*13))
        LOGGER.info(compat_log('Tescase ID="{}" with measurement "{}"'.format(self.id, measurement)))
        if self.description:
            LOGGER.info(compat_log('-'*10 + ' DESCRIPTION '+ '-'*10))
            LOGGER.info(compat_log(self.description))
            LOGGER.info(compat_log('-' * 33))

        not_found_signals = set(
            sig
            for sig in required_signals
            if sig not in self.signals and not sig.startswith('__')
        )
        if not_found_signals:
            comment = 'The following required signals could not be found in the measurement:\n{}\n'\
                .format(', '.join(not_found_signals))
            LOGGER.info(compat_log(comment))
            self.comments += comment + '\n'

        self.triggers = self.get_triggers()
        self.evaluators = self.get_evaluators()
        self.graphs = self.get_graphs_definition()
        self.stats = self.get_stats_definition()

        # get the time axis interval
        last_stamps = [
            signal.time[-1]
            for signal in self.signals.values()
            if len(signal)
        ]
        first_stamps = [
            signal.time[0]
            for signal in self.signals.values()
            if len(signal)
        ]

        if last_stamps:
            last_stamp = np.float32(max(last_stamps))
        else:
            last_stamp = None

        if first_stamps:
            first_stamp = np.float32(min(first_stamps))
        else:
            first_stamp = None

        self.first_timestamp = first_stamp
        self.last_timestamp = last_stamp

        limits = (first_stamp, last_stamp)

        # resolve the simple trigger timestamps
        if first_stamp is not None and last_stamp is not None:
            start = first_stamp
            for name, trigger in self.triggers.items():
                if not trigger.cumulative:
                    if trigger.relative_trigger:
                        trigger.evaluate(
                            relative_timestamp=self.triggers[trigger.relative_trigger].timestamp,
                            limits=limits,
                        )
                    else:
                        trigger.evaluate(start=start, limits=limits)
                    if trigger.timestamp is not None:
                        if first_stamp <= trigger.timestamp <= last_stamp:
                            start = trigger.timestamp
                        else:
                            trigger.timestamp = None

            # resolve the cumulative trigger timestamps
            start = None
            stop = None
            for name, trigger in self.triggers.items():
                if trigger.cumulative:
                    if trigger.relative_trigger:
                        trigger.evaluate(
                            relative_timestamp=self.triggers[trigger.relative_trigger].timestamp,
                            stop=stop,
                            limits=limits,
                        )
                    else:
                        trigger.evaluate(
                            start=start,
                            stop=stop,
                            limits=limits,
                        )
                    if trigger.timestamp is not None:
                        for i, stamp in enumerate(trigger.timestamp):
                            if stamp is not None:
                                if not first_stamp <= stamp <= last_stamp:
                                    trigger.timestamp[i] = None
                        start = trigger.timestamp

                    if stop is None and start is not None:
                        stop = list(start[1:])
                        stop.append(last_stamp)

            not_found_triggers = [
                name
                for name, t in self.triggers.items()
                if t.cumulative is False and t.timestamp is None
            ]

            if not_found_triggers:
                comment = 'The following triggers could not be found in the measurement: ' + ', '.join(not_found_triggers)
                self.comments += comment + '\n'

            not_found_user_signals = set(
                sig
                for sig in required_signals
                if sig.startswith('__') and sig not in self.user_signals
            )
            if not_found_user_signals:
                comment = 'The following user defined signals could not be found in the measurement:\n{}\n'.format(
                    ', '.join(not_found_user_signals))
                LOGGER.info(compat_log(comment))
                self.comments += comment + '\n'

            # run the evaluation based on the trigger timestamps
            for name, e in self.evaluators.items():
                e.evaluate(self.triggers)

            LOGGER.info(compat_log(''))
            LOGGER.info(compat_log(''))
            LOGGER.info(compat_log('-' * 27))
            for name, e in self.evaluators.items():
                LOGGER.info(compat_log('{: <16} == {: <136}'.format(name, Verdict.to_string(e.verdict))))

            unknown_evaluations = [e_name for e_name, e in self.evaluators.items() if e.verdict == Verdict.unknown]
            if unknown_evaluations:
                self.result = Verdict.unknown
                comment = 'The following evaluations could not be done: {}'.format(', '.join(unknown_evaluations))
                self.comments += comment + '\n'

            failed_evaluations = [e_name for e_name, e in self.evaluators.items() if e.verdict == Verdict.failed]
            if failed_evaluations:
                self.result = Verdict.failed
                comment = 'The following evaluations are failed: \n'
                failed_e = []
                for name in failed_evaluations:
                    comm = '\n' + name + '\n'
                    failed_c = []
                    for i, (_, res, cond_res) in enumerate(self.evaluators[name].condition_group.results):
                        if res == Verdict.failed:
                            failed_c.append(
                                '\tCondGroup {} <<{}>>'\
                                    .format(i+1, self.evaluators[name].condition_group.items[i].string))
                    comm += ',\n'.join(failed_c)
                    failed_e.append(comm)
                comment += ', '.join(failed_e)
                self.comments += comment
            else:
                if not unknown_evaluations and not not_found_triggers:
                    self.result = Verdict.passed
                else:
                    self.result = Verdict.unknown
                    passed_evaluations = [e_name for e_name, e in self.evaluators.items() if e.verdict == Verdict.passed]
                    if len(passed_evaluations):
                        comment = 'The following evaluations are passed: {}'.format(', '.join(passed_evaluations))
                        self.comments += comment
        else:
            self.result = Verdict.unknown
            self.comments += "All signals are empty (no samples)"

        LOGGER.info(compat_log(''))
        LOGGER.info(compat_log('-' * 27))
        LOGGER.info(compat_log('{: <16} == {: <136}'.format('TEST RESULT', Verdict.to_string(self.result))))
        LOGGER.info(compat_log(''))
        LOGGER.info(compat_log('='*14 + ' END '+ '=' *14))

        for i in range(4):
            LOGGER.info(compat_log(''))

        self.stringio.seek(0)
        self.log = self.stringio.read()

        LOGGER.removeHandler(log_handler)

        return self.result, self.comments, self.log


class Function:
    """Function

    Functions can be used as left or right operands for 'Condition' objects.
    Functions can contain other `Function` objects as arguments.

    Parameters
    ----------
    string : str
        string to be parsed for the function definition
    signals : dict
        dictionary of `Signal` object loaded from the measurement file

    Attributes
    ----------
    type : str
        function name from the `AVAILABLE_FUNCTIONS`
    string : str
        initial string definition of the function
    args : list
        list of function arguments (objects of type: `Constant`, `Signal` or `Function`)
    sign : str
        unary fucntion sign

    Examples
    --------
    >>> f = Function('SUM("sIn1", 10e-7, ABS("sIn2"), PROD(9, "sIn3"))')
    >>> s = Signal(np.array([1, 2, 3, 13, 23]), np.array([0.1, 0.2, 0.3, 0.8, 1.3]), 'rpm', 'Sig')
    >>> signals = {'Sig': s}
    >>> Function('EDIFF("Sig")', signals).evaluate()
    Signal { name="Sig_DDiff":	s=[ 1  1 10 10]	t=[ 0.2  0.3  0.8  1.3] }
    >>> Function('GRAD("Sig")', signals).evaluate()
    Signal { name="Sig_Gradient":	s=[ 10.  10.  20.  20.]	t=[ 0.2  0.3  0.8  1.3] }

    """
    def __init__(self, string, signals, sign='', user_signals=None):
        string = remove_comments(string)
        LOGGER.debug(compat_log(string))
        self.sign = sign
        self.type = FUNCTION
        self.string = string
        self.user_signals = user_signals
        self.missing_signals = False

        pattern = r'\SPACES*(?P<func>[^ \t\(]+)\SPACES*\((?P<args>.*)\)\SPACES*'.replace('\SPACES', SPACES)
        match = fullmatch(pattern, string)
        if match:
            self.func_type = match.group('func')
            args = match.group('args')
        if not match or (self.func_type not in AVAILABLE_FUNCTIONS and not self.func_type.startswith('NP_')):
            raise EvaluateError('Could not parse function with definition:\n{}'.format(string))
        self.args = []

        state = 'empty'
        cntr = 0
        sign = ''
        replaced = False
        comma_found = False
        arg_str = ''

        s_len = len(Delimiters.start)
        e_len = len(Delimiters.end)

        for i, ch in enumerate(args):
            if state == 'empty':
                replaced = False

                if (arg_str + ch).strip()[:s_len] == Delimiters.start:
                    if len(self.args) and not comma_found:
                        raise EvaluateError(
                            "Could not parse Function, missing ',' between arguments: {}"\
                                .format(string))
                    state = 'signal|constant'
                elif ch in '-+':
                    if len(self.args) and not comma_found:
                        raise EvaluateError(
                            "Could not parse Function, missing ',' between arguments: {}"\
                                .format(string))
                    sign = ch
                elif ch in '0123456789|':
                    if len(self.args) and not comma_found:
                        raise EvaluateError(
                            "Could not parse Function, missing ',' between arguments: {}"\
                                .format(string))
                    state = 'constant'
                elif ch in ascii_uppercase:
                    if len(self.args) and not comma_found:
                        raise EvaluateError(
                            "Could not parse Function, missing ',' between arguments: {}"\
                                .format(string))
                    state = 'func'

                elif ch == ",":
                    comma_found = True

                if not ch in '-+ \t,':
                    arg_str += ch

            elif state == 'signal|constant':
                replaced = True
                if ch in ' +-0123456789|':
                    arg_str += ch
                    state = 'constant'
                else:
                    arg_str += ch
                    state = 'signal'

            elif state == 'constant':
                if replaced and (arg_str + ch).strip()[-e_len:] == Delimiters.end:
                    arg_str = arg_str + ch
                    arg_str = arg_str[s_len:-e_len].strip()
                    if sign == '-':
                        self.args.append(-Constant(arg_str))
                    else:
                        self.args.append(Constant(arg_str))
                    state = 'empty'
                    sign = ''
                    arg_str = ''
                    cntr = 0
                    if ch == ",":
                        comma_found = True
                    else:
                        comma_found = False

                elif not replaced and ch == ',':
                    arg_str = arg_str.strip()
                    if sign == '-':
                        self.args.append(-Constant(arg_str))
                    else:
                        self.args.append(Constant(arg_str))
                    state = 'empty'
                    sign = ''
                    cntr = 0
                    arg_str = ''
                    if ch == ",":
                        comma_found = True
                    else:
                        comma_found = False
                else:
                    arg_str += ch

            elif state == 'signal':
                if (arg_str + ch).strip()[-e_len:] == Delimiters.end:
                    arg_str = arg_str + ch
                    arg_str = arg_str[s_len:-e_len].strip()

                    if arg_str.startswith('__'):
                        if arg_str not in self.user_signals:
                            self.user_signals[arg_str] = Signal([], [], name=arg_str, sign=sign)
                        sig = self.user_signals[arg_str]
                    else:
                        if arg_str not in signals:
                            sig = None
                            self.missing_signals = True
                            sign = ''
                        else:
                            sig = signals[arg_str]
                    if sign == '-':
                        self.args.append(-sig)
                    else:
                        self.args.append(sig)
                    state = 'empty'
                    sign = ''
                    cntr = 0
                    comma_found = False
                    arg_str = ''
                else:
                    arg_str += ch

            elif state == 'func':
                arg_str += ch
                if ch == '(':
                    cntr -= 1
                elif ch == ')':
                    cntr += 1
                if ch == ')' and cntr == 0:
                    arg_str = arg_str.strip()
                    self.args.append(Function(arg_str, signals, sign, self.user_signals))
                    sign = ''
                    state = 'empty'
                    comma_found = False
                    arg_str = ''

        if state == 'constant':
            if replaced:
                raise EvaluateError(
                    "Could not parse Function, missing closing <\"> for constant: {}"\
                        .format(string))
            arg_str = arg_str.strip()
            if sign == '-':
                self.args.append(-Constant(arg_str))
            else:
                self.args.append(Constant(arg_str))
            state = 'empty'
        elif state == 'signal':
            raise EvaluateError(
                "Could not parse Function, missing closing <\"> for signal: {}"\
                    .format(string))
        elif not state == 'empty':
            raise EvaluateError('incorect: "{}"'.format(self.string) + str((Delimiters.start, Delimiters.end)))

        if not state == 'empty':
            raise EvaluateError('incorrect arguments for function: "{}"'.format(self.string))

    def __repr__(self):
        return 'Function {{ {}: sign="{}" args={} }}'.format(self.func_type, self.sign, self.args)

    def evaluate(self, start=None, stop=None):
        """evaluate

        Runs the function's evaluation with respect to the `start` and `stop` timestamps.

        Parameters
        ----------
        start : float
            start time; default *START_OF_MEASUREMENT*
        stop : float
            stop time; default *END_OF_MEASUREMENT*

        Returns
        -------
        result : *Signal* or *Constant*

        Examples
        --------
        >>> f = Function('SUM("sIn1", 10e-7, ABS("sIn2"), PROD(9, "sIn3"))')
        >>> result = f.evaluate(start=3.3, stop=3.8)


        """
        if self.missing_signals:
            return None

        args = [
            arg.evaluate(start, stop) if isinstance(arg, Function) else arg
            for arg in self.args
        ]

        result = None

        if self.func_type.startswith('NP_'):
            func = getattr(np, self.func_type[3:])
            np_args = []
            time = np.array([], dtype=np.float32)
            for arg in args:
                if isinstance(arg, Signal):
                    time = np.union1d(time, arg.time).astype(np.float32)

            args = [
                arg.interp(time).cut(start, stop) if isinstance(arg, Signal) else arg
                for arg in args
            ]

            for arg in args:
                if isinstance(arg, Signal):
                    np_args.append(arg.signal)
                    time = arg.time
                elif isinstance(arg, Constant):
                    np_args.append(arg.x)

            ret = func(*np_args)
            if isinstance(ret, np.ndarray):
                if len(ret) == len(time) - 1:
                    result = Signal(
                        ret,
                        time[1:],
                        name=self.func_type,
                    )
                elif len(ret) == len(time):
                    result = Signal(
                        ret,
                        time,
                        name=self.func_type,
                    )
                elif len(time) == 0:
                    result = Signal(
                        ret,
                        np.arange(len(ret)),
                        name=self.func_type,
                    )
            else:
                if ret is True or ret is False:
                    result = Constant(ret)
                else:
                    result = Constant(str(ret))

        elif self.func_type == 'SUM':
            for arg in args:
                if isinstance(arg, Signal) and np.issubdtype(arg.signal.dtype, np.integer):
                    arg = arg.astype(np.int64)
                result = result + arg

        elif self.func_type == 'PROD':
            for arg in args:
                if isinstance(arg, Signal) and np.issubdtype(arg.signal.dtype, np.integer):
                    arg = arg.astype(np.int64)
                result = result * arg

        elif self.func_type == 'POW':
            if not len(args) == 2:
                raise EvaluateError('POW allows exactly two arguments: "{}"'.format(self.string))
            else:
                result = args[0] ** args[1]

        elif self.func_type == 'DIV':
            if not len(args) == 2:
                raise EvaluateError('DIV allows exactly two arguments: "{}"'.format(self.string))
            else:
                result = args[0] / args[1]

        elif self.func_type == 'AVG':
            for arg in args:
                if isinstance(arg, Signal) and np.issubdtype(arg.signal.dtype, np.integer):
                    arg = arg.astype(np.int64)
                result = result + arg
            result = result / Constant(len(args))

        elif self.func_type == 'DIFF':
            result = args[0]
            if isinstance(result, Signal) and np.issubdtype(result.signal.dtype, np.integer):
                result = result.astype(np.int64)

            for arg in args[1:]:
                result = result - arg

        elif self.func_type == 'ABS':
            result = abs(args[0])

        elif self.func_type == 'CLIP':
            arg = args[0]
            a_min = args[1]
            a_max = args[2]
            result = Signal(np.clip(arg.signal, a_min, a_max),
                            arg.time,
                            arg.unit,
                            arg.name)

        elif self.func_type == 'SIGN':
            arg = args[0]
            if isinstance(arg, Constant):
                result = Constant(np.sign(arg.x))
            else:
                name = arg.name + '_Sign'
                result = Signal(np.sign(arg.signal), arg.time, name=name)

        elif self.func_type == 'EDIFF':
            if not len(args) == 1 or not isinstance(args[0], Signal):
                raise EvaluateError('EDIFF only allows one argument of type Signal: "{}"'.format(self.string))
            else:
                arg = args[0]
                result = Signal(np.diff(arg.signal), arg.time[1:], arg.unit, arg.name + '_DDiff')

        elif self.func_type == 'GRAD':
            if not len(args) in (1, 2) or not isinstance(args[0], Signal):
                raise EvaluateError(
                    'GRAD has a mandatory Signal argument'\
                    ' and an optional Constant second argument (the raster): "{}"'\
                        .format(self.string))
            else:
                arg = args[0].cut(start, stop)

                if len(args) == 2:
                    raster = args[1]
                    raster = to_seconds(raster.x, raster.unit)
                    new_time = np.arange(
                        arg.time[0],
                        arg.time[-1],
                        raster,
                    )
                    arg = arg.interp(new_time)

                result = Signal(
                    np.diff(arg.signal) / np.diff(arg.time),
                    arg.time[1:],
                    '{}/s'.format(arg.unit),
                    arg.name + '_Gradient'
                )

        elif self.func_type == 'HYST':
            """Return a signal that has had hysteresis applied. A value of 1
            in the returned result indicated the signal has crossed both bands
            and has returned to its default position (either above or below
            both top and bottom bands).

            Args:
                signal: A 1D numpy array to apply hysteresis to
                top_band: A 1D numpy array. When the signal evaluates above this band
                    the signal is considered 'above'
                bottom_band: A 1D numpy array. When the signal evaluates below this band
                  the signal is considered 'below
                normal_below: When `True` indicates that the signal is normally 'below'
                  the bottom band. Default = `False` indicating the signal is normally 'above'
                  the top band.
            """
            if not len(args) in (3, 4) or \
                not isinstance(args[0], Signal):

                raise EvaluateError(
                    'HYST has a mandatory Signal argument and \n' \
                    'a mandatory Signal or Constant second argument (TOP_BAND)\n' \
                    'a mandatory Signal or Constant third argument (BOTTIM_BAND)\n' \
                    'an optional Constant forth argument (normal_below, default=0(false)): "{}"'.format(self.string)
                )
            else:
                arg = args[0]

                result = np.zeros(len(arg.signal), int)
                if isinstance(args[1], Constant):
                    top_band = args[1].x
                elif isinstance(args[1], Signal):
                    top_band = args[1].signal
                else:
                    raise EvaluateError(
                        'TOP_BAND argument must be a Signal or a Constant! \n' \
                        'Type: "{}" \n' \
                        'TOP_BAND: {}'.format(type(args[1]), args[1])
                    )

                if isinstance(args[2], Constant):
                    bottom_band = args[2].x
                elif isinstance(args[2], Signal):
                    bottom_band = args[2].signal
                else:
                    raise EvaluateError(
                        'TOP_BAND argument must be a Signal or a Constant! \n' \
                        'Type: "{}" \n' \
                        'BOTTOM_BAND: {}'.format(type(args[1]), args[2])
                    )

                normal_below = 0
                if len(args) == 4:
                    if isinstance(args[3], Constant):
                        normal_below = args[3].x

                top, bottom = {0: (1, -1), 1: (-1, 1)}[normal_below]
                result[arg.signal > top_band] = top
                result[arg.signal < bottom_band] = bottom
                result = ups_downs(result)
                result[result == -1] = 0
                zero_out = {0: np.argmax(arg.signal < bottom_band),
                            1: np.argmax(arg.signal > top_band)}[normal_below]
                result[:zero_out] = 0
                if np.count_nonzero(result) >= 2:
                    print(
                        'Hysteresis threshold detected ' \
                        'at timestamp(s): {} ' \
                        'and normal_below: {}'
                        .format(
                            arg.time[result != 0],
                            normal_below
                        )
                    )
                    result = Signal(
                        name='{}_HYST'.format(arg.name),
                        signal=np.ones(len(arg.signal)),
                        time=arg.time,
                    )
                elif np.count_nonzero(result) == 1:
                    print(
                        'Hysteresis threshold detected ' \
                        'at timestamp: {}'.format(arg.time[result != 0])
                    )
                    result = Signal(
                        name='{}_HYST'.format(arg.name),
                        signal=np.zeros(len(arg.signal)),
                        time=arg.time,
                    )
                else:
                    result = Signal(
                        name='{}_HYST'.format(arg.name),
                        signal=np.zeros(len(arg.signal)),
                        time=arg.time,
                    )

        elif self.func_type in ('MIN', 'MAX'):
            func = np.min if self.func_type == 'MIN' else np.max
            if len(args) == 1:
                if isinstance(args[0], Constant):
                    result = args[0]
                else:
                    result = Constant(func(args[0].cut(start, stop).signal))
            else:
                raise EvaluateError('{} only allows one argument: "{}"'.format(self.func_type, self.string))

        elif self.func_type in ('MAXIM', 'MINIM'):
            func = np.minimum if self.func_type == 'MINIM' else np.maximum
            if len(args) == 1:
                return args[0]
            else:
                result = args[0]
                for arg in args[1:]:
                    if result.type == CONSTANT and arg.type == CONSTANT:
                        if self.func_type == 'MAXIM':
                            if arg > result:
                                result = arg
                        elif self.func_type == 'MINIM':
                            if arg < result:
                                result = arg
                    else:
                        if result.type == CONSTANT:
                            sig = func(arg.signal, result.x)
                            result = Signal(sig, arg.time, arg.unit)
                        elif arg.type == CONSTANT:
                            sig = func(arg.x, result.signal)
                            result = Signal(sig, result.time, result.unit)
                        else:
                            time = np.union1d(result.time, arg.time)
                            s = result.interp(time).signal
                            o = arg.interp(time).signal
                            result = Signal(func(s, o), time)

        elif self.func_type == 'CHECK_CYCLE_TIME':
            if len(args) == 1:
                sig = args[0]
                result = Signal(np.diff(sig.time) * 10**3, sig.time[1:], sig.unit, sig.name)

        elif self.func_type == 'TIMEOUT':
            if len(args) == 1:
                sig = args[0]
                result = Signal(np.diff(sig.time) * 10**3, sig.time[:-1], sig.unit, sig.name)

        elif self.func_type == 'INTERP':
            if len(args) == 2:
                if isinstance(args[0], Signal) and isinstance(args[1], Constant):
                    sig = args[0].cut(start, stop)
                    sig.signal = np.interp(sig.signal, args[1].x, args[1].y)
                    result = sig
                elif isinstance(args[0], Constant) and isinstance(args[1], Signal):
                    sig = args[1].cut(start, stop)
                    sig = np.interp(sig.signal, args[0].x, args[0].y)
                    result = sig
                else:
                    raise EvaluateError(
                        'INTERP allows Signal and Constant, or Constant and Signal arguments: "{}"'\
                            .format(self.string))
            else:
                raise EvaluateError('INTERP only allows two argument: "{}"'.format(self.string))

        elif self.func_type == 'MOD':
            if len(args) == 2:
                if isinstance(args[0], Signal) and isinstance(args[1], Constant):
                    result = args[0] % args[1].x
                elif isinstance(args[0], Constant) and isinstance(args[1], Signal):
                    left = Signal(
                        np.ones(len(args[1]), dtype=args[1].signal.dtype) * args[0].x,
                        args[1].time,
                    )
                    result = left % args[1]
                else:
                    result = args[0] % args[1]
            else:
                raise EvaluateError('MOD only allows two argument: "{}"'.format(self.string))

        elif self.func_type == 'PWM_FREQ':
            if len(args) == 3:
                sig = args[0]
                low = args[1].x
                high = args[2].x

                prev_sample = sig.signal[:-1]
                next_sample = sig.signal[1:]
                c1 = getattr(prev_sample, OPS['<='])
                c2 = getattr(next_sample, OPS['>='])
                idx = np.argwhere(c1(low) & c2(high)).flatten() + 1

                freq = 1 / np.diff(sig.time[idx])

                result = Signal(
                    signal=freq,
                    time=sig.time[idx][1:],
                    unit='Hz',
                    name='{}_Freq'.format(sig.name),
                )

            else:
                EvaluateError(
                    'PWM_FREQ only allows three arguments '\
                    '(Signal, Constant = low level treshold, Constant = hihg level treshold): "{}"'\
                        .format(self.string))

        elif self.func_type == 'PWM_PERIOD':
            if len(args) == 3:
                sig = args[0]
                low = args[1].x
                high = args[2].x

                prev_sample = sig.signal[:-1]
                next_sample = sig.signal[1:]
                c1 = getattr(prev_sample, OPS['<='])
                c2 = getattr(next_sample, OPS['>='])
                idx = np.argwhere(c1(low) & c2(high)).flatten() + 1

                # convert to [ms]
                period = np.diff(sig.time[idx]) * 1000

                result = Signal(
                    signal=period,
                    time=sig.time[idx][1:],
                    unit='s',
                    name='{}_Period'.format(sig.name),
                )

            else:
                EvaluateError(
                    'PWM_PERIOD only allows three arguments '\
                    '(Signal, Constant = low level treshold, Constant = hihg level treshold): "{}"'\
                        .format(self.string))

        elif self.func_type == 'PWM_DUTY':
            if len(args) == 3:
                sig = args[0]
                low = args[1].x
                high = args[2].x

                prev_sample = sig.signal[:-1]
                next_sample = sig.signal[1:]
                c1 = getattr(prev_sample, OPS['<='])
                c2 = getattr(next_sample, OPS['>='])
                idx1 = np.argwhere(c1(low) & c2(high)).flatten() + 1

                prev_sample = sig.signal[:-1]
                next_sample = sig.signal[1:]
                c1 = getattr(prev_sample, OPS['>='])
                c2 = getattr(next_sample, OPS['<='])
                idx2 = np.argwhere(c1(high) & c2(low)).flatten() + 1

                cond = idx2 > idx1[0]
                idx2 = np.extract(cond, idx2).flatten()

                duty = [sig.time[id2] - sig.time[id1] for id1, id2 in zip(idx1, idx2)]

                delta = np.diff(sig.time[idx1])

                duty = [duty_ * 100.0 / delta_ for duty_, delta_ in zip(duty, delta)]

                result = Signal(
                    signal=duty,
                    time=np.arange(len(duty)),
                    unit='Hz',
                    name='{}_Duty'.format(sig.name),
                )

            else:
                EvaluateError(
                    'PWM_FREQ only allows three arguments '\
                    '(Signal, Constant = low level treshold, Constant = hihg level treshold): "{}"'\
                        .format(self.string))

        elif self.func_type == 'TIME_SHIFT':
            if len(args) == 2:
                if isinstance(args[0], Signal) and isinstance(args[1], Constant):
                    sig = args[0]
                    time = sig.time + args[1].x
                    result = Signal(sig.signal, time, sig.unit, sig.name)
                elif isinstance(args[0], Constant) and isinstance(args[1], Signal):
                    sig = args[1]
                    time = sig.time + args[0].x
                    result = Signal(sig.signal, time, sig.unit, sig.name)
                else:
                    raise EvaluateError(
                        'TIME_SHIFT allows Signal and Constant, '\
                        'or Constant and Signal arguments: "{}"'\
                            .format(self.string))
            else:
                raise EvaluateError('TIME_SHIFT only allows two argument: "{}"'.format(self.string))

        elif self.func_type in ('BITRSHIFT', 'BITLSHIFT', 'BITAND', 'BITOR', 'BITXOR'):
            name_to_func = {'BITRSHIFT': np.right_shift,
                            'BITLSHIFT': np.left_shift,
                            'BITAND': np.bitwise_and,
                            'BITOR': np.bitwise_or,
                            'BITXOR': np.bitwise_xor}
            func = name_to_func[self.func_type]

            if len(args) == 2:
                if isinstance(args[0], Signal) and isinstance(args[1], Constant):
                    result = Signal(func(args[0].signal, args[1].x), args[0].time)
                elif isinstance(args[0], Constant) and isinstance(args[1], Constant):
                    result = Constant(func(args[0].x, args[1].x))
                elif isinstance(args[0], Signal) and isinstance(args[1], Signal):
                    if any(s.signal.dtype in ('float64', 'float32') for s in args):
                        raise EvaluateError("Can't perform bitwise operations on floats: {}".format(self.string))
                    else:

                        time = np.union1d(args[0].time, args[1].time)

                        idx = np.searchsorted(args[0].time, time, side='right') - 1
                        idx = np.clip(idx, 0, idx[-1])
                        s1 = args[0].signal[idx]

                        idx = np.searchsorted(args[1].time, time, side='right') - 1
                        idx = np.clip(idx, 0, idx[-1])
                        s2 = args[1].signal[idx]

                        result = Signal(func(s1, s2), time)
                else:
                    raise EvaluateError(
                        '{} allows Signal and Constant, '\
                        'or Constant and Constant arguments: "{}"'\
                            .format(self.func_type, self.string))
            else:
                raise EvaluateError('{} only allows two argument: "{}"'.format(self.func_type, self.string))

        elif self.func_type in ('LARGE', 'SMALL'):
            if all(isinstance(arg, Signal) for arg in args[:-1]) and isinstance(args[-1], Constant):
                nth = args[-1].x
                if not 1 <= nth <= len(args) - 1:
                    raise EvaluateError('nth element = {} outside valid range[1:{}]'.format(nth, len(args) - 1))
                else:
                    time = reduce(np.union1d, (arg.time for arg in args[:-1]))
                    arrays = [arg.interp(time).signal for arg in args[:-1]]
                    arrays = np.sort(np.stack(arrays, axis=-1))
                    if self.func_type == 'LARGE':
                        nth = -nth
                    else:
                        nth -= 1

                    result = Signal(arrays[:, nth], time)
            else:
                raise EvaluateError('LARGE requires the last argument to be \
                                    Constant and all the rest Signal')
        elif self.func_type == "SEQUENCE":
            if len(args) > 1:
                if isinstance(args[0], Signal):
                    s = args[0].cut(start, stop)
                    target = [c.x for c in args[1:]]
                    seq_lst = []
                    for sample in s.signal:
                        if seq_lst:
                            if sample == seq_lst[-1]:
                                continue
                            else:
                                seq_lst.append(sample)
                        else:
                            seq_lst.append(sample)
                    result = Constant(int(target == seq_lst))
                else:
                    raise EvaluateError('{} only allows Signal argument: "{}"'.
                                        format(self.func_type, self.string))
            else:
                raise EvaluateError('{} only allows one argument: "{}"'.
                                    format(self.func_type, self.string))

        elif self.func_type == "SEQUENCE_REPEAT":
            if len(args) > 1:
                if isinstance(args[0], Signal):
                    s = args[0].cut(start, stop)
                    target_seq = [c.x for c in args[1:]]
                    seq_lst = []
                    for sample in s.signal:
                        if seq_lst:
                            if sample == seq_lst[-1]:
                                continue
                            else:
                                seq_lst.append(sample)
                        else:
                            seq_lst.append(sample)

                    seq_lst = np.array(seq_lst)

                    target_seq = np.array(
                        target_seq * math.ceil(len_list_seq/len_target_seq)
                    )

                    if len(target_seq) > len(seq_lst):
                        result = Constant(1)
                    else:
                        target_seq = target_seq[:len(seq_lst)]

                        result = Constant(int(np.array_equal(seq_lst, target_seq)))

                else:
                    raise EvaluateError('{} only allows Signal argument: "{}"'.
                                        format(self.func_type, self.string))
            else:
                raise EvaluateError('{} only allows one argument: "{}"'.
                                    format(self.func_type, self.string))

        elif self.func_type == 'VALUELIST':
            if len(args) > 1:
                if isinstance(args[0], Signal):
                    s = args[0].cut(start, stop)
                    target = set(c.x for c in args[1:])
                    vals = set(s.signal)

                    if vals - target:
                        delta = vals - target
                        idx = []
                        for v in delta:
                            idx.append(np.argwhere(s.signal == v))
                        idx = reduce(np.union1d, idx)

                        v = np.ones(len(s))
                        v[idx] = 0

                        result = Signal(
                            name='{}_VALUELIST'.format(s.name),
                            signal=v,
                            time=s.time,
                        )

                    elif target - vals:
                        delta = target - vals

                        v = np.zeros(len(s))

                        result = Signal(
                            name='{}_VALUELIST'.format(s.name),
                            signal=v,
                            time=s.time,
                            comment='{} is a subset of the VALUELIST. The missing values are {}'\
                                .format(s.name, delta),
                        )


                    else:
                        result = Signal(
                            name='{}_VALUELIST'.format(s.name),
                            signal=np.ones(len(s)),
                            time=s.time,
                        )

                else:
                    raise EvaluateError('{} only allows Signal argument: "{}"'.
                                        format(self.func_type, self.string))
            else:
                raise EvaluateError('{} only allows one argument: "{}"'.
                                    format(self.func_type, self.string))

        elif self.func_type == 'STRCMP':
            result = args[0] == args[1].x

            result = Signal(
                result.astype(np.uint8),
                args[0].time,
                unit='',
                name='STRCMP_<{}>_<{}>'.format(
                    args[0].name,
                    args[1].x,
                ),
            )

        elif self.func_type == 'STRCMP_XDL':

            target = (
                args[1].x
                .upper()
                .replace('|', '')
                .replace('{ ECU:', '')
                .replace('} XPC:', '')
                .strip()
                .replace(' ', '')
            )

            target = xdl_replace(target)

            string = args[0]
            result = np.ones(len(string))

            if '(' not in target and ')' not in target:
                newt = (
                    target
                    .replace('X', r'\w')
                    .replace('?', '\\?')

                )
                pattern = re.compile(newt)

                for i, value in enumerate(string.signal):
                    if pattern.match(value) is None:
                        result[i] = 0
            else:
                pattern = r'(?P<comparison>\((?P<op>[><=!]*)(?P<value>(\w{2})+)\))+?'
                size = len(target)

                matches = [match for match in re.finditer(pattern, target)]

                for match in matches:
                    span = match.span()
                    size -= span[1] - span[0]
                    size += len(match.group('value'))

                offset = 0
                for match in matches:
                    start, end = match.span()
                    start, end = start + offset, end + offset
                    op = '==' if match.group('op') is None else match.group('op')
                    value = match.group('value')
                    int_val = int('0x' + value, 16)

                    patt = r'\w' * start
                    patt += r'(?P<value>\w{{{}}})'.format(len(value))
                    patt += r'\w' * (size - start - len(value))

                    patt = re.compile(patt)

                    for i, val in enumerate(string.signal):
                        curr_match = patt.match(val)
                        if curr_match is None:
                            result[i] = 0
                        else:
                            val = curr_match.group('value')
                            val = int('0x' + val, 16)

                            res = eval('{}{}{}'.format(val, op, int_val))

                            if res is False:
                                result[i] = 0

                    offset += end - start - len(value)

            result = Signal(
                result,
                string.time,
                unit='',
                name='STRCMP_XDL_<{}>_<{}>'.format(string.name, args[1].x),
            )

        elif self.func_type == 'STR2INT_XDL':

            target = (
                args[1].x
                .upper()
                .replace('|', '')
                .replace('{ ECU:', '')
                .replace('} XPC:', '')
                .strip()
                .replace(' ', '')
            )

            target = xdl_replace(target)

            string = args[0]

            pattern = r'\((?P<mask>(\w{2})+)\)'
            match = re.search(pattern, target)

            start, end = match.span()
            mask = match.group('mask')

            patt = target[:start]
            patt += r'(?P<value>\w{{{}}})'.format(len(mask))
            patt += target[end:]

            patt = patt.replace('X', r'\w')

            patt = re.compile(patt)

            values = []
            timestamps = []

            for i, val in enumerate(string.signal):
                curr_match = patt.match(val)
                if curr_match:
                    val = curr_match.group('value')
                    val = int('0x' + val, 16)

                    values.append(val)
                    timestamps.append(string.time[i])

            if len(mask) == 2:
                values = np.array(values, dtype=np.uint8)
            elif len(mask) == 4:
                values = np.array(values, dtype=np.uint16)
            elif len(mask) <= 8:
                values = np.array(values, dtype=np.uint32)
            else:
                values = np.array(values, dtype=np.uint64)

            result = Signal(
                values,
                timestamps,
                unit='',
                name='STR2INT_<{}>'.format(string.name),
            )

        elif self.func_type == 'TRIGGER_INTERVAL':
            # convert to [ms]
            result = Constant(stop - start) * 1000

        elif self.func_type == 'DEFINE':
            signal = args[0]
            other = args[1]
            signal.signal = other.signal[:1].copy()
            signal.time = other.time[:1].copy()
            result = Signal(
                other.signal.copy(),
                other.time.copy(),
                name='{}_copied'.format(other.name),
            )

        else:
            raise EvaluateError('{} function is not supported.'
                                .format(self.func_type))

        if isinstance(result, Signal):
            if start is not None and stop is not None:
                start = np.float32(start)
                stop = np.float32(stop)
                result = result.cut(start, stop)
        if self.sign == '-':
            result = -result

        return result


if __name__ == '__main__':
    pass
