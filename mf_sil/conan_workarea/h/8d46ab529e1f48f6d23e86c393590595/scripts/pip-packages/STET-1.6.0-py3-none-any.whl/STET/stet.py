# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 18:18:26 2016

@author: uidn3651
"""

import logging
import os
import numpy as np
import re
import xlrd, xlsxwriter
from functools import reduce

from bs4 import BeautifulSoup as bs
from collections import OrderedDict, defaultdict, namedtuple
from h5py import File
from pprint import pformat

from mfile import BSIG, MDF, ERG, Measurement
from evaluate.utils import remove_comments, sanitize_string, get_signal_dependencies
from evaluate.core import Signal, Testcase, Verdict, EvaluateError, Delimiters
from evaluate.version import __version__ as EVALUATE_VERSION
from report import HTMLReport
from report import __version__ as REPORT_VERSION

from .version import __version__ as STET_VERSION


logger = logging.getLogger('STET.stet')
logging.getLogger('evaluate.core').setLevel(logging.INFO)


def read_keywords(keywords_xls):
    """
    Parses the input excel file for keyword definitions.

    Parameters
    ----------
    keywords_xls : str
        input excel file name

    Returns
    -------
    keywords : dict
        dictionary containing the keywords found
        .. note::
            the keys are the keyword names and the values are the string definition

    Examples
    --------
    >>> xls_file = r'D:\IMS Exports\Session ID 8927421.xlsx'
    >>> read_keywords(xls_file)
    {'VehicleMoving': '"sInVehicleSpeed" >= 7', 'BrakeActive': '"sInBrakePedalLevel"' >= 0.5'}

    """
    keywords = OrderedDict()
    wb = xlrd.open_workbook(keywords_xls)
    sh = wb.sheet_by_name('Test Cases')
    for i in range(sh.nrows):
        row = sh.row(i)
        if row[0].value.strip() == 'ID':
            break
    else:
        raise EvaluateError('Invalid IMS export: could not parse keywords')
    ids = [cell.value.strip() for cell in row]
    type_idx = ids.index('Type')
    name_idx = ids.index('Title')
    content_idx = ids.index('Content')
    for i in range(sh.nrows):
        if sh.cell(i, type_idx).value.strip() == 'Keyword':
            keywords[sh.cell(i, name_idx).value.strip()] = remove_comments(sh.cell(i, content_idx).value)
    return keywords


def read_testcases(testcase_xls, keywords):
    """
    Reads all the testcases from the IMS excel export

    Parameters
    ----------
    testcase_xls : str
        IMS excel export file name (absolute path)

    Returns
    -------
    testcases : dict
        dict of all testcases from the IMS export. For each testcase id key the
        value is a (testcase string, requirements list) tuple

    """

    testcases = {}
    wb = xlrd.open_workbook(testcase_xls)
    sh = wb.sheet_by_name('Test Cases')
    for i in range(sh.nrows):
        row = sh.row(i)
        if row[0].value.strip() == 'ID':
            break
    else:
        raise EvaluateError('Invalid IMS export: could not parse keywords')
    ids = [cell.value for cell in row]
    id_idx = ids.index('ID')
    type_idx = ids.index('Type')
    test_input_idx = ids.index('Test Input Values')
    precondition_idx = ids.index('Test Pre-Conditions')
    expected_results_idx = ids.index('Expected Test Results')
    measurement_idx = ids.index('Attached Files')
    try:
        requirements_idx = ids.index('Requirements')
    except:
        requirements_idx = None
    for i in range(sh.nrows):
        if sh.cell(i, type_idx).value.strip() == 'Test Case':
            last_tc = OrderedDict()

            id_val = sh.cell(i, id_idx).value

            # check if the ID is an integer
            try:
                if id_val.is_integer():
                    id_val = str(int(id_val))
                else:
                    id_val = str(id_val)
            except:
                id_val = str(id_val)

            last_tc['ID'] = id_val
            last_tc['Type'] = sh.cell(i, type_idx).value
            last_tc['test_input'] = sh.cell(i, test_input_idx).value
            last_tc['precondition'] = sh.cell(i, precondition_idx).value
            last_tc['expected_result'] = sh.cell(i, expected_results_idx).value
            last_tc['measurement'] = sh.cell(i, measurement_idx).value

            if requirements_idx is not None:
                requirements = [
                    line.strip()
                    for line in sh.cell(i, requirements_idx).value.splitlines()
                    if line.strip()
                ]
            else:
                requirements = []

            tc_string = sanitize_string('\n\n'.join(last_tc.values()), keywords)
            testcases[last_tc['ID']] = tc_string, requirements
    return testcases


def load_data(measurement_file, signal_names):
    """
    Loads the signals from the measurement file. The allowed measurement file types are:

        * Continental BSIG (.bsig)
        * IPG erg type 2 (.erg)
        * ASAM MDF v3 and v4 (.mdf, .mf4)
        * Matlab mat (.mat)
        * Datalyser dl3 (.dl3)

    Parameters
    ----------
    measurement_file : str
        absolute path of measurement file
    signal_names : list
        lsit of signal name strings

    Returns
    -------
    signals : dict
        *Signal* objects loaded from the measurement file

        .. note::

            * the keys are the signal names

    """
    logger.debug(measurement_file)
    signals = {}

    if measurement_file.lower().endswith(('mdf', 'mf4')):
        wfile = MDF(measurement_file)
        for name in signal_names:
            try:
                s = wfile.get(name)
                signals[name] = Signal(signal=s.samples,
                                       time=s.timestamps,
                                       unit=s.unit,
                                       name=s.name)
            except:
                continue

    elif measurement_file.lower().endswith('erg'):
        wfile = ERG(measurement_file)
        for name in signal_names:
            try:
                s = wfile.get(name)
                signals[name] = Signal(signal=s.samples,
                                       time=s.timestamps,
                                       unit=s.unit,
                                       name=s.name)
            except:
                continue

    elif measurement_file.lower().endswith('bsig'):
        wfile = BSIG(measurement_file)
        t = wfile.get_signal_by_index(index=0)
        for name in signal_names:
            s = wfile.get(name)
            signals[name] = Signal(s, t, '', name)

    elif measurement_file.lower().endswith('mat'):
        with File(measurement_file, 'r') as mat_file:
            sig_struct_names = [sig for sig in mat_file if not sig.startswith('#')]
            #each signal is saved as a structure
            for sname in sig_struct_names:

                try:
                    item = mat_file.get(sname)
                    if all([field in item for field in ('Data', 'Time', 'Name')]):
                        name = bytes(list(np.array(item.get('Name')).flatten())).decode('latin-1')
                        data = np.array(item.get('Data')).flatten()
                        time = np.array(item.get('Time')).flatten()
                        unit = name.split('__')[-1]
                        unit = unit.replace('perc', '%').replace('p', '/')
                        if unit == 'nu':
                            unit = ''
                        signals[name] = Signal(data, time, unit, name)
                    else:
                        for field in item:
                            val = np.array(item.get(field)).flatten()
                            signals['{}.{}'.format(item, field)] = val
                except:
                    continue

    elif measurement_file.lower().endswith('dl3'):
        wfile = Measurement(measurement_file)
        for name in signal_names:
            try:
                s = wfile.get(name)
                if s is None:
                    raise Exception('DL3 retuned None for "{}"'.format(name))
                signals[name] = Signal(
                    signal=s.samples,
                    time=s.timestamps,
                    unit=s.unit,
                    name=s.name,
                )
            except:
                continue

    return signals


def run_evaluation(measurements, testcases, work_dir, generate_report=True, report_title='', display_log=True, default_graph=False, pictures=None, environment=None):
    """
    Evaluates the test cases using the supplied measurement files.
    The correct path have to set in the *stet_settings.ini* before starting the evaluation

    Parameters
    ----------
    measurements : dict
        the keys are the testcase ID and the values are the path/list of paths of the measurement files
    testcases : dict
        the keys are the testcase ID and the values are the full testcase strings
    work_dir : str
        absolute path of output directory. If ommited the settings.ini value will be used
    generate_report : bool
        option to generate report; default True
    environment : dict
        environement description as item and description pairs

    Returns
    -------
    results : dict
        each key is a testcase ID as string; each dict value is another dict who's keys are measurement file names and values are
        (Verdict, comment, log) tuples

    Examples
    --------
    >>> measurements = {234: ['D:\\m1.mdf', 'D:\\m2.mdf'], 129: 'D:\\m11.mdf'}
    >>> res = run_evaluation(measurements)
    >>> res
    {129: {'D:\\m11.mdf': False}, 234: {'D:\\m1.mdf': True, 'D:\\m2.mdf': False}}

    """

    environment = environment or {}
    environment['STET version'] = STET_VERSION
    environment['evaluate lib version'] = EVALUATE_VERSION
    environment['report lib version'] = REPORT_VERSION

    _message = '{} STET RunEvaluation Started {}'.format(10*'=', 10*'=')
    logger.info(_message)

    if not os.path.exists(work_dir):
        os.makedirs(work_dir)

    if generate_report:
        report = HTMLReport(
            title=report_title,
            display_log=display_log,
            default_graph=default_graph,
            environment=environment,
            output_dir=work_dir,
        )

    results = OrderedDict()
    comments = OrderedDict()

    for tc_id in sorted(list(measurements.keys())):
        meas_file = None

        if isinstance(measurements[tc_id], str):
            measurement_files = [measurements[tc_id].strip(), ]
        else:
            measurement_files = [name.strip() for name in measurements[tc_id]]

        if pictures:
            tc_pictures = pictures[tc_id]
            measurement_files = [
                (meas, pict)
                for meas, pict in zip(measurement_files, tc_pictures)
            ]
        else:
            measurement_files = [
                (meas, None)
                for meas in measurement_files
            ]
        measurement_files.sort()

        tc_string, requirements = testcases.get(tc_id, (None, None))
        if tc_string is None:
            logger.warning('TC ID <' + str(tc_id) +'> not found in Export')
            continue

        logger.info('TC ID <' + str(tc_id) +'> evaluation:')

        results[tc_id] = OrderedDict()
        comments[tc_id] = OrderedDict()

        # get the necessary signal list and load the measured data for them
        required_signals = get_signal_dependencies(tc_string, delimiters=Delimiters)

        for meas_file, picture in measurement_files:
            try:
                mess = 'Measurement file "{}"'.format(meas_file)
                logger.info(mess)
                signals = load_data(meas_file, required_signals)

                testcase = Testcase(tc_string, signals, tc_id, requirements=requirements)

                results[tc_id][meas_file] = testcase.evaluate(meas_file)
                log = results[tc_id][meas_file][2]

                if generate_report:
                    report.append(testcase, measurement=meas_file, picture=picture)

            except Exception as err:
                logger.exception("!!! Exception occured:", exc_info=True)
                try:
                    testcase.stringio.seek(0)
                    log = testcase.stringio.read()
                except:
                    log=''
                results[tc_id][meas_file] = (Verdict.unknown, log, log)
                if report:
                    report.append_error(tc_id, meas_file, err, log=log)

    if generate_report:
        report.save()

    _message = '{} STET RunEvaluation Done {}'.format(10*'=', 10*'=')
    logger.info(_message)

    return results


def offline_evaluation(measurements_folder, output_folder, testcases_export, extension='erg'):
    '''
    Evaluates the measurements located in the supplied folder.

    The file should respect the following naming rule: *{id string}*.extension

    A single report is generated with all the evaluation results.

    Parameters
    ----------
    measurements_folder : str
        absolute path where the files are stored
    output_folder : str
        absolute path of output directory. If ommited the settings.ini value will be used
    testcases_export : str
        absolute path of the IMS Excel export
    extension : str
        file type filter; default is ERG

    Returns
    -------
    results : dict
        each key is a testcase ID as string; each dict value is another dict who's keys are measurement file names and values are True or False

    '''

    measurements = defaultdict(list)
    for file_name in os.listdir(measurements_folder):
        if file_name.lower().endswith(extension.lower()):
            root, ext = os.path.splitext(file_name)
            pattern = r'[^{]*\{(?P<id>[^}]+)\}.*'
            match = re.search(pattern, root)
            if match:
                id = match.group('id')
                measurements[id].append(os.path.join(measurements_folder, file_name))

    keywords = read_keywords(testcases_export)
    testcases = read_testcases(testcases_export, keywords)

    result = run_evaluation(measurements=measurements,
                            testcases=testcases,
                            work_dir=output_folder,
                            display_log=True)
    logger.debug('Offline results:\n\t' + pformat(result))
    return result

def modify_report(report_path):
    '''
    Modify a report to give the propper verdicts for manually evaluated tests.

    Parameters
    ----------
    report_path : str
        absolute path of html report

    '''
    Result = namedtuple('Result', ['id', 'measurement', 'verdict', 'comment'])

    with open(report_path, 'r') as report:
        html = bs(report.read(), 'lxml')
        with open(os.path.splitext(report_path)[0]+'_original.html', 'w') as original:
            original.write(html.prettify())

    workbook = xlsxwriter.Workbook(os.path.join(os.path.dirname(report_path), 'report.xlsx'))
    worksheet = workbook.add_worksheet()

    table = html.find(id='table2')
    table_body = table.find('tbody')
    rows = table_body.find_all('tr')

    for i, row in enumerate(rows):
        res = row.find_all('td')
        for j, cell in enumerate(res):
            worksheet.write(i, j, cell.text.strip())
    workbook.close()
    input('Edit and close the report.xls file. Press any key when ready ...')

    wb = xlrd.open_workbook(os.path.join(os.path.dirname(report_path), 'report.xlsx'))
    ws = wb.sheet_by_index(0)
    new_results = []
    for i in range(ws.nrows):
        res = [ws.cell_value(i, j) for j in range(ws.ncols)]
        res[0] = str(int(res[0]))
        new_results.append(Result(*res))

    print(new_results)

    # TC stats table
    table = html.find(id='table0')
    table_body = table.find('tbody')
    rows = table_body.find_all('tr')
    for row in rows:
        stats = rows[0].find_all('td')

        tc_stats = {}
        for e in new_results:
            if e.verdict == 'failed':
                tc_stats[e.id] = 'failed'
            elif e.verdict == 'unknown':
                if not tc_stats.get(e.id, '') == 'failed':
                    tc_stats[e.id] = 'unknown'
            else:
                if not e.id in tc_stats:
                    tc_stats[e.id] = 'passed'

        failed_tc = len([e for e in tc_stats.values() if e == 'failed'])
        unknown_tc = len([e for e in tc_stats.values() if e == 'unknown'])
        passed_tc = len([e for e in tc_stats.values() if e == 'passed'])
        total_tc = len(tc_stats)

        stats[0].string = '{} = {:.1f}%'.format(failed_tc, 100*failed_tc/total_tc)
        stats[1].string = '{} = {:.1f}%'.format(passed_tc, 100*passed_tc/total_tc)
        stats[2].string = '{} = {:.1f}%'.format(unknown_tc, 100*unknown_tc/total_tc)
        stats[3].string = str(total_tc)

    # Measurements stats table
    table = html.find(id='table1')
    table_body = table.find('tbody')
    rows = table_body.find_all('tr')
    for row in rows:
        stats = rows[0].find_all('td')

        total_meas = len(new_results)
        failed_meas = len([e for e in new_results if e.verdict == 'failed'])
        unknown_meas = len([e for e in new_results if e.verdict == 'unknown'])
        passed_meas = len([e for e in new_results if e.verdict == 'passed'])

        stats[0].string = '{} = {:.1f}%'.format(failed_meas, 100*failed_meas/total_meas)
        stats[1].string = '{} = {:.1f}%'.format(passed_meas, 100*passed_meas/total_meas)
        stats[2].string = '{} = {:.1f}%'.format(unknown_meas, 100*unknown_meas/total_meas)
        stats[3].string = str(total_meas)

    # Measurements overview table
    table = html.find(id='table2')
    table_body = table.find('tbody')
    rows = table_body.find_all('tr')
    align = ['text-align: center', '', 'text-align: center', '']
    for row in rows:
        res = row.find_all('td')
        print(res)
        for new_res in new_results:
            if new_res.id == res[0].text.strip():
                if new_res.measurement == res[1].text.strip():
                    break

        if new_res.verdict == 'passed':
            background_color = '0, 100, 0'
        elif new_res.verdict == 'failed':
            background_color = '175, 0, 0'
        elif new_res.verdict == 'unknown':
            background_color = '51, 51, 51'

        for i, text in enumerate(new_res):
            res[i]['style'] = '{}; background-color: rgb({});'.format(align[i], background_color)
            res[i].string = ''
            pre = html.new_tag('pre')
            text = text.strip()
            pre.string = text.strip()
            res[i].append(pre)

    with open(report_path + 'w') as report:
        report.write(html.prettify())
