# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:59:32 2016

@author: uidn3651
"""
import numpy as np
import unittest

from STET.utils import Condition, Signal, EvaluateError, Function

s1 = Signal(np.array(range(0,100)),
            np.array(range(0, 100)),
            'signal1_unit',
            'Signal1')

s2 = Signal(np.array(range(-100,0)),
            np.array(range(10, 110)),
            'signal2_unit',
            'Signal2')

s3 = Signal(np.array([0.1 * e for e in range(0,100)]),
            np.array(range(20, 120)),
            'signal3_unit',
            'Signal3')

SIGNALS = {'s1': s1, 's2': s2, 's3': s3}


class ConditionTest(unittest.TestCase):

    def test_empty(self):
        c = Condition('', SIGNALS)
        assert c.string == ''
        assert c.relation == ''
        assert c.start == c.stop == None
        assert c.operand1 == None
        assert c.operand2 == None
        assert c.delay_type == ''
        assert c.delay_value == ''
        assert c.delay_unit == ''
        self.assertEqual(c.tolerance, 0.0)
        with self.assertRaises(EvaluateError):
            c.evaluate()

    def test_valid1(self):
        string = '\tOR -"s1" == SUM("s1", 7.5) within 400  ms tolerance 1e3    '
        c = Condition(string, SIGNALS)
        assert c.string == string.strip()
        assert c.relation == 'OR'
        assert c.start == c.stop == None
        self.assertEqual(c.op, '==')
        self.assertEqual(c.operand1, -s1)
        assert isinstance(c.operand2, Function)
        assert c.operand2.sign == ''
        assert c.delay_type == 'within'
        self.assertEqual(c.delay_value, '400')
        assert c.delay_unit == 'ms'
        assert c.tolerance == 1000