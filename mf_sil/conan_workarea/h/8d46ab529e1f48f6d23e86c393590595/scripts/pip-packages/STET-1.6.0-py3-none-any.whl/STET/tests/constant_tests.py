# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:59:32 2016

@author: uidn3651
"""

import unittest
from hypothesis import given
import hypothesis.strategies as st
import numpy as np
from hypothesis.extra.numpy import floating_dtypes as ft

from STET import Constant


class ConditionTest(unittest.TestCase):

    @given(st.integers())
    def test_scalar_int(self, value):

        # int
        c = Constant('{} m^2'.format(value))
        self.assertEqual(c.x, value)
        self.assertEqual(c.unit, 'm^2')

        # hex int
        c = Constant('{} m^2'.format(hex(value)))
        self.assertEqual(c.x, value)
        self.assertEqual(c.unit, 'm^2')

    @given(ft.float64())
    def test_scalar_float(self, value):

        # dot notation
        c = Constant('{}'.format(value))
        self.assertEqual(c.x, value)
        self.assertEqual(c.unit, '')

        # exp notation
        c = Constant('{:e}'.format(value))
        self.assertEqual(c.x, value)
        self.assertEqual(c.unit, '')

    def test_scalar_operations(self):
        c1 = Constant(-1)
        c2 = Constant(8.4)
        c3 = Constant('4.2kph')
        c4 = Constant('0.2e1\tmm')

        result = 1 / ((c1 + c2 / c3) * c4)

        self.assertEqual(result.x, 0.5)

unittest.main()
