# -*- coding: utf-8 -*-
"""
Created on Mon May 29 16:50:22 2017

@author: uidn3651
"""

import argparse
import sys
import json
import logging
import os
from time import gmtime, strftime

from evaluate import Verdict
from STET import run_evaluation, read_testcases, read_keywords


logger = logging.getLogger('STET')

log_formatter = logging.Formatter('{levelname:>9}: {message:<256} [{filename}: {funcName} @ {lineno}]', style='{')

log_file = 'log {}.txt'.format(strftime("%Y-%m-%d %H-%M-%S", gmtime()))
log_file = os.path.join(os.path.dirname(__file__), log_file)

file_output = logging.FileHandler(log_file)
file_output.setFormatter(log_formatter)
file_output.setLevel(logging.INFO)
logger.addHandler(file_output)


def _cmd_line_parser():
    '''
    return a command line parser. It is used when generating the documentation
    '''

    parser = argparse.ArgumentParser()
    parser.add_argument('--id', help='testcase ID')
    parser.add_argument('--measurements', nargs='*', help='list of measurement files')
    parser.add_argument('--output_folder', help='output folder for report')
    parser.add_argument('--testcase_export', help='xls export path')
    parser.add_argument('--no_report', action='store_false', help='if provided no report will be generated')
    parser.add_argument('--report_title', help='report title')
    parser.add_argument('--no_log_in_report', action='store_true', help='do not display additional column with the evaluation log')
    parser.add_argument('--default_graph', action='store_true', help='create graphs with used signals when no graph is defined')
    parser.add_argument('--environment', type=json.loads)
    return parser


if __name__ == '__main__':

    parser = _cmd_line_parser()
    args = parser.parse_args(sys.argv[1:])

    measurements = {args.id: args.measurements}
    work_dir = args.output_folder if args.output_folder else None
    export = args.testcase_export
    generate_report = args.no_report
    report_title = args.report_title if args.report_title else 'TITLE'
    display_log = not args.no_log_in_report
    default_graph = args.default_graph
    environment = args.environment

    keywords = read_keywords(export)
    testcases = read_testcases(export, keywords)

    results = run_evaluation(
        measurements=measurements,
        work_dir=work_dir,
        testcases=testcases,
        generate_report=generate_report,
        report_title=report_title,
        display_log=display_log,
        default_graph=default_graph,
        environment=environment,
    )

    tc_results = [_[0] for _ in results[args.id].values()]
    if Verdict.failed in tc_results:
        sys.exit(15)
    elif Verdict.unknown in tc_results:
        sys.exit(170)
    else:
        sys.exit(240)
