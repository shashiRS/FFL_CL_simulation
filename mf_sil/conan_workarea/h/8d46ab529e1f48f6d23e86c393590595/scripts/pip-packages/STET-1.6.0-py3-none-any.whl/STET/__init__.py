''' automated test evaluation tool for S&T'''

from time import gmtime, strftime
import logging
import os
import sys

PYVERSION = sys.version_info[0]

from .stet import run_evaluation, offline_evaluation, read_testcases, read_keywords
from evaluate import __version__ as evaluate_version
from .version import __version__


app_data_path = os.path.join(os.getenv('APPDATA'), 'STET')
if not os.path.exists(app_data_path):
    os.mkdir(app_data_path)

logger = logging.getLogger('STET')

if PYVERSION > 2:
    log_formatter = logging.Formatter('{levelname:>9}: {message:<256} [{filename}: {funcName} @ {lineno}]', style='{')
else:
    log_formatter = logging.Formatter('%(levelname)-9s: %(message)-256s [%(filename)s: %(funcName)s @ %(lineno)s]')

log_file = 'log {}.txt'.format(strftime("%Y-%m-%d %H-%M-%S", gmtime()))
log_file = os.path.join(app_data_path, log_file)

file_output = logging.FileHandler(log_file)
file_output.setFormatter(log_formatter)
file_output.setLevel(logging.INFO)
logger.addHandler(file_output)

console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
console.setFormatter(log_formatter)
logger.addHandler(console)

logger.setLevel(logging.DEBUG)

logger.info('STET version ' + __version__)
logger.info('evaluate version ' + evaluate_version)
logger.info('Log file -> ' + log_file)
