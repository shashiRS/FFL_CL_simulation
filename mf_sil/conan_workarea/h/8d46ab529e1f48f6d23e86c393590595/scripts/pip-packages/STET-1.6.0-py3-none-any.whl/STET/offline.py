﻿import STET

import sys
from time import perf_counter

start = perf_counter()
print(*sys.path, sep='\n')

measurements_folder = r'e:\TMP\EVAL\ERV_1047_TestCase_0091'
output_folder = measurements_folder  + '\\RESULT'
export = r'c:\Users\uidn3651\Documents\SametimeFileTransfers\LDP_Algo_Test_Spec_new_Replaced.xls'

STET.offline_evaluation(measurements_folder, output_folder, export, 'mdf')

print('Total time: {:.3f}'.format(perf_counter() - start))
