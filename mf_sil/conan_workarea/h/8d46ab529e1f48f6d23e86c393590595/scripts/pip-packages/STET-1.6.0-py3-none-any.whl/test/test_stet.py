import unittest

from STET.stet import Report

class TestReport(unittest.TestCase):
    def test_class_exists(self):
        self.assertTrue(Report)

if __name__ == "__main__":
    unittest.main()
