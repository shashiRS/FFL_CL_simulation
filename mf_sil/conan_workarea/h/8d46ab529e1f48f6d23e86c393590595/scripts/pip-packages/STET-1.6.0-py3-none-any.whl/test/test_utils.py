#!/usr/bin/env python
import os
import sys
import unittest

"""
Utility functions needed by all test scripts.
"""
def getTestData(filename=""):
    return os.path.dirname(__file__) + "/data/" + filename


if __name__ == '__main__':
    unittest.main()