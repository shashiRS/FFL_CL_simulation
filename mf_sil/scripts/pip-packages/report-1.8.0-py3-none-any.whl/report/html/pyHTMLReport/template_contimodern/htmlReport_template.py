﻿#====================================================================
# System Imports
#====================================================================
import os
import sys

#====================================================================
# Simulation Imports
#====================================================================
sys.path.append( os.path.join(os.path.dirname(__file__), '..') )
from htmlReport_template_base import cHTMLReportTemplateBase

from numpy import column_stack

FILE_NAME_HEADER = "header.txt"
FILE_NAME_FOOTER = "footer.txt"
FOLDER_SCRIPTS   = os.path.join(os.path.dirname(__file__), 'scripts')
FOLDER_GFX       = os.path.join(os.path.dirname(__file__), 'gfx')
FOLDER_VIDEOS    = os.path.join(os.path.dirname(__file__), 'video')

MARGIN_FACTOR_LEFT     = 100
TOC_MARGIN_FACTOR_LEFT = 30

#CONTI_COLORS = [(191,115,0), (226,135,0), (255,194,102), (255,165,0)]
COLORS                  = [(0,255,0), (255,0,0), (0,0,255), (255,255,0)]
HIGHLIGHT_COLOR_RBGA    = "rgba(255,255,255, 0.05)"

def GetFilesInFolder(folder):
    """"Summary line.

    Extended description of function.

    Parameters
    ----------
    folder : Type of folder
        Description of folder default None

    Returns
    -------

    Examples
    --------
    >>>>

    """
    result = []
    for root, subFolders, files in os.walk(folder):
        for file in files:
            result.append(os.path.join(root,file))
    return result

class cHTMLReportTemplate(cHTMLReportTemplateBase):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self._currSectionLevel = 0
        self._currSectionCount = 0
        self._graphCount       = 0
        self._maxSectionCount  = 1000

    def GetAdditionalFilePaths(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        filePaths = []
        gfxFiles    = GetFilesInFolder(FOLDER_GFX)
        for currGfxFilePath in gfxFiles:
            filePaths.append({"folder": "gfx", "path": currGfxFilePath})
        scriptFiles = GetFilesInFolder(FOLDER_SCRIPTS)
        for currScriptFilePath in scriptFiles:
            filePaths.append({"folder": "scripts", "path": currScriptFilePath})
        videoFiles = GetFilesInFolder(FOLDER_VIDEOS)
        for currVideoFilePath in videoFiles:
            filePaths.append({"folder": "video", "path": currVideoFilePath})
        return filePaths

    def GetFoldersInDirectory(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        dirPaths = []
        gfxFiles    = dirPaths.append(str(FOLDER_GFX))
        scriptFiles = dirPaths.append(str(FOLDER_SCRIPTS))
        videoFiles  = dirPaths.append(str(FOLDER_VIDEOS))
        return dirPaths

    def CreateHeader(self, title, lazy_reload=True):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        title : Type of title
            Description of title default None
        lazy_reload : Type of lazy_reload
            Description of lazy_reload default True

        Returns
        -------

        Examples
        --------
        >>>>

        """
        headerFile = open(os.path.join(os.path.dirname(__file__), FILE_NAME_HEADER), "r")
        headerFileContent = headerFile.read()
        if(lazy_reload == False):
            headerFileContent = headerFileContent.replace("var lazy_reload = 1;", "var lazy_reload = 0;")
        return headerFileContent.replace("{title}",title)

    def CreateSectionBegin(self, sectionLabel,anchor=[]):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        sectionLabel : Type of sectionLabel
            Description of sectionLabel default None
        anchor : Type of anchor
            Description of anchor default []

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self._currSectionLevel += 1
        self._currSectionCount += 1

        #   If the user wishes to set an anchor to the Section, an empty section
        #   with the specified anchor is added
        anchorstring = ''
        if anchor is not []:
            anchorstring ='<div id={0}></div>'.format(anchor)

        sectionBeginString = ''
        sectionBeginString += '<dt>'
        sectionBeginString += '<div id="secExpander{sectionID}">{anchorstring}<script>jQuery(function() \
                              {$("#secExpander{sectionID}").click(function() \
                              {$("#divSection{sectionID}").toggle(); \
                              if($("#divSection{sectionID}").is(":visible")){$("#imgExpander{sectionID}").attr("src","gfx/toggle_minus.png"); \
                              }else{$("#imgExpander{sectionID}").attr("src","gfx/toggle_plus.png");}});});</script> \
                              <h2 style="margin-left: {marginLeft}px;"><a name="Section{sectionID}"><img id="imgExpander{sectionID}" style="width: 16px; height: 16px; float: left;" alt="" src="gfx/toggle_minus.png"> &nbsp;{label}</a></h2> \
                              <div id="divSection{sectionID}">'.replace("{sectionID}",str(self._currSectionCount))\
                                                               .replace("{label}",sectionLabel)\
                                                               .replace("{marginLeft}",str(MARGIN_FACTOR_LEFT*(self._currSectionLevel-1)))\
                                                               .replace("{anchorstring}",anchorstring)
        sectionBeginString += '</dt></div>'
        sectionBeginString +='<dd><dl>\n'

        return sectionBeginString

    def CreateSectionEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self._currSectionLevel -= 1
        return '</dl></dd>\n'
        #return '</div>'

    def CreateTOC(self, contentList):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        contentList : Type of contentList
            Description of contentList default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        TOCcontent = ''
        countSection     = 1
        countSectLev     = 0
        for currItem in contentList:
            if currItem['type'] == 'SectionBegin':
                countSection     += 1
                countSectLev     += 1
                TOCcontent += '<div style="margin-left: {marginLeft}px;"><a onclick="open_section(\'#divSection{SectionNr}\')" href="#Section{SectionNr}">{textContent}</a></div><br>' \
                .format(marginLeft=TOC_MARGIN_FACTOR_LEFT*countSectLev, SectionNr=countSection, textContent=currItem['Label'])
            if currItem['type'] == 'SectionEnd':
                countSectLev     -= 1
        return TOCcontent

    def CreateInitButtons(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        """
        Adds jQuery to the html report.
        """
        #%copy & paste from html_report.py
        SCRIPT="""
        $(document).ready(function(){
            STATE_HIDDEN_ALL = 0;
            STATE_SHOW_ALL = 1;
            STATE_MIXED = 2;
            state = STATE_MIXED;
            initButtons();
            hide_all_sections();
            ///buildToc()
        });

        function initButtons(){
            $("dt").click(function(){ // trigger
                $(this).next("dd").slideToggle("slow");
                $(this).find("input").toggleClass("opened closed");
                state = STATE_MIXED;
                /* Invoke scroll event to trigger inview-event of dygraphs */
                window.scrollBy(0,1);
                window.scrollBy(0,-1);
                return false;
            });

            $("#show_all").click(function(){
                show_all_sections();
            });

            $("#hide_all").click(function(){
                hide_all_sections();
            });
        }
        """.replace('{maxSectionCount}', str(self._maxSectionCount))

        return '<script>\n' + SCRIPT + '\n</script>\n' + '<input type="submit" class="Buttons" value="Show all" id="show_all" />' + '\n' + '<input type="submit" class="Buttons" value="Hide all" id="hide_all" />' + '\n'



    def CreateFooter(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        footerFile = open(os.path.join(os.path.dirname(__file__), FILE_NAME_FOOTER), "r")
        return footerFile.read()

    def CreateTextSection(self, text):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        text = text.replace("\n", "<br>")
        textSection = '<div style="margin-left: {marginLeft}px; color: #FFFFFF; font-size:12px">{textContent}</div><br>'.format(marginLeft=MARGIN_FACTOR_LEFT*self._currSectionLevel, textContent=text)
        return textSection


    def CreateTableBegin(self, caption="", tableCount=0, sortable=True, width=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        caption : Type of caption
            Description of caption default ""
        tableCount : Type of tableCount
            Description of tableCount default 0
        sortable : Type of sortable
            Description of sortable default True
        width : Type of width
            Description of width default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        tableBegin = '<script> $(document).ready(function() {$("#table{tableCount}").DataTable({"lengthMenu": [[-1, 10, 25, 50], ["All", 10, 25, 50]], paging: false, "aaSorting": [], '.replace('{tableCount}', str(tableCount))
        if not sortable:
            tableBegin += '"bSort": false, '
        tableBegin += 'bFilter: false, bInfo: false});});</script>'
        tableBegin += '<br><table id="table{tableCount}" class="niceTable" width="{width}" border="0" cellpadding="0" cellspacing="0"><caption align="bottom" style="color: #FFFFFF">{tableCaption}</caption>'.format(marginLeft=MARGIN_FACTOR_LEFT*self._currSectionLevel, tableCaption=caption, tableCount=tableCount, width=width)
        return tableBegin

    def CreateTableEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '</tbody></table><br>'

    def CreateTableHeaderBegin(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '<thead>'

    def CreateTableHeaderCell(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return self.CreateTableHeaderRowCell(text, textColor, textAlign, textStyle, backgroundColor)

    def CreateTableHeaderEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '</thead><tbody>'

    def CreateTableRowBegin(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '<tr>'

    def CreateTableHeaderRowCell(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None, tooltip=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None
        tooltip : Type of tooltip
            Description of tooltip default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        styleString = ""
        if textColor is not None or textAlign is not None or textStyle is not None or backgroundColor is not None:
            styleString = 'style="'
            if textColor       is not None: styleString += "color: rgb({red}, {green}, {blue});".format(red=textColor[0], green=textColor[1], blue=textColor[2])
            if textAlign       is not None: styleString += "text-align: {0};".format(textAlign)
            if textStyle       is not None: styleString += "font-weight: {0};".format(textStyle)
            if backgroundColor is not None: styleString += "background-color: rgb({red}, {green}, {blue});".format(red=backgroundColor[0], green=backgroundColor[1], blue=backgroundColor[2])
            styleString += '"'

        if tooltip is not None:
            titleString = 'title= "%s"' % tooltip
            cellString = '<th {title} {style}>{content}</th>'.format(title=titleString, style=styleString, content=text)
        else:
            cellString = '<th {style}>{content}</th>'.format(style=styleString, content=text)

        return cellString

    def CreateTableRowCell(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None, tooltip=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None
        tooltip : Type of tooltip
            Description of tooltip default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        styleString = ""
        if textColor is not None or textAlign is not None or textStyle is not None or backgroundColor is not None:
            styleString = 'style="'
            if textColor       is not None: styleString += "color: rgb({red}, {green}, {blue});".format(red=textColor[0], green=textColor[1], blue=textColor[2])
            if textAlign       is not None: styleString += "text-align: {0};".format(textAlign)
            if textStyle       is not None: styleString += "font-weight: {0};".format(textStyle)
            if backgroundColor is not None: styleString += "background-color: rgb({red}, {green}, {blue});".format(red=backgroundColor[0], green=backgroundColor[1], blue=backgroundColor[2])
            styleString += '"'

        if tooltip is not None:
            titleString = 'title= "%s"' % tooltip
            cellString = '<td {title} {style}>{content}</td>'.format(title=titleString, style=styleString, content=text)
        else:
            cellString = '<td {style}>{content}</td>'.format(style=styleString, content=text)

        return cellString

    def CreateTableHeaderColSpanCell(self, colSpanWidth=None, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None, tooltip=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        colSpanWidth : Type of colSpanWidth
            Description of colSpanWidth default None
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None
        tooltip : Type of tooltip
            Description of tooltip default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if colSpanWidth is not None:
            colSpanString = ""
            colSpanString += '<td colspan="{headerColSpan}">{content}</td>'.format(headerColSpan=str(colSpanWidth), content=text)

        return colSpanString

    def CreateTableRowEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '</tr>'

    def CreateGraph(self, graphData, save_path):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        graphData : Type of graphData
            Description of graphData default None
        filePath : Type of filePath
            Description of filePath default None

        Returns
        -------

        Examples
        --------
        >>>>

        """

        vertLinesList = graphData.vertLines
        graphID = os.path.basename(graphData.filename)
        htmlFileString = ''
        legendID = "legend{0:04d}".format(self._graphCount)
        if graphData.title is not None:
            if vertLinesList is not None:
                for i, obj in enumerate(vertLinesList):
                    htmlFileString += "<div style='width: 75px;left: {0}px; position:absolute; padding: 6px 6px; border: 2px solid #a1a1a1; border-radius: 8px;'>".format(i*100+600)
                    htmlFileString += '<span align="center" style="color: {color}">&nbsp;<b>{name}</b>: {time}s&nbsp;</span>'.format(color=vertLinesList[i].color, time=str(vertLinesList[i].xCoord), name=vertLinesList[i].sigName)
                    htmlFileString += '</div>'
                htmlFileString += '<br>'
            htmlFileString += '<div style=" color: #FFFFFF; font-size: 24px"><u>{graphTitle}&nbsp;&nbsp;</u>{help}</div><br>'\
                                .replace("{graphTitle}", graphData.title)\
                                .replace("{help}",'<span class="circ" title="{0}">&nbsp;?&nbsp;</span>'.format(graphData.helpstring.replace('\n','&#13;')) if graphData.helpstring is not None else "")
        #if vertLinesList is not None:
        #    htmlFileString += "<div class='box' style='width: 150px; position:fixed'>"
        #    for i, obj in enumerate(vertLinesList):
        #        htmlFileString += '<p align="center" style="color: {color}">{name}: {time}s</p>'.format(color=vertLinesList[i].color, time=str(vertLinesList[i].xCoord), name=vertLinesList[i].sigName)
        #    htmlFileString += '</div>'

        htmlFileString += '<table><tbody><tr><td valign="top">'

        htmlFileString += '<div id="{graphID}"></div>'.replace('{graphID}', graphID)

        htmlFileString += '</td><td valign="top">&nbsp;&nbsp;</td><td valign="top"><div id="{0}_right"></div></td></tr></tbody></table><table  width = 100% style="table-layout:fixed;"><td style:"width: 33%"></td><td style:"width: 33%"><div id="{0}_below" style="left:600px;"></div></td><td style:"width: 33%"></td></table>'.format(legendID)

        htmlFileString += """ <script>
                            var got_{graphID}=false;
                            $(document).ready(function() {
                            if(lazy_reload==1){
                            $("#{graphID}").bind("inview", function(event, isVisible)
                            { if(!isVisible) return;
                              if(got_{graphID}) return;
                            $.getScript('graphData/graphData_{graphID}.js', function() {
                            addGraphToHTML();
                            got_{graphID}=true;
                            });});}
                            else {$.getScript('graphData/graphData_{graphID}.js', function() {
                            addGraphToHTML();
                            });}});
                            </script>""".replace('{graphID}', graphID)

        with open(os.path.join(save_path,
                               'graphData/graphData_{graphID}.js'.replace(
                                       "{graphID}", graphID)), 'r+') as file:
            file.seek(0)
            file.write(
                'var current_section_level = {: >10}; var nogroup = {: >20}'.format(
                    self._currSectionLevel,
                    '"noSyncGroup{}"'.format(self._currSectionCount),
                )
            )

        self._graphCount += 1
        return htmlFileString

    def CreateImage(self, imgData):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        imgData : Type of imgData
            Description of imgData default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '\n<IMG SRC="%s" ALT="%s" WIDTH=%d HEIGHT=%d/><br/>' % (imgData['path'], imgData['title'], imgData['width'], imgData['height'])

    def CreateVideo(self, videoData):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        videoData : Type of videoData
            Description of videoData default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        #htmlFileString = """<video controls>
        #                    <source src=""" +videoData["fileName"] +""" type=video/mp4>
        #                    </video>"""
        htmlFileString = """<video id=\""""+ videoData["title"]+ """\" class="video-js vjs-default-skin" controls preload="none" width="640" height="300"
                            poster=\""""+ videoData["imgFileName"]+"""\" data-setup="{}">
                            <source src=\""""+ videoData["fileName"] +"""\" type='video/mp4' />
                            <p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to a web browser that <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a></p>
                            </video>

                            <script type='text/javascript'>
                                var video = videojs(\""""+ videoData["title"]+ """\", {
                                controls: true,
                                autoplay: false,
                                preload: 'none',
                                plugins: {
                                framebyframe: {
                                fps: 30,
                                steps: [
                                        { text: '<- -', step: -5 },
                                        { text: '<-', step: -1 },
                                        { text: '->', step: 1 },
                                        { text: '- ->', step: 5 },
                                      ]
                                    }
                                  }
                                });
                            </script>"""
        return htmlFileString



    def CreateLink(self, linkData):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        linkData : Type of linkData
            Description of linkData default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return '%s<a href="%s" %s>%s</a>' % (linkData['prefix'].replace(" ","&nbsp"),
                                             linkData['path'],
                                             'title="'+linkData['title']+'"' if linkData['title'] is not None else '',
                                             linkData['text'])

    def AddHTMLCode(self, codeData):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        codeData : Type of codeData
            Description of codeData default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return codeData['code']
