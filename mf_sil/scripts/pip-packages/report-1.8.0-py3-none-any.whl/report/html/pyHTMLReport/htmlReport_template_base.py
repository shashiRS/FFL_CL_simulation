class cHTMLReportTemplateBase(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def GetAdditionalFilePaths(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateHeader(self, title):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        title : Type of title
            Description of title default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateFooter(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateSectionBegin(self, sectionLabel):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        sectionLabel : Type of sectionLabel
            Description of sectionLabel default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateSectionEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTextSection(self, text):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableBegin(self, caption=""):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        caption : Type of caption
            Description of caption default ""

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableHeaderBegin(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableHeaderCell(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableHeaderEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableRowBegin(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableRowCell(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateTableRowEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    def CreateGraph(self, graphData):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        graphData : Type of graphData
            Description of graphData default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        pass
    