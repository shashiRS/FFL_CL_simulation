﻿#====================================================================
# System Imports
#====================================================================
import os
import sys
import imp
import json
import copy
import shutil
import string
import logging
import random
import tempfile
from win32api import GetSystemMetrics

import numpy as np

MARGIN_FACTOR_LEFT     = 100
TOC_MARGIN_FACTOR_LEFT = 30

#CONTI_COLORS = [(191,115,0), (226,135,0), (255,194,102), (255,165,0)]
COLORS                  = [(0,255,0), (255,0,0), (0,0,255), (255,255,0)]
HIGHLIGHT_COLOR_RBGA    = "rgba(255,255,255, 0.05)"

#====================================================================
# Own Imports
#====================================================================


def copytree(src, dst, symlinks=False, ignore=None):
    """"Summary line.

    Extended description of function.

    Parameters
    ----------
    src : Type of src
        Description of src default None
    dst : Type of dst
        Description of dst default None
    symlinks : Type of symlinks
        Description of symlinks default False
    ignore : Type of ignore
        Description of ignore default None

    Returns
    -------

    Examples
    --------
    >>>>

    """
    names = os.listdir(src)
    if ignore is not None:
        ignored_names = ignore(src, names)
    else:
        ignored_names = set()

    if not os.path.isdir(dst): # This one line does the trick
        os.makedirs(dst)
    errors = []
    for name in names:
        if name in ignored_names:
            continue
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:
            if symlinks and os.path.islink(srcname):
                linkto = os.readlink(srcname)
                os.symlink(linkto, dstname)
            elif os.path.isdir(srcname):
                copytree(srcname, dstname, symlinks, ignore)
            else:
                # Will raise a SpecialFileError for unsupported file types
                shutil.copy2(srcname, dstname)
        # catch the Error from the recursive copytree so that we can
        # continue with other files
        except EnvironmentError as why:
            errors.append((srcname, dstname, str(why)))
    try:
        shutil.copystat(src, dst)
    except OSError as why:
        if WindowsError is not None and isinstance(why, WindowsError):
            # Copying file access times may fail on Windows
            pass
        else:
            errors.extend((src, dst, str(why)))

def ReducePlotData(xData, yData):
    """"Summary line.

    Extended description of function.

    Parameters
    ----------
    xData : Type of xData
        Description of xData default None
    yData : Type of yData
        Description of yData default None

    Returns
    -------

    Examples
    --------
    >>>>

    """
    newXData = [xData[0]]
    newYData = copy.deepcopy(yData)
    for currNewYData in newYData:
        currNewYData["dataPoints"] = [currNewYData["dataPoints"][0]]
    #lastSeenYValues = [ currYData["dataPoints"][0] for currYData in yData ]
    for currPointIdx in range(1, len(xData)):
        changedYValue = False
        # Check whether any of the yGraph Values has changed
        for currYDataIdx, currYData in enumerate(yData):
            if abs(currYData["dataPoints"][currPointIdx] - newYData[currYDataIdx]["dataPoints"][-1]) > 0.00001:
                changedYValue = True
        if changedYValue:
            newXData.append(xData[currPointIdx-1])
            newXData.append(xData[currPointIdx])
            for currYDataIdx, currYData in enumerate(yData):
                newYData[currYDataIdx]["dataPoints"].append(currYData["dataPoints"][currPointIdx-1])
                newYData[currYDataIdx]["dataPoints"].append(currYData["dataPoints"][currPointIdx])

    # Always add last data point to make plot long enough
    newXData.append(xData[-1])
    for currYDataIdx, currYData in enumerate(yData):
        newYData[currYDataIdx]["dataPoints"].append(currYData["dataPoints"][-1])

    return newXData, newYData

#====================================================================
# HTML Report Table
#====================================================================
class cHTMLReportTableCell(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, text=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None, tooltip=None, colSpan=None ):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None
        textColor : Type of textColoro
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None
        tooltip : Type of tooltip
            Description of tooltip default None
        colSpan : Type of colSpan
            Description of colSpan default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.text            = text
        self.tooltip         = tooltip
        self.textColor       = textColor
        self.textAlign       = textAlign
        self.textStyle       = textStyle
        self.backgroundColor = backgroundColor
        self.colSpan         = colSpan

    def to_json(self):
        js = {
            '_type': 'cHTMLReportTableCell',
            'text': self.textColor,
            'tooltip': self.tooltip,
            'textColor': self.textColor,
            'textAlign': self.textAlign,
            'textStyle': self.textStyle,
            'backgroundColor': self.backgroundColor,
            'colSpan': self.colSpan,
        }

        return js

    @classmethod
    def from_json(cls, js):

        args = [
            js[key]
            for key in (
                'text',
                'tooltip',
                'textColor',
                'textAlign',
                'textStyle',
                'backgroundColor',
                'colSpan',
            )
        ]

        return cls(
            *args
        )

    def propagateStyle(self, textColor, textAlign, textStyle, backgroundColor):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if self.textColor       is None: self.textColor       = textColor
        if self.textAlign       is None: self.textAlign       = textAlign
        if self.textStyle       is None: self.textStyle       = textStyle
        if self.backgroundColor is None: self.backgroundColor = backgroundColor

class cHTMLReportTableRow(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, cells=[], textColor=None, textAlign=None, textStyle=None, backgroundColor=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        cells : Type of cells
            Description of cells default []
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.cells           = cells
        self.textColor       = textColor
        self.textAlign       = textAlign
        self.textStyle       = textStyle
        self.backgroundColor = backgroundColor

        # Shortcut for handling the row type: If the user just passes a string it is converted to a cell
        for idx,currCell in enumerate(self.cells):
            if type(currCell) is str:
                self.cells[idx] = cHTMLReportTableCell(text=currCell)
            elif type(currCell) is cHTMLReportTableCell:
                pass
            else:
                logging.exception("Wrong argument type: " + str(type(currCell)))

    def to_json(self):
        js = {
            '_type': 'cHTMLReportTableRow',
            'textColor': self.textColor,
            'textAlign': self.textAlign,
            'textStyle': self.textStyle,
            'backgroundColor': self.backgroundColor,
            'cells': [
                cell.to_json()
                for cell in self.cells
            ]
        }

        return js

    @classmethod
    def from_json(cls, js):
        cells = [
            cHTMLReportTableCell.from_json(cell_json)
            for cell_json in js['cells']
        ]

        return cls(
            cells,
            js['textColor'],
            js['textAlign'],
            js['textStyle'],
            js['backgroundColor'],
        )

    def addCell(self, cell):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        cell : Type of cell
            Description of cell default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.cells.append(cell)

    def propagateStyle(self, textColor, textAlign, textStyle, backgroundColor):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if self.textColor       is None: self.textColor       = textColor
        if self.textAlign       is None: self.textAlign       = textAlign
        if self.textStyle       is None: self.textStyle       = textStyle
        if self.backgroundColor is None: self.backgroundColor = backgroundColor

        for currCell in self.cells:
            try:
                currCell.propagateStyle(self.textColor, self.textAlign, self.textStyle, self.backgroundColor)
            except:
                print('Error: wrong type +' + str(currCell) + ' ' + str(type(currCell)))

class cHTMLReportTable(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, label=None, headerRow=None, rows=None, textColor=None, textAlign=None, textStyle=None, backgroundColor=None, headerColSpanRows=None, sortable=True, width=None):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        label : Type of label
            Description of label default None
        headerRow : Type of headerRow
            Description of headerRow default None
        rows : Type of rows
            Description of rows default None
        textColor : Type of textColor
            Description of textColor default None
        textAlign : Type of textAlign
            Description of textAlign default None
        textStyle : Type of textStyle
            Description of textStyle default None
        backgroundColor : Type of backgroundColor
            Description of backgroundColor default None
        headerColSpanRows : Type of headerColSpanRows
            Description of headerColSpanRows default None
        sortable : Type of sortable
            Description of sortable default True
        width : Type of width
            Description of width default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.label           = label
        self.headerRow       = headerRow
        self.rows            = rows
        self.textColor       = textColor
        self.textAlign       = textAlign
        self.textStyle       = textStyle
        self.backgroundColor = backgroundColor
        self.headerColSpanRows = headerColSpanRows
        self.sortable        = sortable
        self.width           = width

        if self.rows is None:
            self.rows = []
        if self.headerColSpanRows is None:
            self.headerColSpanRows = []

    def to_json(self):
        js = {
            '_type': 'cHTMLReportTable',
            'label': self.label,
            'headerRow': self.headerRow if self.headerRow is None else self.headerRow.to_json(),
            'rows': [
                row.to_json()
                for row in self.rows
            ],
            'textColor': self.textColor,
            'textAlign': self.textAlign,
            'textStyle': self.textStyle,
            'backgroundColor': self.backgroundColor,
            'headerColSpanRows': [
                row.to_json()
                for row in self.headerColSpanRows
            ],
            'sortable': self.sortable,
            'width': self.width,
        }

        return js

    @classmethod
    def from_json(cls, js):

        return cls(
            label=js['label'],
            headerRow=cHTMLReportTableRow.from_json(js['headerRow']),
            rows=[
                cHTMLReportTableRow.from_json(row)
                for row in js['rows']
            ],
            textColor=js['textColor'],
            textAlign=js['textAlign'],
            textStyle=js['textStyle'],
            backgroundColor=js['backgroundColor'],
            headerColSpanRows=[
                cHTMLReportTableRow.from_json(row)
                for row in js['headerColSpanRows']
            ],
            sortable=js['sortable'],
            width=js['width'],
        )

    def setHeaderRow(self, headerRow):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        headerRow : Type of headerRow
            Description of headerRow default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.headerRow = headerRow

    def addHeaderDescription(self, headerColSpan):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        headerColSpan : Type of headerColSpan
            Description of headerColSpan default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.headerColSpanRows.append(headerColSpan)

    def addRow(self, row):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        row : Type of row
            Description of row default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.rows.append(row)

    def propagateStyle(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.headerRow.propagateStyle(self.textColor, self.textAlign, self.textStyle, self.backgroundColor)
        for currRow in self.rows:
            currRow.propagateStyle(self.textColor, self.textAlign, self.textStyle, self.backgroundColor)

#====================================================================
# HTML Report Graph
#====================================================================
class cHTMLReportGraphYData(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, dataPoints, name=None, lineColor=None, lineWidth=None, lineType=None, axisAssign = None, yAxisLabel=None, legendLabel=None, NoInterpBetwDataPoints = False):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        dataPoints : Type of dataPoints
            Description of dataPoints default None
        name : Type of name
            Description of name default None
        lineColor : Type of lineColor
            Description of lineColor default None
        lineWidth : Type of lineWidth
            Description of lineWidth default None
        lineType : Type of lineType
            Description of lineType default None
        axisAssign : Type of axisAssign
            Description of axisAssign default None
        yAxisLabel : Type of yAxisLabel
            Description of yAxisLabel default None
        legendLabel : Type of legendLabel
            Description of legendLabel default None
        NoInterpBetwDataPoints : Type of NoInterpBetwDataPoints
            Description of NoInterpBetwDataPoints default False

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.dataPoints = dataPoints
        self.name       = name
        self.lineColor  = lineColor
        self.lineWidth  = lineWidth
        self.lineType   = lineType
        self.axisAssign = axisAssign
        self.yAxisLabel = yAxisLabel
        self.legendLabel = legendLabel
        self.NoInterpBetwDataPoints = NoInterpBetwDataPoints

    def to_json(self):

        js = {
            key: getattr(self, key)
            for key in (
                'name',
                'lineColor',
                'lineWidth',
                'lineType',
                'axisAssign',
                'yAxisLabel',
                'legendLabel',
                'NoInterpBetwDataPoints',
            )
        }
        js['dataPoints'] = self.dataPoints.tolist()
        js['_type'] = 'cHTMLReportGraphYData'

        return js

    @classmethod
    def from_json(cls, js):
        return cls(
            dataPoints=np.array(js['dataPoints']),
            name=js['name'],
            lineColor=js['lineColor'],
            lineWidth=js['lineWidth'],
            lineType=js['lineType'],
            axisAssign=js['axisAssign'],
            yAxisLabel=js['yAxisLabel'],
            legendLabel=js['legendLabel'],
            NoInterpBetwDataPoints=js['NoInterpBetwDataPoints'],
        )


class cHTMLReportGraph(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, xData, yData=[], xDataName=None, title=None, lineWidth=None, syncGroup=None, width=GetSystemMetrics(0)*0.8, height=200, xLim=None, yLim=None, xLabel=None, yLabel=None, vertLines=None, gridAlignAxis=None, highlightedIntervall=[None,None] , helpstring=None, legendLocation = 'right', rangeselector = False, dataReduction = False, time_data=None, is_integer=None,
                 filename=''):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        xData : Type of xData
            Description of xData default None
        yData : Type of yData
            Description of yData default []
        xDataName : Type of xDataName
            Description of xDataName default None
        title : Type of title
            Description of title default None
        lineWidth : Type of lineWidth
            Description of lineWidth default None
        syncGroup : Type of syncGroup
            Description of syncGroup default None
        width : Type of width
            Description of width default GetSystemMetrics()
        is_integer : list
            integers flags for all y data

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.xData      = xData
        self.yData      = yData
        self.xLabel     = xLabel
        self.yLabel     = yLabel
        self.xLim       = xLim
        self.yLim       = yLim
        self.xDataName  = xDataName
        self.title      = title
        self.lineWidth  = lineWidth
        self.syncGroup  = syncGroup
        self.width      = width
        self.height     = height
        self.vertLines  = vertLines
        self.gridAlignAxis        = gridAlignAxis
        self.highlightedIntervall = highlightedIntervall
        self.helpstring           = helpstring
        self.legendLocation       = legendLocation
        self.rangeselector        = rangeselector
        self.dataReduction        = dataReduction
        self.time_data = time_data
        self.is_integer = is_integer
        self.filename = filename

    def to_json(self):

        js = dict(
            _type='cHTMLReportGraph',
            xData=[
                x.to_json()
                for x in self.xData
            ],
            yData=[
                y.to_json()
                for y in self.yData
            ],
            xDataName=self.xDataName,
            title=self.title,
            lineWidth=self.lineWidth,
            syncGroup=self.syncGroup,
            width=self.width,
            height=self.height,
            xLim=self.xLim,
            yLim=self.yLim,
            xLabel=self.xLabel,
            yLabel=self.yLabel,
            vertLines=[
                line.to_json()
                for line in self.vertLines
            ],
            gridAlignAxis=self.gridAlignAxis,
            highlightedIntervall=self.highlightedIntervall,
            helpstring=self.helpstring,
            legendLocation=self.legendLocation,
            rangeselector=self.rangeselector,
            dataReduction=self.dataReduction,
            time_data=self.time_data,
            is_integer=self.is_integer,
            filename=self.filename,
        )

        return js

    @classmethod
    def from_json(cls, js):
        return cls(
            xData=np.array(js['xData']),
            yData=[
                cHTMLReportGraphYData.from_json(y)
                for y in js['yData']
            ],
            xDataName=js['xDataName'],
            title=js['title'],
            lineWidth=js['lineWidth'],
            syncGroup=js['syncGroup'],
            width=js['width'],
            height=js['height'],
            xLim=js['xLim'],
            yLim=js['yLim'],
            xLabel=js['xLabel'],
            yLabel=js['yLabel'],
            vertLines=[
                cHTMLReportVerticalLine.from_json(line)
                for line in js['vertLines']
            ],
            gridAlignAxis=js['gridAlignAxis'],
            highlightedIntervall=js['highlightedIntervall'],
            helpstring=js['helpstring'],
            legendLocation=js['legendLocation'],
            rangeselector=js['rangeselector'],
            dataReduction=js['dataReduction'],
            time_data=js['time_data'],
            is_integer=js['is_integer'],
            filename=js['filename'],
        )

    def addYDataSeries(self, yDataSeries):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        yDataSeries : Type of yDataSeries
            Description of yDataSeries default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.yData.append(yDataSeries)

class cHTMLReportVideo(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, title, videoFileName, imgFileName):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        title : Type of title
            Description of title default None
        videoFileName : Type of videoFileName
            Description of videoFileName default None
        imgFileName : Type of imgFileName
            Description of imgFileName default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.title = title
        self.fileName = videoFileName
        self.imgFileName = imgFileName

class cHTMLReportImage(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, path, title=None, width=100, height=100):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        path : Type of path
            Description of path default None
        title : Type of title
            Description of title default None
        width : Type of width
            Description of width default 100
        height : Type of height
            Description of height default 100

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.title      = title
        self.width      = width
        self.height     = height
        self.path       = path

    def to_json(self):

        js = dict(
            _type='cHTMLReportImage',
            path=self.path,
            title=self.title,
            width=self.width,
            height=self.height,
        )

        return js

    @classmethod
    def from_json(cls, js):
        return cls(
            path=js['path'],
            title=js['title'],
            width=js['width'],
            height=js['height'],
        )

class cHTMLReportLink(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, path, text, prefix = '\n', title = None ):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        path : Type of path
            Description of path default None
        text : Type of text
            Description of text default None
        prefix : Type of prefix
            Description of prefix default '\n'
        title : Type of title
            Description of title default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.prefix     = prefix
        self.text       = text
        self.path       = path
        self.title      = title

    def to_json(self):

        js = dict(
            _type='cHTMLReportLink',
            prefix=self.prefix,
            text=self.text,
            path=self.path,
            title=self.title,
        )

        return js

    @classmethod
    def from_json(cls, js):
        return cls(
            prefix=js['prefix'],
            text=js['text'],
            path=js['path'],
            title=js['title'],
        )

class cHTMLReportVerticalLine(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, sigName, xCoord, color):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        sigName : Type of sigName
            Description of sigName default None
        xCoord : Type of xCoord
            Description of xCoord default None
        color : Type of color
            Description of color default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.sigName = sigName
        self.xCoord = xCoord
        self.color = color

    def to_json(self):

        js = dict(
            _type='cHTMLReportVerticalLine',
            sigName=self.sigName,
            xCoord=float(self.xCoord),
            color=self.color,
        )

        return js

    @classmethod
    def from_json(cls, js):
        return cls(
            sigName=js['sigName'],
            xCoord=js['xCoord'],
            color=js['color'],
        )

class cHTMLReportCode(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, code):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        code : Type of code
            Description of code default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self.code = code

#====================================================================
# HTML Report
#====================================================================
class cHTMLReport(object):
    """

    Parameters
    ----------

    Attributes
    ----------

    """
    def __init__(self, title="", theme="contimodern", toc=False, working_folder='', save_path='', clear=True):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        title : Type of title
            Description of title default ""
        theme : Type of theme
            Description of theme default "contimodern"
        toc : Type of toc
            Description of toc default False
        working_folder : str
            path to working folder for current report

        Returns
        -------

        Examples
        --------
        >>>>

        """

        self._title   = title
        self._content = []
        self._toc     = toc

        self.clear = clear
        self.save_path = save_path

        working_folder = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10)) if working_folder == '' else working_folder
        temp_folder = tempfile.gettempdir()
        self.working_folder = os.path.join(temp_folder, working_folder)

        ### Remove old graphData files at start
        if self.clear:
            if os.path.exists(os.path.join(self.save_path, 'graphData')):
                shutil.rmtree(os.path.join(self.save_path, 'graphData'))

        if not os.path.exists(os.path.join(self.working_folder, 'temp_graphs')):
            os.makedirs(os.path.join(self.working_folder, 'temp_graphs'))

        # Create graphData directory
        if not os.path.exists(
                os.path.join(self.save_path, 'graphData')):
            try:
                os.makedirs(
                    os.path.join(self.save_path, 'graphData'))
            except:
                print('Cannot create output file directory ' + self.save_path)
                sys.exit(0)

        # Load Template
        themePath      = os.path.dirname(__file__) + "/template_" + theme +"/htmlReport_template.py"
        cfgImport      = imp.load_source('currTemplate', themePath )
        self.theme = theme
        self._template = cfgImport.cHTMLReportTemplate()

        self._graph_index = 0

    def to_json(self):

        js = dict(
            _type='cHTMLReport',
            title=self._title,
            theme=self.theme,
            toc=self._toc,
            save_path=self.save_path,
            clear=self.clear,
            _graph_index=self._graph_index,
        )

        items = []

        for item in self._content:
            new_item = {'type': item['type']}

            if item['type'] == 'Table':
                new_item['TableObject'] = item['TableObject'].to_json()
                items.append(new_item)
            elif item['type'] == 'Image':
                new_item['ImageObject'] = item['ImageObject'].to_json()
                items.append(new_item)
            elif item['type'] == 'Link':
                new_item['LinkObject'] = item['LinkObject'].to_json()
                items.append(new_item)
            elif item['type'] == 'Graph':
                new_item['GraphObject'] = item['GraphObject'].to_json()
                items.append(new_item)
            else:
                items.append(item)

        js['content'] = items

        return js

    @classmethod
    def from_json(cls, js):
        rep = cls(
            title=js['title'],
            theme=js['theme'],
            toc=js['toc'],
            save_path=js['save_path'],
            clear=js['clear']
        )

        for item in js['content']:

            if item['type'] == 'Table':
                item['TableObject'] = cHTMLReportTable.from_json(item['TableObject'])
            elif item['type'] == 'Image':
                item['ImageObject'] = cHTMLReportImage.from_json(item['ImageObject'])
            elif item['type'] == 'Link':
                item['LinkObject'] = cHTMLReportLink.from_json(item['LinkObject'])
            elif item['type'] == 'Graph':
                item['GraphObject'] = cHTMLReportGraph.from_json(item['GraphObject'])

            rep._content.append(item)

        rep._graph_index = js['_graph_index']

        return rep

    def _createAdditionalFolders(self, folder):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        folder : Type of folder
            Description of folder default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        additionalFiles = self._template.GetAdditionalFilePaths()

    def _createReportHTML(self, filePath, lazy_reload=True):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        filePath : Type of filePath
            Description of filePath default None
        lazy_reload : Type of lazy_reload
            Description of lazy_reload default True

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not os.path.exists(os.path.dirname(filePath)):
            try:
                os.makedirs(os.path.dirname(filePath))
            except:
                print('Cannot create output file directory ' + os.path.dirname(filePath))
                sys.exit(0)

        gfx = os.path.join(
            os.path.dirname(filePath),
            'gfx',
        )

        tableCount = 0
        with open(filePath, "w") as reportFile:
            if (lazy_reload == False):
                reportFile.write(self._template.CreateHeader(self._title, False))
            else:
                reportFile.write(self._template.CreateHeader(self._title))
            reportFile.write(self._template.CreateInitButtons())
            if self._toc:
                reportFile.write(self._template.CreateSectionBegin("Table of Contents"))
                reportFile.write(self._template.CreateTOC(self._content))
                reportFile.write(self._template.CreateSectionEnd())

            # Process Content List
            for currContentItem in self._content:
                if currContentItem["type"] == "SectionBegin":
                    reportFile.write(self._template.CreateSectionBegin(currContentItem["Label"],anchor=currContentItem["anchor"]))
                elif currContentItem["type"] == "SectionEnd":
                    reportFile.write(self._template.CreateSectionEnd())
                elif currContentItem["type"] == "Text":
                    reportFile.write(self._template.CreateTextSection(currContentItem["TextContent"]))
                elif currContentItem["type"] == "Table":
                    # Table Begin
                    table = currContentItem["TableObject"]
                    table.propagateStyle()
                    reportFile.write(self._template.CreateTableBegin(table.label, tableCount=tableCount, sortable=table.sortable, width=table.width))

                    # Header Column Span
                    if table.headerColSpanRows is not None:
                        reportFile.write(self._template.CreateTableHeaderBegin())
                        for currHeaderColSpanRow in table.headerColSpanRows:
                            reportFile.write(self._template.CreateTableRowBegin())
                            for currHeaderColSpanCell in currHeaderColSpanRow.cells:
                                reportFile.write(self._template.CreateTableHeaderColSpanCell(colSpanWidth=currHeaderColSpanCell.colSpan,
                                                                                             text = currHeaderColSpanCell.text,
                                                                                             textColor       = currHeaderColSpanCell.textColor,
                                                                                             textAlign       = currHeaderColSpanCell.textAlign,
                                                                                             textStyle       = currHeaderColSpanCell.textStyle,
                                                                                             backgroundColor = currHeaderColSpanCell.backgroundColor))
                            reportFile.write(self._template.CreateTableRowEnd())

                    # Table Header
                    if table.headerRow is not None:
                        reportFile.write(self._template.CreateTableRowBegin())
                        for currHeaderCell in table.headerRow.cells:
                            reportFile.write(self._template.CreateTableHeaderCell(text            = currHeaderCell.text,
                                                                                  textColor       = currHeaderCell.textColor,
                                                                                  textAlign       = currHeaderCell.textAlign,
                                                                                  textStyle       = currHeaderCell.textStyle,
                                                                                  backgroundColor = currHeaderCell.backgroundColor))
                        reportFile.write(self._template.CreateTableRowEnd())
                        reportFile.write(self._template.CreateTableHeaderEnd())

                    # Table Rows
                    for currRow in table.rows:
                        reportFile.write(self._template.CreateTableRowBegin())
                        for currCell in currRow.cells:
                            reportFile.write(self._template.CreateTableRowCell(text            = currCell.text,
                                                                               textColor       = currCell.textColor,
                                                                               textAlign       = currCell.textAlign,
                                                                               textStyle       = currCell.textStyle,
                                                                               backgroundColor = currCell.backgroundColor,
                                                                               tooltip         = currCell.tooltip))
                        reportFile.write(self._template.CreateTableRowEnd())
                    # Table End
                    reportFile.write(self._template.CreateTableEnd())
                    tableCount += 1
                elif currContentItem["type"] == "Graph":
                    graph = currContentItem["GraphObject"]
                    reportFile.write(self._template.CreateGraph(graph, self.save_path))
                elif currContentItem["type"] == "Image":
                    o = currContentItem["ImageObject"]
                    new_path = os.path.join(
                        gfx,
                        os.path.basename(o.path),
                    )
                    rel_path = os.path.join(
                        'gfx',
                        os.path.basename(o.path),
                    )
                    shutil.copy(o.path, os.path.join(gfx, new_path))
                    imageData = {"width": o.width, "height": o.height, "title": o.title, "path" : rel_path}
                    reportFile.write(self._template.CreateImage(imageData))
                elif currContentItem["type"] == "Video":
                    o = currContentItem["VideoObject"]
                    videoData = {"title": o.title, "fileName": o.fileName, "imgFileName": o.imgFileName}
                    reportFile.write(self._template.CreateVideo(videoData))
                elif currContentItem["type"] == "Link":
                    o = currContentItem["LinkObject"]
                    linkData = {"path": o.path, "text": o.text, "title": o.title, "prefix": o.prefix}
                    reportFile.write(self._template.CreateLink(linkData))
                elif currContentItem["type"] == "Code":
                    o = currContentItem["CodeObject"]
                    codeData = {"code": o.code}
                    reportFile.write(self._template.AddHTMLCode(codeData))
                else:
                    pass
            reportFile.write(self._template.CreateFooter())

    def _generate_graph(self, graphData):
        time_axis = graphData['time_data']
        MARGIN_FACTOR_LEFT = 100
        HIGHLIGHT_COLOR_RBGA = "rgba(255,255,255, 0.05)"

        if graphData["syncGroup"] is None:
            graphData["syncGroup"] = "{nogroup}"
        # graphID = "graph{0:04d}".format(self._graphCount)
        graphID = os.path.basename(graphData['filename'])
        legendID = "legend{0:04d}".format(self._graph_index)
        graphData["legend"] = 'always'
        vertLinesList = graphData["vertLines"]

        # Declare js-file

        jsFileString = """var current_section_level = {: >10}; var nogroup = {: >20};
var MARGIN_FACTOR_LEFT = 100;
var marginLeft =  current_section_level * MARGIN_FACTOR_LEFT;
""".format('', '')

        ### Write Graph Data to file
        jsFileString += 'var vertLines{graphID} = new Array();\n'.replace(
            "{graphID}", graphID)
        if vertLinesList is not None:
            for i, obj in enumerate(vertLinesList):
                jsFileString += 'vertLines{graphID}[{i}] = new Object();\n'.replace(
                    "{i}", str(i)).replace("{graphID}", graphID)
                jsFileString += 'vertLines{graphID}[{i}]["sigName"] = "{sigName}";\n'.replace(
                    "{i}", str(i)).replace("{sigName}",
                                           vertLinesList[i].sigName).replace(
                    "{graphID}", graphID)
                jsFileString += 'vertLines{graphID}[{i}]["xCoord"] = {xCoord};\n'.replace(
                    "{i}", str(i)).replace("{xCoord}", str(
                    vertLinesList[i].xCoord)).replace("{graphID}", graphID)
                jsFileString += 'vertLines{graphID}[{i}]["color"] = "{color}";\n'.replace(
                    "{i}", str(i)).replace("{color}", str(
                    vertLinesList[i].color)).replace("{graphID}", graphID)

        currEqualNumberCount = []
        for currYData in graphData["yData"]:
            currEqualNumberCount.append(0)

        jsFileString += 'var GraphData{graphID} = '.replace("{graphID}",
                                                            graphID)
        jsFileString += "[\n"

        vals = np.column_stack(
            [graphData['xData'], ] + [x['dataPoints'] for x in graphData["yData"]]
        )
        lines = ['[{}],\n'.format(','.join(line)) for line in vals]

        # xdata = graphData['xData']
        #
        # ydata = [x['dataPoints'] for x in graphData["yData"]]
        # lines = ['[{}],\n'.format(','.join(vals)) for vals in zip(xdata, *ydata)]

        jsFileString += ''.join(lines)

        jsFileString += '\n];\n'

        jsFileString += 'function addGraphToHTML() {\n$("#{GraphID}") .html("\\\n'.replace(
            '{GraphID}', graphID)

        ### Graph Prefix
        jsFileString += '<div style=\'margin-left\': {{marginLeft}}px;\' id=\'{graphName}\'></div>\\\n<script type=\'text/javascript\'>\\\n'.format(
            graphName=graphID)
        jsFileString += 'if (typeof {syncGroupName} == \'undefined\'){{syncGroupName} = [];}\\\n{syncGroupName}.push(\\\nnew Dygraph(\\\ndocument.getElementById(\'{graphName}\'),\\\n'.replace(
            "{syncGroupName}", graphData["syncGroup"]).replace("{graphName}",
                                                               graphID)

        ### Call function from extern js-file
        jsFileString += 'getData_{graphID}(),\\\n'.replace("{graphID}",
                                                           graphID)

        ### Graph Options
        jsFileString += "{\\\n"

        # Labels
        if graphData["xDataName"] is None: graphData["xDataName"] = ""

        # Get max num of y-axis-labels
        maxNumYLabels = 0
        for i, currYData in enumerate(graphData["yData"]):
            if (currYData["yAxisLabel"] is not None):
                if len(currYData["yAxisLabel"]) > maxNumYLabels:
                    maxNumYLabels = len(currYData["yAxisLabel"])

        # Adapt graph height to max number of y-axis-labels
        for i, currYData in enumerate(graphData["yData"]):
            if currYData["axisAssign"] == 'y2':
                additionalWidth = 56
                break
            else:
                additionalWidth = 0
        jsFileString += 'width: ' + str(
            graphData["width"] + additionalWidth) + ', height: ' + str(
            graphData["height"]) + ',\\\n'

        jsFileString += 'labels: [\'{xDataLabel}\''.format(
            xDataLabel=graphData["xDataName"])
        for currYData in graphData["yData"]:
            if currYData["name"] is None: currYData["name"] = ""
            jsFileString += ',\'{currYDataLabel}\''.format(
                currYDataLabel=currYData["name"])
        jsFileString += "],\\\n"

        # animated zoom
        jsFileString += "animatedZooms: true,\\\n"

        # range selector
        if graphData["rangeselector"] is True:
            jsFileString += "showRangeSelector: true,\\\n"
            jsFileString += "rangeSelectorHeight: 35,\\\n"
            jsFileString += "rangeSelectorPlotStrokeColor: 'black',\\\n"
            jsFileString += "rangeSelectorPlotFillColor: '',\\\n"
        # Set special y axis labels
        jsFileString += 'connectSeparatedPoints: true,'
        jsFileString += 'axes:{'

        for i, (currYData, integer) in enumerate(
                zip(graphData["yData"], graphData['is_integer'])):
            if currYData["axisAssign"] is not None:
                jsFileString += '{yAxis}:{'.replace('{yAxis}', str(
                    currYData["axisAssign"]))
            else:
                jsFileString += '{yAxis}:{'.replace('{yAxis}', 'y')
            if currYData["yAxisLabel"] is not None:
                jsFileString += 'axisLabelFormatter: function({yDataLabel}){'.replace(
                    "{yDataLabel}", currYData["name"])
                jsFileString += "if({yDataLabel}>=0 && {yDataLabel}<1) return '{STATE}';".replace(
                    "{STATE}", currYData["yAxisLabel"][str(0)]).replace(
                    "{yDataLabel}", currYData["name"])
                for j in range(0, len(currYData["yAxisLabel"])):
                    jsFileString += "else if({yDataLabel}>={j} && {yDataLabel}<{j}+1) return '{STATE}';".replace(
                        "{j}", str(j)).replace("{STATE}",
                                               currYData["yAxisLabel"][
                                                   str(j)]).replace(
                        "{yDataLabel}", currYData["name"])
                jsFileString += '},'
            if currYData["legendLabel"] is not None:
                #   valueFormatter-Function:
                #   declares aliases for the values: Instead of numbers, the legend will show names returned by this function
                jsFileString += 'valueFormatter: function({legendLabel}){'.replace(
                    "{legendLabel}", currYData["name"])
                jsFileString += "if({legendLabel}>=0 && {legendLabel}<1) return '{STATE}';".replace(
                    "{STATE}", currYData["legendLabel"][str(0)]).replace(
                    "{legendLabel}", currYData["name"])
                for j in range(0, len(currYData["legendLabel"])):
                    jsFileString += "else if({legendLabel}>={j} && {legendLabel}<{j}+1) return '{STATE}';".replace(
                        "{j}", str(j)).replace("{STATE}",
                                               currYData["legendLabel"][
                                                   str(j)]).replace(
                        "{legendLabel}", currYData["name"])
                jsFileString += '},'

            if graphData["gridAlignAxis"] is not None:
                if graphData["gridAlignAxis"] == currYData["axisAssign"]:
                    jsFileString += 'drawGrid: true, independentTicks: true'
                else:
                    jsFileString += 'drawGrid: false, independentTicks: true'
            else:
                jsFileString += 'drawGrid: true, independentTicks: true'

            prec = '' if integer else '.toPrecision(6)'
            jsFileString += ", valueFormatter: function(y) {{{{return y{0};}}}},axisLabelFormatter: function(y) {{{{return y;}}}}".format(
                prec)
            # else:
            #    jsFileString += 'drawGrid: false'
            jsFileString += '},'
        jsFileString += '},\\\n'

        # Ranges
        if graphData["xLim"] is not None:
            jsFileString += "dateWindow: [{xMin},{xMax}],\\\n".format(
                xMin=graphData["xLim"][0], xMax=graphData["xLim"][1])

        if graphData["yLim"] is not None:
            jsFileString += "valueRange: [{yMin},{yMax}],\\\n".format(
                yMin=graphData["yLim"][0], yMax=graphData["yLim"][1])

        if graphData["xLabel"] is not None:
            jsFileString += 'xlabel: \'%s\',\\\n' % graphData["xLabel"]

        # if len(graphData["yData"])>1:
        #    if graphData["yLabel"] is not None:
        #        jsFileString += 'ylabel: \'%s\',' % graphData["yData"][0]["name"]
        #    if len(graphData["yData"])>1:
        #        jsFileString += 'y2label: \'%s\',' % graphData["yLabel"]
        # else:
        #    if graphData["yLabel"] is not None:
        #        jsFileString += 'ylabel: \'%s\',' % graphData["yLabel"]
        if graphData["yLabel"] is not None:
            jsFileString += 'ylabel: \'%s\',\\\n' % graphData[
                "yLabel"]  # <  The label for the first y-axis will always be derived from
            #   the graphs "yLabel"-property
            if currYData[
                "axisAssign"] == "y2":  # <  If however the current line is assigned to a second y-axis,
                jsFileString += 'y2label: \'%s\',\\\n' % currYData[
                    "name"]  # the second y-label is derived from the Name-Property of
                #   the line.

        if graphData["legend"] is not None:
            jsFileString += 'legend: \'%s\',\\\n' % graphData["legend"]

        #   put legend outside, if asked to
        if graphData["legendLocation"] == "inside":
            pass
        elif graphData["legendLocation"] == "below":
            jsFileString += "labelsDiv: document.getElementById('{0}_below'), ".format(
                legendID)
            jsFileString += "labelsSeparateLines: true,\\\n"
        else:  # < default, put it at the right side of the plot (outside)
            jsFileString += "labelsDiv: document.getElementById('{0}_right'), ".format(
                legendID)
            jsFileString += "labelsSeparateLines: true,\\\n"

        # Colors
        jsFileString += "colors: ["
        currContiColorID = 0
        for currYData in graphData["yData"]:
            if currYData["lineColor"] is None: currYData["lineColor"] = COLORS[
                currContiColorID]
            jsFileString += '\'rgb({red},{green},{blue})\','.format(
                red=currYData["lineColor"][0], green=currYData["lineColor"][1],
                blue=currYData["lineColor"][2])
            currContiColorID = (currContiColorID + 1) % len(COLORS)
        jsFileString += "],\\\n"

        # Strokes
        i = 0
        for currYData in graphData["yData"]:
            jsFileString += "'{currYDataLabel}':".format(
                currYDataLabel=currYData["name"])
            jsFileString += "{"
            if currYData[
                "lineType"] is not None:  # default/None: data points will be connected to line, otherwise set lineType=drawPoints
                if currYData["lineType"] == "drawPoints":
                    jsFileString += "strokeWidth: 0, drawPoints: true, pointSize: 2, "
                else:
                    jsFileString += "strokePattern: {strokeType},".format(
                        strokeType=currYData["lineType"])
            if currYData["lineWidth"] is not None:
                jsFileString += "strokeWidth: {strokeWidth},".format(
                    strokeWidth=currYData["lineWidth"])
            # if currYData["yAxisLabel"] is not None and i==len(graphData["yData"])-1 and len(graphData["yData"])>1:
            # Assign
            if currYData["axisAssign"] == "y2":
                jsFileString += "axis:{}"
            jsFileString += "},\\\n"
            i += 1

        #   highlight areas
        hl = graphData["highlightedIntervall"]
        if (hl[0] is None) and (hl[1] is None):  # <  highlight nothing
            hl[0] = 0
            hl[1] = 0
        elif (hl[0] is None) and (
                hl[1] is not None):  # <  highlight everything up until hl[1]
            hl[0] = graphData["xData"][0]
        elif (hl[1] is None) and (hl[
                                      0] is not None):  # <  highlight everything from hl[0] to the end
            hl[1] = graphData["xData"][-1]
            # <  else: hl[0] and hl[1] were given and are used by default

        jsFileString += ("drawCallback:\\\nfunction(me, initial) {\\\n"
                         "if (blockRedraw || initial) return; \\\nblockRedraw = true; \\\n"
                         "var range = me.xAxisRange();\\\n"
                         "for (var j = 0; j < {syncGroupName}.length; j++) { \\\n"
                         "if ({syncGroupName}[j] == me) continue; \\\n"
                         "{syncGroupName}[j].updateOptions( { \\\n"
                         "dateWindow: range \\\n"
                         "} ); \\\n"
                         "} \\\n"
                         "blockRedraw = false; \\\n"
                         "}\\\n"
                         "\\\n, highlightCallback: function(e, x, pts, row) { \\\n"
                         "for (var j = 0; j < {syncGroupName}.length; j++) { \\\n"
                         "{syncGroupName}[j].setSelection(row); \\\n"
                         "}},underlayCallback: function (canvas, area, g)\\\n{\\\n"
                         'var bottom_left = g.toDomCoords({highlight_start}, -20);\\\n'
                         'var top_right = g.toDomCoords({highlight_end}, +20);\\\n'
                         'var left = bottom_left[0];\\\n'
                         'var right = top_right[0];\\\n'
                         "canvas.fillStyle = '{color}';\\\n"
                         'canvas.fillRect(left, area.y, right - left, area.h);\\\n'
                         'var range{graphID} = g.xAxisRange();\\\n'
                         'var xRange{graphID} = range{graphID}[1]-range{graphID}[0];\\\n'
                         'for (var i=0; i < {vertLineCount};i++) {\\\n'
                         "var VertLineXCoord{graphID}=vertLines{graphID}[i]['xCoord'];\\\n"
                         'var line_start{graphID} = VertLineXCoord{graphID}-0.001*xRange{graphID};\\\n'
                         'var line_end{graphID}=VertLineXCoord{graphID}+0.001*xRange{graphID};\\\n'
                         'var bottom_left{graphID} = g.toDomCoords(line_start{graphID}, 0);\\\n'
                         'var top_right{graphID} = g.toDomCoords(line_end{graphID}, 0);\\\n'
                         'var left{graphID}=bottom_left{graphID}[0];\\\n'
                         'var right{graphID} = top_right{graphID}[0]; \\\n'
                         "canvas.fillStyle=vertLines{graphID}[i]['color'];\\\n"
                         'canvas.fillRect(left{graphID}, area.y, right{graphID}-left{graphID}, area.h);\\\n'
                         '}}'
                         '}));\\\n</script>".replace(/{marginLeft}/g    ,marginLeft).replace(/{nogroup}/g    ,nogroup)\n').replace("{syncGroupName}",
                                                         graphData[
                                                             "syncGroup"]) \
            .replace("{graphID}", graphID) \
            .replace("{highlight_start}", str(hl[0])) \
            .replace("{highlight_end}", str(hl[1])) \
            .replace("{color}", HIGHLIGHT_COLOR_RBGA)

        if vertLinesList is not None:
            jsFileString = jsFileString.replace("{vertLineCount}",
                                                str(len(vertLinesList)))
        else:
            jsFileString = jsFileString.replace("{vertLineCount}", "0")

        jsFileString += ');}\n'

        with open(os.path.join(self.save_path,
                               'graphData/graphData_{graphID}.js'.replace(
                                       "{graphID}", graphID)), 'w') as file:
            file.write(jsFileString)
            file.write(
                'function getData_{graphID}() { return GraphData{graphID};}'.replace(
                    "{graphID}", graphID))

    def Save(self, filePath):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        filePath : Type of filePath
            Description of filePath default None

        Returns
        -------

        Examples
        --------
        >>>>

        """

        # Generate HTML File

        # Generate additional folders and copy additional files
        additionalFolders = self._template.GetFoldersInDirectory()

        for currAdditionalFolder in additionalFolders:
            os.makedirs(
                os.path.join(
                    self.save_path,
                    os.path.basename(currAdditionalFolder),
                ),
                exist_ok=True,
            )

        #self._createReportHTML(filePath, lazy_reload=False)
        self._createReportHTML(filePath)

        for currAdditionalFolder in additionalFolders:
            copytree(currAdditionalFolder, os.path.join(self.save_path, os.path.basename(currAdditionalFolder)))

        shutil.rmtree(os.path.join(self.working_folder, 'temp_graphs'), True)

    def SectionBegin(self, sectionLabel,anchor=[], additional_html=[]):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        sectionLabel : Type of sectionLabel
            Description of sectionLabel default None
        anchor : Type of anchor
            Description of anchor default []
        additional_html : Type of additional_html
            Description of additional_html default []

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self._content.append({"type": "SectionBegin", "Label": sectionLabel,"anchor": anchor,"additional_html": additional_html})

    def SectionEnd(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        self._content.append({"type": "SectionEnd"})

    def SwapLastSection(self):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------

        Returns
        -------

        Examples
        --------
        >>>>

        """
        new_section = []
        pos = len(self._content)
        cntr = 0
        for i, item in enumerate(self._content[::-1]):
            pos -= 1
            cntr += 1
            if item['type'] == 'SectionBegin':
                break
        for i in range(cntr):
            new_section.append(self._content.pop(pos))
        new_section.extend(self._content)
        self._content = new_section


    def AddText(self, text):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        text : Type of text
            Description of text default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not type(text) is str:
            logging.exception("Wrong argument type: " + str(type(text)))

        self._content.append({"type": "Text", "TextContent": text})

    def AddTable(self, table):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        table : Type of table
            Description of table default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not type(table) is cHTMLReportTable:
            logging.exception("Wrong argument type: " + str(type(table)))

        self._content.append({"type": "Table", "TableObject": table})

    def AddGraph(self, graph, name=''):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        graph : Type of graph
            Description of graph default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not type(graph) is cHTMLReportGraph:
            logging.exception("Wrong argument type: " + str(type(graph)))

        ALLOWED_CHARS = string.ascii_letters + string.digits + '_'

        filename = '{}_{}'.format(
                name,
                self._graph_index,
        )

        filename = [
            c if c in ALLOWED_CHARS else '_'
            for c in filename
        ]

        filename = ''.join(filename)

        g = graph
        graph.filename = filename

        yData = []
        for currYDataSeries in g.yData:
            currYData = {}
            currYData["dataPoints"] = currYDataSeries.dataPoints
            currYData["name"] = currYDataSeries.name
            currYData["lineColor"] = currYDataSeries.lineColor
            currYData["lineType"] = currYDataSeries.lineType
            currYData["lineWidth"] = g.lineWidth
            currYData["axisAssign"] = currYDataSeries.axisAssign
            currYData["yAxisLabel"] = currYDataSeries.yAxisLabel
            currYData["legendLabel"] = currYDataSeries.legendLabel
            currYData[
                "NoInterpBetwDataPoints"] = currYDataSeries.NoInterpBetwDataPoints

            if currYDataSeries.lineWidth is not None: currYData[
                "lineWidth"] = currYDataSeries.lineWidth
            yData.append(currYData)

        if g.dataReduction:
            xData, yData = ReducePlotData(g.xData, yData)
        else:
            xData = g.xData

        graphData = {"width": g.width, "height": g.height,\
                                 "title": g.title, "xData": xData, "yData": yData, "xDataName": g.xDataName,\
                                 "xLim": g.xLim, "yLim" : g.yLim, "xLabel":g.xLabel, "yLabel":g.yLabel,\
                                 "syncGroup": g.syncGroup, "vertLines": g.vertLines, "gridAlignAxis": g.gridAlignAxis,
                                 "highlightedIntervall": g.highlightedIntervall,
                                 "helpstring": g.helpstring,
                                 "legendLocation": g.legendLocation,
                                 "rangeselector" : g.rangeselector,
                                 "time_data":g.time_data,
                                 "filename": filename,
                                 "is_integer": g.is_integer}

        graphData['filename'] = filename

        self._generate_graph(graphData)

        graph.xData = []
        graph.yData = []

        self._content.append({"type": "Graph", "GraphObject": graph})

        self._graph_index += 1

    def AddVideo(self, video):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        video : Type of video
            Description of video default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not type(video) is cHTMLReportVideo:
            logging.exception("Wrong argument type: " + str(type(video)))

        self._content.append({"type": "Video", "VideoObject": video})

    def AddImage(self, img):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        img : Type of img
            Description of img default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        if not type(img) is cHTMLReportImage:
            logging.exception("Wrong argument type: " + str(type(img)))

        self._content.append({"type": "Image", "ImageObject": img})

    def AddLink(self, link):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        link : Type of link
            Description of link default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        """"
        Adds a link to the content list
        """
        if not type(link) is cHTMLReportLink:
            logging.exception("Wrong argument type: " + str(type(link)))

        self._content.append({"type": "Link", "LinkObject": link})

    def GetLink(self, link):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        link : Type of link
            Description of link default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        """"
        Directly returns a html-link-string
        """
        if not type(link) is cHTMLReportLink:
            logging.exception("Wrong argument type: " + str(type(link)))
        linkData = {"path": link.path, "text": link.text,"prefix": link.prefix, "title": link.title}
        return self._template.CreateLink(linkData)

    def AddHTMLCode(self, code):
        """"Summary line.

        Extended description of function.

        Parameters
        ----------
        code : Type of code
            Description of code default None

        Returns
        -------

        Examples
        --------
        >>>>

        """
        return self._content.append({"type": 'Code', "CodeObject": code})
