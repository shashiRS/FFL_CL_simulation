# -*- coding: utf-8 -*-
"""
Created on Thu Aug 24 10:03:29 2017

@author: uidn3651
"""

import pickle
import os
import logging
from collections import OrderedDict
from functools import reduce
from textwrap import wrap
from datetime import datetime

import numpy as np
from PIL import Image

from .pyHTMLReport.htmlReport import *
from ..version import __version__


class Verdict:
    '''Enumeration used for the verdicts. The options are:
       unknown(0), failed(-1) and passed(1).

    '''
    unknown = 0
    failed = -1
    passed = 1

    @staticmethod
    def to_string(value):
        if value == Verdict.unknown:
            string = 'UNKNOWN'
        elif value == Verdict.failed:
            string = 'FAILED'
        elif value == Verdict.passed:
            string = 'PASSED'
        else:
            raise ValueError('Invalid Verdict value {}'.format(value))
        return string


class HTMLReport(object):
    """
    Html report generator

    Parameters
    ----------
    title : str
        report title
    default_graph : bool
        enable autogeneration of graph from testcase's signals attribute in case no
        graphs are found in the testcase specification
    display_log : bool
        enable suplimentary report column with the evaluation log
    environment : dict
        description of environment (for example lib versions, sw versions, etc)
        default *None*


    Attributes
    ----------
    results : OrderedDict
        the keys are the test case ID's and the values are dicts of (measurement files: Verdict) pairs
    comments : OrderedDict
        the keys are the test case ID's and the values are dicts of (measurement files: comment string) oairs
    log : OrderedDict
        the keys are the test case ID's and the values are dicts of (measurement files: evaluation log string) pairs
    report : cHTMLReport
        dictionary of triggers (type `Trigger`)
    environment : dict
        description of environment (for example lib versions, sw versions, etc)

    """

    def __init__(self, title, default_graph=False, display_log=False, working_folder='', environment=None, output_dir='', clear=True):
        self.default_graph = default_graph
        self.display_log = display_log
        self.results = {}
        self.comments = {}
        self.log = {}
        self.descriptions = {}
        self.report = cHTMLReport(title=title, theme="contimodern", toc=True, working_folder=working_folder, save_path=output_dir, clear=clear)
        self.stats = {}
        self.title = title
        self.environment = environment or {}
        self.environment['Date'] = datetime.now().strftime('%d %b %Y %H:%M:%S')
        self.environment['report lib version'] = __version__

        self.requirements_db = {}

        self.report.SectionBegin("Graphical overview")
        self.working_folder = working_folder
        self.output_dir = output_dir
        self.clear = clear

    def append(self, testcase, measurement='', picture=None):
        ''' append test case evaluation to report

        Parameters
        ----------
        testcase : Testcase
            test case object
        measurement : str
            measurement file name; default is ''
        picture : str
            path to picture to be added after graphs for the current measurement

        '''
        gname = None
        if not testcase.id in self.results:
            self.results[testcase.id] = {}
            self.comments[testcase.id] = {}
            self.log[testcase.id] = {}
            self.descriptions[testcase.id] = testcase.description.replace('<', '&lt').replace('>', '&gt')

            if testcase.requirements:
                for req in testcase.requirements:
                    if req not in self.requirements_db:
                        self.requirements_db[req] = set()
                    self.requirements_db[req].add(testcase.id)
            else:
                if 'unlinked' not in self.requirements_db:
                    self.requirements_db['unlinked'] = set()
                self.requirements_db['unlinked'].add(testcase.id)

        try:
            if testcase.result is None:
                testcase.evaluate()
        except Exception as err:
            self.append_error(testcase.id,
                              measurement,
                              'Check evaluation arguments:'\
                              '\n\t- Expected Results string consistency,'\
                              '\n\t- Provided Signals consitency.'
                              '\nExit with error: "{}"'.format(err),
                              )
        else:

            stats = testcase.compute_stats()
            if stats:
                stats_key = tuple(stats)
                if stats_key not in self.stats:
                    self.stats[stats_key] = []

                self.stats[stats_key].append(
                    (measurement, testcase.result, list(stats.values()))
                )

                if any(sts[2] for sts in stats.values()):
                    mark_yellow = True
                else:
                    mark_yellow = False
            else:
                mark_yellow = False

            self.results[testcase.id][measurement] = testcase.result, mark_yellow
            self.comments[testcase.id][measurement] = (
                testcase
                .comments
                .replace('<', '&lt')
                .replace('>', '&gt')
            )
            self.log[testcase.id][measurement] = testcase.log

            vertLines = []

            if len(testcase.triggers):
                incr = 200 // len(testcase.triggers)
                for i, (tname, trig) in enumerate(testcase.triggers.items()):
                    if trig.timestamp is not None:
                        if isinstance(trig.timestamp, list):
                            for item in trig.timestamp:
                                if item is not None:
                                    vertLines.append(
                                        cHTMLReportVerticalLine(
                                            tname,
                                            round(float(item), 6),
                                            'RGB(0,255,{})'.format(i*incr + 55),
                                        )
                                    )
                        else:
                            vertLines.append(
                                cHTMLReportVerticalLine(
                                    tname,
                                    round(float(trig.timestamp), 6),
                                    'RGB(0,0,{})'.format(i*incr + 55),
                                )
                        )

            # graphs section
            if len(testcase.graphs):
                self.report.SectionBegin("TC {}: {}".format(testcase.id, measurement))

                if picture:

                    image = Image.open(picture)
                    width, height = image.size
                    self.report.AddImage(
                        cHTMLReportImage(
                            picture,
                            'my_image',
                            width=width,
                            height=height,
                        )
                    )
                for gname, graph in testcase.graphs.items():
                    try:
                        # Update signal name to contain Replacement(ASAP))
                        for signal in graph['signals']:
                            asap = graph['signals'][signal].name
                            if '(' not in asap:
                                graph['signals'][signal].name = "{} ({})".format(signal, asap)
                        g_signals = list(graph['signals'].values())
                        a_signals = list(graph['signals'])
                        time_axis = [s.time for s in g_signals]
                        # g_signals = [s.signal for s in g_signals]
                        is_integer = [1 if s.signal.dtype.kind in 'ui' else 0 for s in g_signals]
                        stroke = [7, 3]

                        strokes = [None for g in g_signals]

                        t = time_axis[0]
                        for arch_name, const in graph['constants'].items():
                            new_sig = g_signals[0].copy()
                            vall = np.ones(len(new_sig), dtype=np.int8) * const.x
                            new_sig.signal = vall
                            g_signals.append(new_sig)
                            a_signals.append(arch_name)
                            is_integer.append(1 if vall.dtype.kind in 'ui' else 0)
                            strokes.append(stroke)

                        time_axis = [np.around(t, 6) for t in time_axis]
                        xdata = reduce(np.union1d, time_axis)

                        g_signals = [sig.interp(xdata).signal for sig in g_signals]
                        g_signals = [s.astype(np.float32) if s.dtype.kind == 'f' else s for s in g_signals]
                        g_signals = [sig.astype('U32') for sig in g_signals]
                        indexes = [np.intersect1d(np.argwhere(xdata < t[0]), np.argwhere(xdata > t[-1])) for t in time_axis]
                        for sig, idx in zip(g_signals, indexes):
                            sig[idx] = ''

                        xdata = xdata.astype('U32')
                        ydata = [
                            cHTMLReportGraphYData(sig, asig, lineType=stroke)
                            for sig, asig, integer, stroke in zip(g_signals, a_signals, is_integer, strokes)
                            if not integer
                        ]
                        ydata += [
                            cHTMLReportGraphYData(sig, asig, lineType=stroke)
                            for sig, asig, integer, stroke in zip(g_signals, a_signals, is_integer, strokes)
                            if integer
                        ]
                        is_integer.sort()
                        title = graph['title']
                        gr = cHTMLReportGraph(xdata, ydata, xLim=[0, xdata[-1]],
                                              xLabel='t [s]', yLabel='', title=title, width=1000,
                                              height=300, legendLocation = 'top', vertLines=vertLines,
                                              is_integer=is_integer)
                        self.report.AddGraph(
                            gr,
                            '{}_{}'.format(
                                gname,
                                testcase.id,
                            ),
                        )
                    except Exception as err:
                        raise
                        self.comments[testcase.id][measurement] += '\n\nGraph {} error: {}\n'.format(gname, err)

                self.report.SectionEnd()

            elif self.default_graph:
                self.report.SectionBegin("TC {}: {}".format(testcase.id, measurement))
                try:
                    # Update signal name to contain Replacement(ASAP))
                    for signal in testcase.signals:
                        asap = testcase.signals[signal].name
                        if '(' not in asap:
                            testcase.signals[signal].name = "{} ({})".format(signal, asap)

                    signals = testcase.signals.values()
                    a_signals = [s.name for s in signals if s.signal.dtype.kind not in 'SUV']
                    time_axis = [s.time for s in signals if s.signal.dtype.kind not in 'SUV']
                    g_signals = [s for s in signals if s.signal.dtype.kind not in 'SUV']
                    is_integer = [
                        1 if s.signal.dtype.kind in 'ui' else 0
                        for s in g_signals
                    ]

                    time_axis = [np.around(t, 4) for t in time_axis]
                    xdata = reduce(np.union1d, time_axis)

                    g_signals = [s.interp(xdata).signal.astype('U32') for s in g_signals]
                    indexes = [np.intersect1d(np.argwhere(xdata < t[0]), np.argwhere(xdata > t[-1])) for t in time_axis]
                    for sig, idx in zip(g_signals, indexes):
                        sig[idx] = ''

                    xdata = xdata.astype('U32')

                    ydata = [
                        cHTMLReportGraphYData(sig, asig)
                        for sig, asig, integer in
                        zip(g_signals, a_signals, is_integer)
                        if not integer
                    ]
                    ydata += [
                        cHTMLReportGraphYData(sig, asig)
                        for sig, asig, integer in
                        zip(g_signals, a_signals, is_integer)
                        if integer
                    ]
                    is_integer.sort()

                    title = str(testcase.id)
                    gr = cHTMLReportGraph(xdata, ydata, xLim=[0, xdata[-1]],
                                          xLabel='t [s]', yLabel='', title=title, width=1000,
                                          height=300, legendLocation = 'top', vertLines=vertLines,
                                          is_integer=is_integer)
                    self.report.AddGraph(gr)
                except Exception as err:
                    self.comments[testcase.id][measurement] += '\n\nDefault Graph error: {}\n'.format(gname, err)

                self.report.SectionEnd()

    def append_error(self, testcase_id, measurement, error, log=''):
        ''' appends an error section to the report. This is called when an exception is triggered

        Parameters
        ----------
        testcase_id : str
            test case ID
        measurement : str
            measurement file name
        error : traceback
            traceback of exception
        log : str
            testcase log if available, default ""

        '''
        self.report.SectionBegin("TC {}: {}".format(testcase_id, measurement))
        self.report.SectionEnd()
        if not testcase_id in self.results:
            self.results[testcase_id] = {}
            self.comments[testcase_id] = {}
            self.log[testcase_id] = {}
            self.descriptions[testcase_id] = ''

            # TO DO : manage requirements for failed tests
            # if testcase.requirements:
            #     for req in testcase.requirements:
            #         if req not in self.requirements_db:
            #             self.requirements_db[req] = set()
            #         self.requirements_db[req].add(testcase.id)
            # else:
            #     if 'unlinked' not in self.requirements_db:
            #         self.requirements_db['unlinked'] = set()
            #     self.requirements_db['unlinked'].add(testcase.id)
        self.results[testcase_id][measurement] = Verdict.unknown, False
        comments = "\n!!! Exception occured: {}".format(error)
        if measurement not in self.comments[testcase_id].keys():
            self.comments[testcase_id][measurement] = comments
        else:
            self.comments[testcase_id][measurement] += comments
        self.log[testcase_id][measurement] = log

    def to_json(self):
        js = dict(
            default_graph=self.default_graph,
            display_log=self.display_log,
            results=self.results,
            comments=self.comments,
            log=self.log,
            working_folder=self.working_folder,
            output_dir=self.output_dir,
            clear=self.clear,
            report=self.report.to_json(),
            stats={str(key): val for key, val in self.stats.items()},
            title=self.title,
            descriptions=self.descriptions,
            requirements_db={key: list(val) for key, val in self.requirements_db.items()},
            environment=self.environment,
        )

        return js

    @classmethod
    def from_json(cls, js):
        rep = cls(
            title=js['title'],
            default_graph=js['default_graph'],
            display_log=js['display_log'],
            environment=js['environment'],
            working_folder=js['working_folder'],
            output_dir=js['output_dir'],
            clear=js['clear']
        )

        rep.comments = js['comments']
        rep.results = js['results']
        rep.descriptions = js['descriptions']
        rep.log = js['log']
        rep.stats = {eval(key): val for key, val in js['stats'].items()}
        rep.report = cHTMLReport.from_json(js['report'])
        rep.requirements_db = {key: set(val) for key, val in js['requirements_db'].items()}

        return rep

    @classmethod
    def load(cls, name):
        """ load raw report from pickle file"""
        with open(name, 'rb') as source:
            return pickle.load(source)

    def dump(self, name):
        """ dump raw report to pickle file"""
        with open(name, 'wb') as destination:
            pickle.dump(self, destination)

    def save(self):
        ''' creates Report folder in *output_dir* and saves html report in it

        Parameters
        ----------
        output_dir : str
            root output folder path

        '''
        output_dir = self.output_dir
        background_color = list()
        self.report.SectionEnd()

        # results overview section
        self.report.SectionBegin("Results overview")
        results = self.results
        comments = self.comments
        log = self.log

        failed_tc = len([True for tc_result in results.values() if any([res[0] == Verdict.failed for res in tc_result.values()])])
        passed_tc = len([True for tc_result in results.values() if all([res[0] == Verdict.passed for res in tc_result.values()])])
        total_tc = len(results)
        unknown_tc = total_tc - failed_tc - passed_tc
        failed_meas = len([True for tc_result in results.values() for meas_result in tc_result.values() if meas_result[0] == Verdict.failed])
        unknown_meas = len([True for tc_result in results.values() for meas_result in tc_result.values() if meas_result[0] == Verdict.unknown])
        passed_meas = len([True for tc_result in results.values() for meas_result in tc_result.values() if meas_result[0] == Verdict.passed])
        total_meas = sum((len(tc_result) for tc_result in results.values()))

        tc_stats_table = cHTMLReportTable("Testcase Statistics", width=300)
        tc_stats_table.setHeaderRow(cHTMLReportTableRow(cells=["Failed Testcases", "Passed Testcases", "Unknown Testcases", "Total Testcases"]))
        cells = [cHTMLReportTableCell(text='{} = {:.1f}%'.format(failed_tc, failed_tc/total_tc*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text='{} = {:.1f}%'.format(passed_tc, passed_tc/total_tc*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text='{} = {:.1f}%'.format(unknown_tc, unknown_tc/total_tc*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text=str(total_tc),
                                      textAlign="center")]
        tc_stats_table.addRow(cHTMLReportTableRow(cells=cells))
        self.report.AddTable(tc_stats_table)

        meas_stats_table = cHTMLReportTable("Measurements Statistics", width=300)
        meas_stats_table.setHeaderRow(cHTMLReportTableRow(cells=["Failed Measurements", "Passed Measurements", "Unknown Measurements", "Total Measurements"]))
        cells = [cHTMLReportTableCell(text='{} = {:.1f}%'.format(failed_meas, failed_meas/total_meas*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text='{} = {:.1f}%'.format(passed_meas, passed_meas/total_meas*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text='{} = {:.1f}%'.format(unknown_meas, unknown_meas/total_meas*100 if total_tc else 0),
                                      textAlign="center"),
                 cHTMLReportTableCell(text=str(total_meas),
                                      textAlign="center")]
        meas_stats_table.addRow(cHTMLReportTableRow(cells=cells))
        self.report.AddTable(meas_stats_table)

        results_table = cHTMLReportTable("Results overview", sortable=True)
        results_table.setHeaderRow(cHTMLReportTableRow(cells=["Testcase Id", "Testcase Description", "Measurement file", "Result", "Comment"]))

        cntr = 3
        for tc_id in sorted(list(self.results.keys())):
            for meas_file in results.get(tc_id, []):
                cntr += 1
                text_color = None
                if results[tc_id][meas_file][0] == Verdict.passed:
                    background_color = (0, 100, 0)
                elif results[tc_id][meas_file][0] == Verdict.failed:
                    background_color = (175, 0, 0)
                elif results[tc_id][meas_file][0] == Verdict.unknown:
                    background_color = (51, 51, 51)
                if cntr % 2 == 0:
                    background_color = [color-25 if color else color for color in background_color]

                if results[tc_id][meas_file] == (Verdict.failed, True):
                    background_color = 255, 255, 0
                    text_color = 0, 0, 0

                description = '\n'.join(
                    '\n'.join(wrap(line, 80))
                    for line in self.descriptions[tc_id].splitlines()
                )

                cells = [cHTMLReportTableCell(text='<pre>' + str(tc_id) + r'</pre>',
                                              textColor=text_color,
                                              backgroundColor=background_color,
                                              textAlign="center"),
                         cHTMLReportTableCell(text='<pre>' + description + r'</pre>',
                                              textColor=text_color,
                                              backgroundColor=background_color,
                                              textAlign="left"),
                         cHTMLReportTableCell(text='''<a href="#Section{}" onclick="open_section('#divSection{}')" {}>{}</a>'''.format(
                             cntr, cntr, 'style="color: rgb{}"'.format(text_color) if text_color else '', meas_file ),
                                              textColor=text_color,
                                              backgroundColor=background_color),
                         cHTMLReportTableCell(text='<pre>' + Verdict.to_string(results[tc_id][meas_file][0])  + r'</pre>',
                                              textColor=text_color,
                                              backgroundColor=background_color,
                                              textAlign="center"),
                         cHTMLReportTableCell(text='<pre>' + comments[tc_id][meas_file] + r'</pre>',
                                              textColor=text_color,
                                              backgroundColor=background_color)]

                results_table.addRow(cHTMLReportTableRow(cells=cells))

        self.report.AddTable(results_table)

        for table_columns, values in self.stats.items():
            stats_table = cHTMLReportTable("Measurement Statistics", width=300)
            stats_table.setHeaderRow(cHTMLReportTableRow(
                cells=['Measurement'] + list(table_columns)))

            for measurement, verdict, vals in values:
                if verdict == Verdict.passed:
                    background_color = (0, 100, 0)
                elif verdict == Verdict.failed:
                    background_color = (175, 0, 0)
                elif verdict == Verdict.unknown:
                    background_color = (51, 51, 51)
                if cntr % 2 == 0:
                    background_color = [
                        color-25 if color else color
                        for color in background_color
                    ]

                cells = [
                    cHTMLReportTableCell(
                        text=r'<pre>{}</pre>'.format(
                            os.path.basename(measurement)
                        ),
                        backgroundColor=background_color,
                        textAlign="left",
                    ),
                ]

                for text, background_color, mark_yellow in vals:

                    cells.append(
                        cHTMLReportTableCell(
                            text=r'<pre>{}</pre>'.format(text),
                            textAlign="right",
                            backgroundColor=background_color,
                        )
                    )

                    if mark_yellow and verdict in (Verdict.failed, Verdict.unknown):
                        cells[0].backgroundColor = 255, 255, 0
                        cells[0].textColor = 0, 0, 0

                stats_table.addRow(cHTMLReportTableRow(cells=cells))
            self.report.AddTable(stats_table)

        self.report.SectionEnd()

        self.report.SwapLastSection()

        if self.display_log:

            self.report.SectionBegin("Extended logs")

            results_table = cHTMLReportTable("Extended logs", sortable=True)

            results_table.setHeaderRow(cHTMLReportTableRow(
                cells=["Testcase Id", "Testcase Description", "Measurement file", "Result", "Comment",
                       "Log"]))

            cntr = 3
            for tc_id in sorted(list(self.results.keys())):
                for meas_file in results.get(tc_id, []):
                    verdict, mark_yellow = results[tc_id][meas_file]
                    cntr += 1
                    text_color = None
                    if verdict == Verdict.passed:
                        background_color = (0, 100, 0)
                    elif verdict == Verdict.failed:
                        background_color = (175, 0, 0)
                    elif verdict == Verdict.unknown:
                        background_color = (51, 51, 51)
                    if cntr % 2 == 0:
                        background_color = [color - 25 if color else color for
                                            color in background_color]

                    if verdict in (Verdict.unknown, Verdict.failed) and mark_yellow:
                        background_color = (255, 255, 0)
                        text_color = 0, 0, 0

                    log_text = '\n'.join(
                        line.rstrip()
                        for line in log[tc_id][meas_file].splitlines()
                    )

                    description = '\n'.join(
                        '\n'.join(wrap(line, 80))
                        for line in self.descriptions[tc_id].splitlines()
                    )

                    cells = [
                        cHTMLReportTableCell(
                            text='<pre>' + str(tc_id) + r'</pre>',
                            textColor=text_color,
                            backgroundColor=background_color,
                            textAlign="center",
                        ),
                        cHTMLReportTableCell(
                            text='<pre>' + description + r'</pre>',
                            textColor=text_color,
                            backgroundColor=background_color,
                            textAlign="left",
                        ),
                        cHTMLReportTableCell(
                            text=meas_file,
                            textColor=text_color,
                            backgroundColor=background_color,
                        ),
                        cHTMLReportTableCell(
                            text='<pre>' + Verdict.to_string(verdict) + r'</pre>',
                            textColor=text_color,
                            backgroundColor=background_color,
                            textAlign="center",
                        ),
                        cHTMLReportTableCell(
                            text='<pre>' + comments[tc_id][meas_file] + r'</pre>',
                            textColor=text_color,
                            backgroundColor=background_color,
                        ),
                        cHTMLReportTableCell(
                            text='<pre>' + log_text + r'</pre>',
                            textColor=text_color,
                            backgroundColor=background_color,
                        ),
                    ]

                    results_table.addRow(cHTMLReportTableRow(cells=cells))

            self.report.AddTable(results_table)

            self.report.SectionEnd()

        if self.requirements_db and set(self.requirements_db) != {'unlinked', }:
            self.report.SectionBegin("Requirements overview")

            for req, tetscase_ids in self.requirements_db.items():
                self.report.SectionBegin(str(req))

                results_table = cHTMLReportTable(req, sortable=True)

                results_table.setHeaderRow(cHTMLReportTableRow(
                    cells=["Testcase Id", "Testcase Description", "Measurement file", "Result", "Comment"]))

                cntr = 3
                for tc_id in sorted(tetscase_ids):
                    description = '\n'.join(
                        '\n'.join(wrap(line, 80))
                        for line in self.descriptions[tc_id].splitlines()
                    )
                    verd = Verdict.passed
                    for meas_file in results.get(tc_id, []):
                        cntr += 1
                        if results[tc_id][meas_file][0] == Verdict.passed:
                            background_color = (0, 100, 0)
                        elif results[tc_id][meas_file][0] == Verdict.failed:
                            background_color = (175, 0, 0)
                            verd = Verdict.failed
                        elif results[tc_id][meas_file][0] == Verdict.unknown:
                            background_color = (51, 51, 51)
                            if verd == Verdict.passed:
                                verd = Verdict.unknown
                        if cntr % 2 == 0:
                            background_color = [color - 25 if color else color for
                                                color in background_color]

                        cells = [cHTMLReportTableCell(
                                text='<pre>' + str(tc_id) + r'</pre>',
                                backgroundColor=background_color,
                                textAlign="center"),
                            cHTMLReportTableCell(
                                text='<pre>' + description + r'</pre>',
                                backgroundColor=background_color,
                                textAlign="left"),
                            cHTMLReportTableCell(
                                text=meas_file,
                                backgroundColor=background_color),
                            cHTMLReportTableCell(
                                text='<pre>' + Verdict.to_string(
                                    results[tc_id][
                                        meas_file][0]) + r'</pre>',
                                backgroundColor=background_color,
                                textAlign="center"),
                            cHTMLReportTableCell(
                                text='<pre>' + comments[tc_id][
                                    meas_file] + r'</pre>',
                                backgroundColor=background_color)]

                        results_table.addRow(cHTMLReportTableRow(cells=cells))

                self.report.AddTable(results_table)
                self.report.SectionEnd()

            self.report.SectionEnd()

        self.report.SectionBegin("Environment")

        environment_table = cHTMLReportTable("Enviroment", sortable=True)
        environment_table.setHeaderRow(
            cHTMLReportTableRow(cells=["Item", "Description"])
        )

        for item, description in self.environment.items():

            cells = [
                cHTMLReportTableCell(text=item),
                cHTMLReportTableCell(text=description),
            ]

            environment_table.addRow(cHTMLReportTableRow(cells=cells))

        self.report.AddTable(environment_table)

        self.report.SectionEnd()

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        if len(self.results) > 1:
            report_path = os.path.join(output_dir, "Report.html")

        else:
            if self.results:
                tc_id = list(self.results.keys())[0]
            else:
                tc_id = 'id_missing'
            report_path = os.path.join(output_dir, "Report_TC_{}.html".format(tc_id))
        self.report.Save(report_path)

        logging.info('\tReport : ' + report_path)
