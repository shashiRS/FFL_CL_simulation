#!/usr/bin/env python
import os
import sys
import unittest

from utils import get_test_data
from report.html.pyHTMLReport.htmlReport import cHTMLReportTableCell

thispath = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

class TestcHTMLReportTableCell(unittest.TestCase):

    def test_cHTMLReportTableCell_exists(self):
        self.assertTrue(cHTMLReportTableCell)


if __name__ == '__main__':
    unittest.main()
